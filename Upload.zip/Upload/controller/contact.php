<?php

class contact extends Controller
{
    function __construct() 
    {
        parent::__construct();
        
    }
    
    public function Index($data=array())
    {
        $this->view->render('contact/index',$data,1); 
    }
    function contactus()
    {	
        $this->Index();  
    }
}
?>