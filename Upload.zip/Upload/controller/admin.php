<?php
class admin extends Controller
{   
    function __construct() 
    {
        parent::__construct();
    }
    function login()
    {
        $data='';
        $this->view->render('admin/index',$data,1); 
    }
    function admin()
    {
        $data='';
        $ret                           = $this->model->admin();
        $this->view->numberOfUser      = $ret[0];
        $this->view->activeUser        = $ret[1];
        $this->view->deactiveUser      = $ret[2];
        $this->view->allAdvertise      = $ret[3];
        $this->view->activeAdvertise   = $ret[4];
        $this->view->deactiveAdvertise = $ret[5];
        $this->view->visit             = $ret[6];
        $this->view->advertiseVisit    = $ret[7];

        $this->view->render('admin/admin',$data,1);  
    }
    function insertads($pa=0,$pb=0)
    {                         
        $data='';
        $this->view->star_dis      = 'disabled';
        $this->view->link_dis      = 'disabled';
        $this->view->linkdiv       = 'none';
        $this->view->sp            = "inline";
        $this->view->subject       = '';
        $this->view->adsprice      = '';
        $this->view->adscost       = '';
        $this->view->cost          = 0;
        $this->view->title         = '';
        $this->view->comment       = '';
        $this->view->keyword       = '';
        $this->view->adsprice      = '';
        $this->view->mode          = '';
        $this->view->linkvalue_dis = '';
        $this->view->link_value    = '';
        $this->view->name          = '';
        $this->view->email         = '';
        $this->view->tel           = '';
        $this->view->mobile        = '';
        $this->view->yahooid       = '';
        $this->view->address       = '';
        $this->view->etebar        = '';
        $this->view->msg           = '';
        $this->view->empty         = '';
        $this->view->edit          = '';
        $this->view->kind          = '';
        $this->view->price         = '';
        $url                       = '';
        $hasurl                    = '';
        $star                      = '';
        $timelong                  = '';
        
        if($pa == '0')
        {
            $editMode = 0; // Insert New Ads  1
            $this->view->edit          = 0;
        }
        elseif($pa != NUll)
        {
            if($pb != 'edit')
            {
                $editMode = 1; // Edit Ads
                $this->view->edit = 1;
                $this->view->adsid = $pb;
                $ret = $this->model->inserAdsGetAds($pb);
                $this->view->mgid       = $ret['mgid'];
                $this->view->sgid       = $ret['sgid'];
                $this->view->subject    = $ret['subject'];
                $this->view->comment    = $ret['comment'];
                $this->view->keyword    = $ret['keyword'];
                $this->view->price      = $ret['price'];
                $this->view->timelong   = $ret['timelong'];
                $this->view->kind       = $ret['kind'];
                $this->view->hasurl     = $ret['hasurl'];
                $this->view->link_value = $ret['url'];
                $this->view->name       = $ret['name'];
                $this->view->email      = $ret['email'];
                $this->view->tel        = $ret['tel'];
                $this->view->mobile     = $ret['mobile'];
                $this->view->yahooid    = $ret['yahoo'];
                $this->view->address    = $ret['address'];
                
                if($ret['hasurl'] == 1)
                {
                    $this->view->timelong_dis = "disabled";
                }
                if($ret['hasurl'] == 1)
                {
                    $this->view->link_dis      = '';
                    $this->view->linkdiv       = 'inline';
                }
                if($ret['kind'] == 3 OR $ret['kind'] == 4)
                {
                    $this->view->timelong_dis = "disabled";
                    $this->view->sp           = "none";
                    $this->view->linkdiv      = 'none';
                }
                
            }
            else
            {
                header("Location:".URL."admin/adslist");
            }
        }
        if(isset($_POST['addads']))
        {
            $editMode  = $_POST["editmode"];
            $mgroup    = $_POST["mgroup"];
            $sgroup    = $_POST["sgroup"];
            $subject   = $_POST["subject"];
            $comment   = $_POST["comment"];
            $adsPrice  = $_POST["adsprice"];
            $kind      = $_POST["kind"];
            if(isset($_POST["timelong"])) {$timelong  = $_POST["timelong"];}
            if(isset($_POST["hasurl"]))   {$hasurl    = $_POST["hasurl"];}
            if(isset($_POST["url"]))      {$url       = $_POST["url"];}
            if(isset($_POST["star"]))     {$star      = $_POST["star"];}
            $name      = $_POST["name"];
            $email     = $_POST["email"];
            $tel       = $_POST["tel"];
            $mobile    = $_POST["mobile"];
            $yahooid   = $_POST["yahooid"];
            $address   = $_POST["address"];
            $keyword   = $_POST["keyword"];
            $image     = $_FILES['image']['name'];
            $adsId     = 0;
            if($editMode == 1) $adsId = $_POST["adsid"];
            
            $data = $this->model->inserAdsNewAds($editMode,$adsId,$mgroup,$sgroup,$subject,$comment,$adsPrice,$kind,$timelong,$hasurl,$url,$star,$name,$email,$tel,$mobile,$yahooid,$address,$keyword,$image);
            $this->view->mgroup   = $data[0];
            $this->view->sgroup   = $data[1];
            $this->view->subject  = $data[2];
            $this->view->comment  = $data[3];
            $this->view->adsPrice = $data[4];
            $this->view->kind     = $data[5];
            $this->view->timelong = $data[6];
            //$this->view->hasurl   = $data[7];
            $this->view->url      = $data[8];
            $this->view->star     = $data[9];
            $this->view->name     = $data[10];
            $this->view->email    = $data[11];
            $this->view->tel      = $data[12];
            $this->view->mobile   = $data[13];
            $this->view->yahooid  = $data[14];
            $this->view->address  = $data[15];
            $this->view->keyword  = $data[16];
            $this->view->msg      = $data[17];
            //$this->view->cost     = sefr($data[18]);
            $this->view->edit     = 1;
            if($this->view->kind == 3 OR $this->view->kind == 4) {$this->view->timelong_dis = 'disabled';$this->view->star_dis = '';}
        }
        
        
        $this->view->render('admin/insertads',$data,1);
    }
    function adslist($param1=0,$param2=0,$param3=0)
    {
        $data='';
        if(isset($_POST['search']))
        {
            $word = $_POST['word'];
            header("Location:".URL."admin/adslist/search/".$word);
        }
        if($param1 == '0')
        {
            $this->view->page       = 0;
            $this->view->searchMode = 0;
            $this->view->userMode   = 0;
        }
        elseif($param2 == '0')
        {
           $this->view->page       = $param1;
           $this->view->searchMode = 0;
           $this->view->userMode   = 0;
        }
        elseif($param1 == 'user')
        {
            $this->view->email      = $this->model->getemail($param2);
            $this->view->uid        = $param2;
            if($param3 == 0) $this->view->page       = 1;
            if($param3 != 0) $this->view->page       = $param3;
            $this->view->userMode   = 1;
            $this->view->searchMode = 0;
        }
        elseif($param1 == 'search')
        {
           $this->view->word       = $param2;
           if($param3 == 0) $this->view->page       = 1;
           if($param3 != 0) $this->view->page       = $param3;
           $this->view->searchMode = 1;
           $this->view->userMode   = 0;
        }
        $this->view->render('admin/adslist',$data,1);  
    }
    function galerydelete()
    {
        $this->view->page       = 0;
        $this->view->searchMode = 0;
        $this->view->userMode   = 0;
        $this->model->galeryDelete($id);
        header("Location:".URL."admin/adslist");
    }
    function adsrefresh($pa=0)
    {

        $this->view->page       = 0;
        $this->view->searchMode = 0;
        $this->view->userMode   = 0;
        $data = '';
        if($pa == 0)
        {
            
        }
        else 
        {
            $this->model->adsRefresh($pa);
        }
        header("Location:".URL."admin/adslist");
    }
    function adsdelete($id)
    {
        $data='';
        $this->view->page       = 0;
        $this->view->searchMode = 0;
        $this->view->userMode   = 0;
        $this->model->adsDelete($id);
        header("Location:".URL."admin/adslist");
    }
    function adsedit($id)
    {
        $data='';
        $this->view->page       = 0;
        $this->view->searchMode = 0;
        $this->view->userMode   = 0;
        header("Location:".URL."admin/insertads");
    }
    function fish($pa=0,$pb=0)
    {
        $data='';
        $this->view->msg  = '';
        $this->view->page = 1;
        $this->view->editMode = '';
        if($pa != NULL)
        {
            if($pb == 0)
            {
                header("Location:".URL."admin/fish");
            }
            else
            {
                if($pa == 'page')
                {
                    $this->view->page = $pb;
                }
                elseif($pa == 'delete')
                {
                    $this->model->fishDelete($pb);
                    header("Location:".URL."admin/fish");
                }
                elseif($pa == 'confirm')
                {
                    $this->model->fishConfirm($pb);
                    header("Location:".URL."admin/fish");
                }
                elseif($pa == 'edit')
                {
                    $data='';
                    $this->view->editMode = 1;
                    $this->view->msg='';
                    if(isset($_POST['regfish']))
                    {
                        $id       = $_POST["id"];
                        $aid      = $_POST["account"];
                        $resid    = $_POST["resid"];
                        $amount   = $_POST["amount"];
                        $fishdate = $_POST["date"];
                        $sender   = $_POST["sender"];
                        $comment  = $_POST["comment"];
                        $this->view->msg = $this->model->fishEditConfirm($id,$aid,$resid,$amount,$fishdate,$sender,$comment);
                    }
                    $ret                 = $this->model->fishGetData($pb);
                    $this->view->aid     = $ret[1];
                    $this->view->fdate   = $ret[3];
                    $this->view->resid   = $ret[5]; 
                    $this->view->amount  = $ret[6];   
                    $this->view->sender  = $ret[7]; 
                    $this->view->comment = $ret[8];
                }
                else
                {
                    header("Location:".URL."admin/fish");   
                }
            }
            
        }
        $this->view->render('admin/fish',$data,1);  
    }
    function onlinepay($pa=0,$pb=0)
    {
        $data='';
        $this->view->msg  = '';
        $this->view->page = 1;
        if($pa != NULL)
        {
            if($pb == 0)
            {
                header("Location:".URL."admin/onlinepay");
            }
            else
            {
                if($pa == 'page')
                {
                    $this->view->page = $pb;
                }
                elseif($pa == 'delete')
                {
                    $this->model->onlinepayDelete($pb);
                    header("Location:".URL."admin/onlinepay");
                }
                elseif($pa == 'confirm')
                {
                    $this->model->onlinepayConfirm($pb);
                    header("Location:".URL."admin/onlinepay");
                }
                else
                {
                    header("Location:".URL."admin/onlinepay");   
                }
            }
            
        }
        $this->view->render('admin/onlinepay',$data,1); 
    }
    
    function account($pa=0,$pb=0)
    {
        $data='';
        $this->view->msg  = '';
        $this->view->page = 1;
        if($pa != NULL)
        {
            if($pb == 0)
            {
                header("Location:".URL."admin/account");
            }
            else
            {
                if($pa == 'page')
                {
                    $this->view->page = $pb;
                }
                elseif($pa == 'del')
                {
                    $this->model->accountDelete($pb);
                    header("Location:".URL."admin/account");
                }
                else
                {
                    header("Location:".URL."admin/account");   
                }
            }
            
        }
        if(isset($_POST['sendaccount']))
        {
            $accountname   = $_POST["accountname"];
            $accountnumber = $_POST["accountnumber"];
            $accountatm    = $_POST["accountatm"];
            $accountsheba  = $_POST["accountsheba"];
            $accountholder = $_POST["accountholder"];
            $this->view->msg = $this->model->accountAdd($accountname,$accountnumber,$accountatm,$accountsheba,$accountholder);
        }
        $this->view->render('admin/account',$data,1);  
    }
    function onlinepayaccount($pa=0,$pb=0)
    {
        $data='';
        $this->view->parameter1 = '';
        $this->view->parameter2 = '';
        $this->view->editMode   = '';
        $this->view->msg        = '';
        $this->view->page       = 1;
        if($pa != NULL)
        {
            if($pb == 0)
            {
                header("Location:".URL."admin/onlinepayaccount");
            }
            else
            {
                if($pa == 'page')
                {
                    $this->view->page = $pb;
                }
                elseif($pa == 'delete')
                {
                    $this->model->onlinePayAccountDelete($pb);
                    header("Location:".URL."admin/onlinepayaccount");
                }
                elseif($pa == 'edit')
                {
                    $ret                       = $this->model->onlineGetAccount($pb);
                    $this->view->bankid        = $ret['bankid'];
                    $this->view->parameter1    = $ret['parameter1'];
                    $this->view->parameter2    = $ret['parameter2'];
                    $this->view->accountstatus = $ret['accountstatus'];
                    $this->view->editMode      = 1;
                    $this->view->render('admin/onlinepayaccount',$data,1); 
                }
                else
                {
                    header("Location:".URL."admin/account");   
                }
            }
            
        }
        if(isset($_POST['addonlinemethod']))
        {
            $bankid        = $_POST["bankid"];
            $parameter1    = $_POST["parameter1"];
            $parameter2    = $_POST["parameter2"];
            $accountstatus = $_POST["accountstatus"];
            $this->model->onlinepayAdd($bankid,$parameter1,$parameter2,$accountstatus);
        }
        if(isset($_POST['editonlinemethod']))
        {
            $id              = $_POST["id"];
            $bankid          = $_POST["bankid"];
            $parameter1      = $_POST["parameter1"];
            $parameter2      = $_POST["parameter2"];
            $accountstatus   = $_POST["accountstatus"];
            $this->view->msg = $this->model->onlinepayAccountEdit($id,$bankid,$parameter1,$parameter2,$accountstatus);
        }
        $this->view->render('admin/onlinepayaccount',$data,1);  
    }
    function content($pa=0,$pb=0)
    {
        $data='';
        $this->view->name     = '';
        $this->view->content  = '';
        $this->view->msg      ='';
        $this->view->editMode ='';
        if($pa != NULL)
        {
            if($pb == 0)
            {
                header("Location:".URL."admin/content");
            }
            else
            {
                if($pa == 'page')
                {
                    $this->view->page = $pb;
                }
                elseif($pa == 'delete')
                {
                    $ret = $this->model->contentDelete($pb);
                    header("Location:".URL."admin/content");
                }
                elseif($pa == 'edit')
                {
                    $this->view->editMode = 1; 
                    $ret                  = $this->model->contentGetData($pb);
                    $this->view->name     = $ret['name'];
                    $this->view->content  = $ret['content'];
                }
                else
                {
                    header("Location:".URL."admin/content");   
                }
            } 
        }
        if(isset($_POST['addcontent']))
        {
            $name    = $_POST["name"];
            $content = $_POST["content"];
            $this->view->msg = $this->model->contentAdd($name,$content);
            header("Location:".URL."admin/content"); 
        }
        if(isset($_POST['editcontent']))
        {
            $id      = $_POST["id"];
            $name    = $_POST["name"];
            $content = $_POST["content"];
            $this->view->msg = $this->model->contentEdit($id,$name,$content);
            header("Location:".URL."admin/content"); 
        }
        $this->view->render('admin/content',$data,1);  
    }
    function menu($pa=0,$pb=0)
    {
        $data='';
        $mid='';
        $k='';
        $this->view->editMode   = '';
        $this->view->menukind   = '';
        $this->view->menuname   = '';
        $this->view->menufile   = '';
        $this->view->menulink   = '';
        $this->view->menupos    = '';
        $this->view->menustatus = '';
        $this->view->msg        = '';
        $location = 'block/'; 
        $dir = dir($location); 
        while ($entry = $dir->read()) 
        {
            $entry;
            if (is_file($location . $entry))
            {

                if($entry != 'index.php') 
                {
                    $k++;
                    $this->view->phpfile[$k] = $entry;
                }
            } 
        }
        if($pa != NULL)
        {
            if($pb == 0)
            {
                header("Location:".URL."admin/menu");
            }
            else
            {
                if($pa == 'page')
                {
                    $this->view->page = $pb;
                }
                elseif($pa == 'delete')
                {
                    $ret = $this->model->menuDelete($pb);
                    $id = $_GET['id'];
                    header("Location:".URL."admin/menu");
                }
                elseif($pa == 'edit')
                {
                    $this->view->editMode     = 1; 
                    $ret                      = $this->model->menuGetData($pb);
                    $this->view->menuname     = $ret["name"];
                    $this->view->menufile     = $ret["file"];
                    $this->view->menukind     = $ret["kind"];
                    $this->view->menustatus   = $ret["status"];
                    $this->view->menupos      = $ret["pos"];
                    $this->view->menulink     = $ret["file"];
                }
                elseif($pa == 'up')
                {
                    $this->model->menuUpOrdering($pb);
                    
                }
                elseif($pa == 'dn')
                {
                    $this->model->menuDnOrdering($pb);
                }
                else
                {
                    header("Location:".URL."admin/menu");   
                }
            } 
        }
        if(isset($_POST['menuadd']))
        {
            $menukind     = $_POST["menukind"];
            $menuname     = $_POST["menuname"];
            $menustatus   = $_POST["menustatus"];
            $menuposition = $_POST["menuposition"];
            if(isset($_POST["menulink"])) $menulink     = $_POST["menulink"];
            if(isset($_POST["menufile"])) $menufile     = $_POST["menufile"];
            if(isset($_POST["menucontent"])){$menucontent  = $_POST["menucontent"];}
            if($menukind == 1) $file = $menufile;
            if($menukind == 2) $file = $menucontent;
            if($menukind == 3) $file = $menulink;
            if($menukind == 4) $file = $menulink;
            $ordering     = my_max(TABLE_PREFIX.'menu','ordering','pos',$menuposition,-1,-1,-1,-1,-1,-1) + 1;
            $this->model->menuAdd($menuname,$file ,$menukind ,$ordering  ,$menuposition,$menustatus);  
        }
        if(isset($_POST['menuedit']))
        {
            $id           = $_POST["id"];
            $menukind     = $_POST["menukind"];
            $menuname     = $_POST["menuname"];
            $menustatus   = $_POST["menustatus"];
            $menuposition = $_POST["menuposition"];
            if(isset($_POST["menulink"])) $menulink     = $_POST["menulink"];
            if(isset($_POST["menufile"])) $menufile     = $_POST["menufile"];
            if(isset($_POST["menucontent"])){$menucontent  = $_POST["menucontent"];}
            if($menukind == 1) $file = $menufile;
            if($menukind == 2) $file = $menucontent;
            if($menukind == 3) $file = $menulink;
            if($menukind == 4) $file = $menulink;
            $this->view->msg = $this->model->menuEdit($id,$menuname,$file,$menukind,$menuposition,$menustatus); 
        }
        $this->view->render('admin/menu',$data,1);  
    }
    function adsmaingroup($pa=0,$pb=0)
    {
        $data='';
        $this->view->mgname   = '';
        $this->view->mgimage  = '';
        $this->view->editMode = '';
        $this->view->msg      = '';
        if(isset($_POST['maingroup']))
        {
            $mgname  = $_POST["mgname"];
            $mgimage = $_POST["mgimage"];
            $this->view->msg = $this->model->adsMainGroupAdd($mgname,$mgimage); 
        }
        if(isset($_POST['editmaingroup']))
        {
            $mgid    = $_POST["id"];
            $mgname  = $_POST["mgname"];
            $mgimage = $_POST["mgimage"];
            $this->view->msg = $this->model->adsMainGroupEdit($mgid,$mgname,$mgimage);
        }
        if($pa != NULL)
        {
            if($pb == 0)
            {
                header("Location:".URL."admin/adsmaingroup");
            }
            else
            {
                if($pa == 'page')
                {
                    $this->view->page = $pb;
                }
                elseif($pa == 'delete')
                {
                   $ret = $this->model->adsMainGroupDelete($id);
                }
                elseif($pa == 'edit')
                {
                    $this->view->editMode = 1; 
                    $ret                  = $this->model->adsMainGroupGetData($pb);
                    $this->view->mgname   = $ret['mgname'];
                    $this->view->mgimage  = $ret['mgjpg'];
                }
                else
                {
                    header("Location:".URL."admin/adsmaingroup");   
                }
            } 
        }
        $this->view->render('admin/adsmaingroup',$data,1);  
    }
    function adssubgroup($pa=0,$pb=0)
    {
        $data='';
        $this->view->sgname   = '';
        $this->view->mgimage  = '';
        $this->view->editMode = '';
        $this->view->msg      = '';
        $this->view->page     = 1;
        if(isset($_POST['subgroup']))
        {
            $sgname = $_POST["sgname"];
            $mgid   = $_POST["mgid"];
            $this->view->msg = $this->model->adsSubGroupAdd($sgname,$mgid); 
        }
        if(isset($_POST['editsubgroup']))
        {
            $mgid   = $_POST["id"];
            $sgname = $_POST["sgname"];
            $mgid   = $_POST["mgid"];
            $this->view->msg = $this->model->adsSubGroupEdit($pb,$sgname,$mgid);
        }
        if($pa != NULL)
        {
            if($pb == 0)
            {
                header("Location:".URL."admin/adssubgroup");
            }
            else
            {
                if($pa == 'page')
                {
                    $this->view->page = $pb;
                }
                elseif($pa == 'delete')
                {
                   $ret = $this->model->adsSubGroupDelete($pb);
                }
                elseif($pa == 'edit')
                { 
                    $ret                  = $this->model->adsSubGroupGetData($pb);
                    $this->view->sgname   = $ret['sgname'];
                    $this->view->mgid     = $ret['mgid'];
                    $this->view->editMode = 1;
                }
                else
                {
                    header("Location:".URL."admin/adssubgroup");   
                }
            } 
        }
        $this->view->render('admin/adssubgroup',$data,1);  
    }
    function userlist($pa=0,$pb=-1,$pc=0,$pd=0)
    {
        $data = '';
        $this->view->page = 1; 
        $this->view->sort = '';
        $this->view->msg  = '';
        $this->view->sort = 0;$this->view->s1=1;$this->view->s2=3;$this->view->s3=5;$this->view->s4=7;$this->view->s5=9;$this->view->s5=11;
        if($pa != NULL)
        {
            if($pb == -1)
            {
                header("Location:".URL."admin/userlist");
            }
            else
            {
                if($pa == 'sort')
                {
                    $this->view->sort = $pb;
                    if($pb > 12)  {$this->view->sort = 0;$this->view->s1=1;$this->view->s2=3;$this->view->s3=5;$this->view->s4=7;$this->view->s5=9;$this->view->s5=11;}
                    if($pb == 1)  {$this->view->s1 =2;   $this->view->s2=3;$this->view->s3=5;$this->view->s4=7;$this->view->s5=9;$this->view->s6=11;}
                    if($pb == 2)  {$this->view->s1 =1;   $this->view->s2=3;$this->view->s3=5;$this->view->s4=7;$this->view->s5=9;$this->view->s6=11;}
                    if($pb == 3)  {$this->view->s1 =1;   $this->view->s2=4;$this->view->s3=5;$this->view->s4=7;$this->view->s5=9;$this->view->s6=11;}
                    if($pb == 4)  {$this->view->s1 =1;   $this->view->s2=3;$this->view->s3=5;$this->view->s4=7;$this->view->s5=9;$this->view->s6=11;}
                    if($pb == 5)  {$this->view->s1 =1;   $this->view->s2=3;$this->view->s3=6;$this->view->s4=7;$this->view->s5=9;$this->view->s6=11;}
                    if($pb == 6)  {$this->view->s1 =1;   $this->view->s2=3;$this->view->s3=5;$this->view->s4=7;$this->view->s5=9;$this->view->s6=11;}
                    if($pb == 7)  {$this->view->s1 =1;   $this->view->s2=3;$this->view->s3=5;$this->view->s4=8;$this->view->s5=9;$this->view->s6=11;}
                    if($pb == 8)  {$this->view->s1 =1;   $this->view->s2=3;$this->view->s3=5;$this->view->s4=7;$this->view->s5=9;$this->view->s6=11;}
                    if($pb == 9)  {$this->view->s1 =1;   $this->view->s2=3;$this->view->s3=5;$this->view->s4=7;$this->view->s5=10;$this->view->s6=11;}
                    if($pb == 10) {$this->view->s1 =1;   $this->view->s2=3;$this->view->s3=5;$this->view->s4=7;$this->view->s5=9;$this->view->s6=11;}
                    if($pb == 11) {$this->view->s1 =1;   $this->view->s2=3;$this->view->s3=5;$this->view->s4=7;$this->view->s5=9;$this->view->s6=12;}
                    if($pb == 12) {$this->view->s1 =1;   $this->view->s2=3;$this->view->s3=5;$this->view->s4=7;$this->view->s5=9;$this->view->s6=11;}
                    if($pc == 'page' AND $pd != 0)
                    {
                       
                        $this->view->page = $pd;   
                    }
                }
                elseif($pa == 'delete')
                {
                   $this->view->msg = $this->model->userListDelete($pb);
                }
                else
                {
                    header("Location:".URL."admin/userlist");   
                }
            } 
        }   
        $this->view->render('admin/userlist',$data,1);
    }
    function adminfooter()
    {
        $data='';
        $this->view->msg = '';
        if(isset($_POST['editfooter']))
        {
            $comment = $_POST["comment"];
            $this->view->msg = $this->model->adminFooterEdit($comment);
        }
        $ret= $this->model->adminFooterGetData();
        $this->view->footer = $ret['value'];
        $this->view->render('admin/adminfooter',$data,1);  
    }
    function emailtemplate($pa=0,$pb=0)
    {
        $data='';
        $this->view->editMode = '';
        $this->view->msg      = '';
        $this->view->page     = 1;
        $this->view->name     = '';
        $this->view->content  = '';
        if(isset($_POST['addcontent']))
        {
            $content         = $_POST["content"];
            $name            = $_POST["name"];
            $this->view->msg = $this->model->emailTemplateAdd($name,$content); 
        }
        if(isset($_POST['editcontent']))
        {
            $id              = $_POST["id"];
            $name            = $_POST["name"];
            $content         = $_POST["content"];
            $this->view->msg = $this->model->emailTemplateEdit($id,$name,$content);
        }
        if($pa != NULL)
        {
            if($pb == 0)
            {
                header("Location:".URL."admin/emailtemplate");
            }
            else
            {
                if($pa == 'page')
                {
                    $this->view->page = $pb;
                }
                elseif($pa == 'delete')
                {
                   $ret = $this->model->emailTemplateDelete($pb);
                }
                elseif($pa == 'edit')
                {
                    $this->view->editMode = 1; 
                    $ret                  = $this->model->emailTemplateGetData($pb);
                    $this->view->name     = $ret['name'];
                    $this->view->content  = $ret['content'];
                }
                else
                {
                    header("Location:".URL."admin/emailtemplate");   
                }
            }
        }
        $this->view->render('admin/emailtemplate',$data,1);  
    }
    function email($pa=0,$pb=-1,$pc=0,$pd=0)
    {
        $data = '';$rt=0;$ro='';$userId='';$len=0;$k=0;
        $this->view->page = 1; 
        $this->view->sort = '';
        $this->view->msg  = '';
        $this->view->sort = 0;$this->view->s1=1;$this->view->s2=3;$this->view->s3=5;$this->view->s4=7;$this->view->s5=9;$this->view->s6=11;
        if(isset($_POST['send']))
        {

            $row         = $_POST["satr"];
            $eid         = $_POST["eid"];
            $subject     = $_POST["subject"];
            for($t=1 ; $t<=$row ; $t++)
            {
                $uId = $_POST["uid".$t];
                if(isset($_POST["ch".$t])) {$ro  = $_POST["ch".$t];}
                if($ro == 'on')
                {
                    $userId[$rt] = $uId;
                    $rt++;
                    $k=1;
                }
            }
            if($k==1) $len = count($userId);
            if($eid < 1)
            {
                $this->view->msg="<font color=red>قالب نامه را انتخاب کنید</font>";
            }
            elseif($subject == "")
            {
                $this->view->msg="<font color=red>موضوع ایمیل را وارد نمایید</font>";
            }
            elseif($len > 10)
            {
                $this->view->msg="<font color=red>حداکثر 10 عضو انتخاب کنید</font>";
            }
            elseif($len < 1)
            {
                $this->view->msg="<font color=red>حداقل یک عضو را انتخاب کنید</font>";
            }
            else
            {
               $this->view->msg = $this->model->emailSend($eid,$subject,$userId);
            }

        }
        if($pa != NULL)
        {
            if($pb == -1)
            {
                header("Location:".URL."admin/email");
            }
            else
            {
                if($pa == 'sort')
                {
                    $this->view->sort = $pb;
                    if($pb > 12)  {$this->view->sort = 0;$this->view->s1=1;$this->view->s2=3;$this->view->s3=5;$this->view->s4=7;$this->view->s5=9;$this->view->s5=11;}
                    if($pb == 1)  {$this->view->s1 =2;   $this->view->s2=3;$this->view->s3=5;$this->view->s4=7;$this->view->s5=9;$this->view->s6=11;}
                    if($pb == 2)  {$this->view->s1 =1;   $this->view->s2=3;$this->view->s3=5;$this->view->s4=7;$this->view->s5=9;$this->view->s6=11;}
                    if($pb == 3)  {$this->view->s1 =1;   $this->view->s2=4;$this->view->s3=5;$this->view->s4=7;$this->view->s5=9;$this->view->s6=11;}
                    if($pb == 4)  {$this->view->s1 =1;   $this->view->s2=3;$this->view->s3=5;$this->view->s4=7;$this->view->s5=9;$this->view->s6=11;}
                    if($pb == 5)  {$this->view->s1 =1;   $this->view->s2=3;$this->view->s3=6;$this->view->s4=7;$this->view->s5=9;$this->view->s6=11;}
                    if($pb == 6)  {$this->view->s1 =1;   $this->view->s2=3;$this->view->s3=5;$this->view->s4=7;$this->view->s5=9;$this->view->s6=11;}
                    if($pb == 7)  {$this->view->s1 =1;   $this->view->s2=3;$this->view->s3=5;$this->view->s4=8;$this->view->s5=9;$this->view->s6=11;}
                    if($pb == 8)  {$this->view->s1 =1;   $this->view->s2=3;$this->view->s3=5;$this->view->s4=7;$this->view->s5=9;$this->view->s6=11;}
                    if($pb == 9)  {$this->view->s1 =1;   $this->view->s2=3;$this->view->s3=5;$this->view->s4=7;$this->view->s5=10;$this->view->s6=11;}
                    if($pb == 10) {$this->view->s1 =1;   $this->view->s2=3;$this->view->s3=5;$this->view->s4=7;$this->view->s5=9;$this->view->s6=11;}
                    if($pb == 11) {$this->view->s1 =1;   $this->view->s2=3;$this->view->s3=5;$this->view->s4=7;$this->view->s5=9;$this->view->s6=12;}
                    if($pb == 12) {$this->view->s1 =1;   $this->view->s2=3;$this->view->s3=5;$this->view->s4=7;$this->view->s5=9;$this->view->s6=11;}
                    if($pc == 'page' AND $pd != 0)
                    {
                       
                        $this->view->page = $pd;   
                    }
                }
                else
                {
                    header("Location:".URL."admin/email");   
                }
            } 
        }   
        $this->view->render('admin/email',$data,1);
    }
    function rq($pa=0,$pb=0)
    {
        $data='';
        $this->view->editMode = '';
        $this->view->msg      = '';
        $this->view->page     = 1;
        $this->view->question = '';
        $this->view->answer   = '';
        if(isset($_POST['addrq']))
        {
            $question  = $_POST["question"];
            $answer    = $_POST["answer"];

            if($question  == NULL)
            {
                $this->view->msg = "<font color=red>سوال را وارد کنید</font>";
            }
            elseif($answer == NULL)
            {
                $this->view->msg = "<font color=red>پاسخ را وارد کنید</font>";
            }
            else
            {
                $this->view->msg = $this->model->rqAdd($question,$answer); 
            } 
        }
        if(isset($_POST['editrq']))
        {
            $id              = $_POST["id"];
            $question        = $_POST["question"];
            $answer          = $_POST["answer"];
            $this->view->msg = $this->model->rqEdit($id,$question,$answer);
        }
        if($pa != NULL)
        {
            if($pb == 0)
            {
                header("Location:".URL."admin/rq");
            }
            else
            {
                if($pa == 'page')
                {
                    $this->view->page = $pb;
                }
                elseif($pa == 'delete')
                {
                   $this->view->msg = $this->model->rqDelete($pb);
                }
                elseif($pa == 'edit')
                {
                    $this->view->editMode = 1; 
                    $ret                  = $this->model->rqGetData($pb);
                    $this->view->question = $ret['question'];
                    $this->view->answer   = $ret['answer'];
                }
                else
                {
                    header("Location:".URL."admin/rq");   
                }
            }
        }
        $this->view->render('admin/rq',$data,1);  
    }
    function amar()
    {
        $data='';
        $this->view->render('admin/amar',$data,1);  
    }
    function visitor()
    {
        $data='';
        $this->view->render('admin/visitor',$data,1);  
    }
    function setting()
    {
        $data='';
        $this->view->msg='';
        if(isset($_POST['updatesetting']))
        {
            $ads_on_first_page      = $_POST['ads_on_first_page'];
            $star_price             = preg_replace('/[^\d]/', '', $_POST['star_price']);
            $link_price             = preg_replace('/[^\d]/', '', $_POST['link_price']);
            $ads_sp_price           = preg_replace('/[^\d]/', '', $_POST['ads_sp_price']);
            $gift                   = preg_replace('/[^\d]/', '', $_POST['gift']);
            $onvan                  = $_POST['onvan'];
            $image_ads_show         = $_POST['image_ads_show'];
            $smsWebservise          = $_POST['smsWebservise'];
            $smsNumber              = $_POST['smsNumber'];
            $smsUsername            = $_POST['smsUsername'];
            $smsPassword            = $_POST['smsPassword'];
            $siteEmail              = $_POST['siteEmail'];
            $ip1       		        = $_POST['ip1'];
            $ip2                    = $_POST['ip2'];
            $registerMode           = $_POST['registerMode'];
            $loginNotConfirmedEmail = $_POST['loginNotConfirmedEmail'];
            $galeryThemes           = $_POST['galeryThemes'];
            $adsCol                 = $_POST['adsCol'];
            $this->view->msg        = $this->model->settingEdit($ads_on_first_page,$star_price ,$link_price,$ads_sp_price,$gift,$onvan,$image_ads_show,$smsWebservise,$smsNumber,$smsUsername,$smsPassword,$siteEmail,$ip1,$ip2,$registerMode,$loginNotConfirmedEmail,$galeryThemes,$adsCol);
        }

        $this->view->ads_on_first_page      = Setting::GetSetting(1);
        $this->view->star_price             = Setting::GetSetting(2);
        $this->view->link_price             = Setting::GetSetting(3);
        $this->view->ads_sp_price           = Setting::GetSetting(4);
        $this->view->onvan                  = Setting::GetSetting(5);
        $this->view->image_ads_show         = Setting::GetSetting(6);
        $this->view->smsWebservise          = Setting::GetSetting(7);
        $this->view->smsNumber              = Setting::GetSetting(8);
        $this->view->smsUsername            = Setting::GetSetting(9);
        $this->view->smsPassword            = Setting::GetSetting(10);
        $this->view->siteAddress            = Setting::GetSetting(11);
        $this->view->siteEmail              = Setting::GetSetting(12);
        $this->view->ip1                    = Setting::GetSetting(14);
        $this->view->ip2                    = Setting::GetSetting(15);
        $this->view->registerMode           = Setting::GetSetting(16);
        $this->view->loginNotConfirmedEmail = Setting::GetSetting(17);
        $this->view->galeryThemes           = Setting::GetSetting(18);
        $this->view->gift                   = Setting::GetSetting(20);
        $this->view->adsCol                 = Setting::GetSetting(21);
        $this->view->render('admin/setting',$data,1);  
    }
    function resetpassword()
    {
        $data='';
        $this->view->msg = '';
        if(isset($_POST['changePassword']))
        {
            $currentPassword = $_POST["currentPassword"];
            $newPassword     = $_POST["newPassword"];
            $renewPassword   = $_POST["renewPassword"];
            $adminId         = $_POST["id"];

            if($currentPassword  == NULL)
            {
                $this->view->msg = "<font color=red>کلمه عبور فعلی را وارد نمایید</font>";
            }
            elseif($newPassword      == NULL) 
            { 
                $this->view->msg = "<font color=red>کلمه عبور جدید را وارد کنید</font>";
                
            }
            elseif($renewPassword    == NULL)
            {
                $this->view->msg = "<font color=red>تکرار کلمه عبور جدید را وارد نمایید</font>";
            }
            else
            {
                $this->view->msg = $this->model->resetPassword($adminId,$currentPassword,$newPassword,$renewPassword);
            }

        }
        $this->view->render('admin/resetpassword',$data,1);  
    }
    function logout()
    {
        session_start();
        unset($_SESSION['SUB_ADMIN_ID']);
        header("Location: ../index.php");
    }
}
?>