<?php

class content extends Controller
{
    function __construct() 
    {
        parent::__construct();
        
    }
    
    public function Index($data=array())
    {
        $this->view->render('content/index',$data,1); 
    }
    function page($id)
    {	
        if (!isset($id))
        {
            header("Location:" . URL);
        }
        $ret = $this->model->page($id);
		$this->view->name    = $ret[1];
        $this->view->content = $ret[2];
        $this->Index();
    }
}
?>