<?php

class ads extends Controller
{
    function __construct() 
    {
        parent::__construct();
        
    }
    function view($id,$sub=0,$data=array())
    {
        $this->view->group = 0;
        $this->view->page = 1;
        $pt2 =  $_GET['url'];
        $pt2 = trim($pt2,'/');
        $pt2 = explode('/', $pt2);
        $sub = trim($pt2[3]);
        $count = count($pt2);
        if($count == 4)
        {
            if(get_int($id))
            {       
               
                $ret     = $this->model->view($id);
                $subject = space_rep($this->view->subject  = trim($ret[4]));
                if($subject == $sub)
                {
                    $this->view->adsid    = $ret[0];
                    $this->view->userid   = $ret[1];
                    $this->view->mgid     = $ret[2];
                    $this->view->sgid     = $ret[3];
                    $this->view->comment  = $ret[5];
                    $this->view->price    = $ret[6];
                    $this->view->adskind  = $ret[8];
                    $this->view->star     = $ret[10];
                    $this->view->crdate   = $ret[12];
                    $this->view->update   = $ret[13];
                    $this->view->lvdate   = $ret[15];
                    $this->view->timelong = $ret[16];
                    $this->view->url      = $ret[17];
                    $this->view->hasurl   = $ret[18];
                    $this->view->name     = $ret[19];
                    $this->view->email    = $ret[20];
                    $this->view->tel      = $ret[21];
                    $this->view->mobile   = $ret[22];
                    $this->view->yahoo    = $ret[23];
                    $this->view->address  = $ret[24];
                    $this->view->keyword  = $ret[25];
                    $this->view->visit    = $ret[26];
                    $this->view->render('ads/index',$data,1); 
                }
                else
                {
                    header("Location:../../index.php");   
                }
            }
            else 
            {
                header("Location:../../index.php");
            }
        }
        else 
        {
            header("Location:../../index.php");
        }
    }
    function group($sgid,$page,$data=array())
    {
        
        $ret = $this->model->group($sgid);
        $this->view->page = $page;
        $this->view->mgid  = $ret[1];
        $this->view->sgid  = $sgid;
        $this->view->group = 1;
        $this->view->render('ads/index',$data,1); 
    }
}
?>