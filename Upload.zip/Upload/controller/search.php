<?php

class search extends Controller
{
    function __construct() 
    {
        parent::__construct();
        
    }
    
    public function Index($data=array())
    {
        $this->view->render('search/index',$data,1); 
    }

    function word($page,$word)
    {	
        $this->view->word = $word;
        $this->Index();  
    }

}
?>