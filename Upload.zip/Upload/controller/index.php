<?php
class index extends Controller
{
    function __construct() 
    {
        parent::__construct();
    }
    public function Index($data=array())
    {
        $this->view->render('index/index',$data,1);
        
    }
    function maingroup($id)
    {
       if(!isset($id)) header("Location:".URL);
       $data = $this->model->maingroup($id);
       $this->view->mgads = 1;
       $this->view->mgid = $id;
       $this->Index();
    }
    function subgroup($id)
    {
       if(!isset($id)) header("Location:".URL);
       $data = $this->model->subgroup($id);
       $this->view->sgads = 1;
       $this->view->sgid = $id;
       $this->Index();
    }
}
?>