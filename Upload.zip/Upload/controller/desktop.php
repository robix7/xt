<?php
class desktop extends Controller
{   
    function __construct() 
    {
        parent::__construct();
    }
    function galery($pa=0,$pb=0)
    {
        $data='';
        $this->view->msg = '';
        $this->view->uid = UID;
        if($pa == '0')
        {
            header("Location:".URL."desktop/adslist");
        }
        elseif($pb == '0')
        {
            header("Location:".URL."desktop/adslist");
        }
        elseif($pa == 'view')
        {
            $ret                 = $this->model->viewGalery($pb);
            $this->view->kind    = $ret['kind'];
            $this->view->subject = $ret['subject'];
            $this->view->comment = $ret['comment'];
            $this->view->star    = $ret['star'];
            $this->view->id      = $pb;
        }
        elseif($pa == 'delete')
        {
            $ret            = $this->model->deleteGalery($pb);
            header("Location:".URL."desktop/galery/view/".$ret);
        }
        if(isset($_POST['sendimage']))
        {
            $id    = $pb;
            $image = $_FILES['image']['name'];
            $al    = $_POST["al"];
            $name  = $_POST["name"];
            $uid   = UID;
            $this->view->msg = $this->model->sendGaleryImage($uid,$id,$image,$al,$name);
        }
        $this->view->render('desktop/galery',$data,1); 
    }
    function index()
    {
        $data='';
        $this->view->sentok = '';
        $this->view->msg    = '';
        $uid = UID;
        $this->view->active = $this->model->indexGetData($uid);
        $items         = explode("/", remainCredit($uid));
        $this->view->fishAmount    = $items[0];
        $this->view->fishPending   = $items[1];
        $this->view->onlineAmount  = $items[2];
        $this->view->onlinePending = $items[3];
        $this->view->amountPending = $items[4];
        $this->view->adsPending    = $items[5];
        $this->view->adsCost       = $items[6];
        $this->view->remainCredit  = $items[7];
        $this->view->fishGift      = $items[8];

        if(isset($_POST['send']))
        {
            $ret = $this->model->indexSendEmail();
            $this->view->sentok = $ret[1];
            $this->view->msg    = $ret[0];
            
        }
        $this->view->render('desktop/index',$data,1); 
    }
    function insertads($pa=0,$pb=0)
    {                         
        $data='';
        $userId                    = UID;
        $this->view->star_dis      = 'disabled';
        $this->view->link_dis      = 'disabled';
        $this->view->linkdiv       = 'none';
        $this->view->sp            = "inline";
        $this->view->subject       = '';
        $this->view->adsprice      = '';
        $this->view->adscost       = '';
        $this->view->cost          = 0;
        $this->view->title         = '';
        $this->view->comment       = '';
        $this->view->keyword       = '';
        $this->view->adsprice      = '';
        $this->view->mode          = '';
        $this->view->linkvalue_dis = '';
        $this->view->link_value    = '';
        $this->view->name          = '';
        $this->view->email         = '';
        $this->view->tel           = '';
        $this->view->mobile        = '';
        $this->view->yahooid       = '';
        $this->view->address       = '';
        $this->view->etebar        = '';
        $this->view->msg           = '';
        $this->view->empty         = '';
        $this->view->edit          = '';
        $this->view->kind          = '';
        $this->view->price         = '';
        $url                       = '';
        $hasurl                    = '';
        $star                      = '';
        $timelong                  = '';
        $items                     = explode("/", remainCredit($userId));
        $this->view->etebar        = $items[7];
        
        if($pa == '0')
        {
            $editMode = 0; // Insert New Ads  1
            $this->view->edit          = 0;
        }
        elseif($pa != NUll)
        {
            if($pb != 'edit')
            {
                $editMode = 1; // Edit Ads
                $this->view->edit = 1;
                $this->view->adsid = $pb;
                $ret = $this->model->inserAdsGetAds($pb);
                $this->view->mgid       = $ret['mgid'];
                $this->view->sgid       = $ret['sgid'];
                $this->view->subject    = $ret['subject'];
                $this->view->comment    = $ret['comment'];
                $this->view->keyword    = $ret['keyword'];
                $this->view->price      = $ret['price'];
                $this->view->timelong   = $ret['timelong'];
                $this->view->kind       = $ret['kind'];
                $this->view->hasurl     = $ret['hasurl'];
                $this->view->link_value = $ret['url'];
                $this->view->name       = $ret['name'];
                $this->view->email      = $ret['email'];
                $this->view->tel        = $ret['tel'];
                $this->view->mobile     = $ret['mobile'];
                $this->view->yahooid    = $ret['yahoo'];
                $this->view->address    = $ret['address'];
                
                if($ret['hasurl'] == 1)
                {
                    $this->view->timelong_dis = "disabled";
                }
                if($ret['hasurl'] == 1)
                {
                    $this->view->link_dis      = '';
                    $this->view->linkdiv       = 'inline';
                }
                if($ret['kind'] == 3 OR $ret['kind'] == 4)
                {
                    $this->view->timelong_dis = "disabled";
                    $this->view->sp           = "none";
                    $this->view->linkdiv      = 'none';
                }
                
            }
            else
            {
                header("Location:".URL."desktop/adslist");
            }
        }
        if(isset($_POST['addads']))
        {
            $editMode  = $_POST["editmode"];
            $mgroup    = $_POST["mgroup"];
            $sgroup    = $_POST["sgroup"];
            $subject   = $_POST["subject"];
            $comment   = $_POST["comment"];
            $adsPrice  = $_POST["adsprice"];
            $kind      = $_POST["kind"];
            if(isset($_POST["timelong"])) {$timelong  = $_POST["timelong"];}
            if(isset($_POST["hasurl"]))   {$hasurl    = $_POST["hasurl"];}
            if(isset($_POST["url"]))      {$url       = $_POST["url"];}
            if(isset($_POST["star"]))     {$star      = $_POST["star"];}
            $name      = $_POST["name"];
            $email     = $_POST["email"];
            $tel       = $_POST["tel"];
            $mobile    = $_POST["mobile"];
            $yahooid   = $_POST["yahooid"];
            $address   = $_POST["address"];
            $keyword   = $_POST["keyword"];
            $image     = $_FILES['image']['name'];
            $adsId     = 0;
            if($editMode == 1) $adsId = $_POST["adsid"];
            
            $data = $this->model->inserAdsNewAds($editMode,$adsId,$userId,$mgroup,$sgroup,$subject,$comment,$adsPrice,$kind,$timelong,$hasurl,$url,$star,$name,$email,$tel,$mobile,$yahooid,$address,$keyword,$image);
            $this->view->mgroup   = $data[0];
            $this->view->sgroup   = $data[1];
            $this->view->subject  = $data[2];
            $this->view->comment  = $data[3];
            $this->view->adsPrice = $data[4];
            $this->view->kind     = $data[5];
            $this->view->timelong = $data[6];
            //$this->view->hasurl   = $data[7];
            $this->view->url      = $data[8];
            $this->view->star     = $data[9];
            $this->view->name     = $data[10];
            $this->view->email    = $data[11];
            $this->view->tel      = $data[12];
            $this->view->mobile   = $data[13];
            $this->view->yahooid  = $data[14];
            $this->view->address  = $data[15];
            $this->view->keyword  = $data[16];
            $this->view->msg      = $data[17];
            $this->view->cost     = sefr($data[18]);
            $this->view->edit     = 1;
            if($this->view->kind == 3 OR $this->view->kind == 4) {$this->view->timelong_dis = 'disabled';$this->view->star_dis = '';}
        }
        
        
        $this->view->render('desktop/insertads',$data,1);
    }
    function adslist($pa=0,$pb=0,$pc=0)
    {
        $data='';
        $this->view->searchMode = '';
        $this->view->page = '';
        $this->view->uid = UID;
        if(isset($_POST['search']))
        {
            $word = $_POST['word'];
            header("Location:".URL."desktop/adslist/search/".$word);
        }
        if($pa == '0')
        {
            $this->view->page       = 0;
            $this->view->searchMode = 0;
            $this->view->userMode   = 0;
        }
        elseif($pb == '0')
        {
           $this->view->page       = $pa;
           $this->view->searchMode = 0;
           $this->view->userMode   = 0;
        }
        elseif($pa == 'search')
        {
           $this->view->word       = $pb;
           if($param3 == 0) $this->view->page       = 1;
           if($param3 != 0) $this->view->page       = $pc;
           $this->view->searchMode = 1;
           $this->view->userMode   = 0;
        }
        elseif($pa == 'delete')
        {
            $data='';
            $this->model->adsDelete($pb);
            header("Location:".URL."desktop/adslist");
        }
        elseif($pa == 'refresh')
        {
            $data='';
            $this->model->adsRefresh($pb);
            header("Location:".URL."desktop/adslist");
        }
        $this->view->render('desktop/adslist',$data,1);  
    }
    function message($pa=0,$pb=0)
    {
        $data='';
        $this->view->message = '';
        if($pa == '0')
        {
            
        }
        elseif($pb == '0')
        {
           
        }
        elseif($pa == 'view')
        {
            $ret = $this->model->readMessage($pb);
            $this->view->message = $ret[0]['message'];
        }
        $this->view->render('desktop/message',$data,1); 
    }
    function messageview()
    {
        $data='';
        $this->view->render('desktop/messageview',$data,1); 
    }
    function onlinepay()
    {
        require "include/nusoap.php";
        $data='';
        $this->view->amount='';
        $this->view->msg='';
        $this->view->msg10='';
        $this->view->msg11='';
        $this->view->msg12='';
        $this->view->msg13='';
        $this->view->uid = UID;
        if(isset($_SESSION['bank']) and ( ($_SESSION['bank'] == "parsian") OR ($_SESSION['bank'] == "zarinpal" )))
        {
            $this->view->msg = $this->model->onlinepayback();
        }
        if(isset($_POST['onlinepay']))
        {
            $amount = preg_replace('/[^\d]/', '', $_POST['amount']);
            $getway = $_POST['getway'];
            $this->view->msg = $this->model->onlinepay($amount,$getway);
        }
        $this->view->render('desktop/onlinepay',$data,1);
    }
    function registerfish()
    {
        $data='';
        $this->view->resid = '';
        $this->view->amount = '';
        $this->view->k10 = '';
        $this->view->sender='';
        $this->view->comment='';
        $this->view->msg='';
        $this->view->msg10='';
        $this->view->msg11='';
        $this->view->msg12='';
        $this->view->msg13='';
        $this->view->fishdate='';
        $this->view->uid = $uid = UID;

        if(isset($_POST['regfish']))
        {
            $this->view->k10 = 1;
            $uid      = UID;
            $aid      = $_POST["account"];
            $resid    = $_POST["resid"];
            $amount   = $_POST["amount"];
            $fishdate = $_POST["date"];
            $sender     = $_POST["sender"];
            $comment  = $_POST["comment"];
            $tig = time();

            $ti      = date('Y-m-d',time());
            $tij     = g_to_j($ti);
            $date3   = explode("-",$tij);

            $dte1 = 0;$dte2 = 0;$dte3 = 0;$dte4 = 0;
            $date2   = explode("-",$fishdate);
            if($date2[0] > 1390 and $date2[0] <= $date3[0]) $dte1 = 1;
            if($date2[1] >= 1 and $date2[1] <= 12) $dte2 = 2;
            if($date2[2] >= 1 and $date2[2] <= 31) $dte3 = 3;
            if($dte1 == 1 and $dte2 == 2 and $dte3 == 3) $dte4 = 4;

            $er = 0;
            if($resid == NULL)  { $this->view->msg10 = "<font color=red>شماره رسید را وارد نمایید</font>";$er = 1; }
            if($amount == NULL) { $this->view->msg11 = "<font color=red>مبلغ را وارد نمایید</font>";$er = 1; }
            if($sender == NULL) { $this->view->msg12 = "<font color=red>نام واریز کننده را وارد نمایید</font>";$er = 1; }
            if($dte4 == 0)      { $this->view->msg13 = "<font color=red>تاریخ را صحیح وارد نمایید</font>";$er = 1; }
            $this->view->fishdate=$fishdate;
            if($er == 0)
            {
                $k10 = 0;
                $this ->view->msg  = $this->model->registerFish($aid,$uid,$fishdate,$tig,$resid,$amount,$sender,$comment);
            }

        }
        $this->view->render('desktop/registerfish',$data,1); 
    }
    function resetpassword()
    {
        $data='';
        $this->view->msg = '';
        $this->view->msg10 = '';
        $this->view->msg11 = '';
        $this->view->msg12 = '';
        $this->view->msg13 = '';
        $userId = UID;
        if(isset($_POST['changePassword']))
        {
            $er = 0;
            $currentPassword = $_POST["currentPassword"];
            $newPassword     = $_POST["newPassword"];
            $renewPassword   = $_POST["renewPassword"];

            if($currentPassword  == NULL) { $this->view->msg10 = "<font color=red>کلمه عبور فعلی را وارد نمایید</font>";$er = 1; }
            if($newPassword      == NULL) { $this->view->msg11 = "<font color=red>کلمه عبور جدید را وارد کنید</font>";$er = 1; }
            if($renewPassword    == NULL) { $this->view->msg12 = "<font color=red>تکرار کلمه عبور جدید را وارد نمایید</font>";$er = 1; }
            if($er == 0)
            {
                $this ->view->msg  = $this->model->resetPassword($currentPassword,$newPassword,$renewPassword);
            }	
        }

        $this->view->render('desktop/resetpassword',$data,1); 
    }
    function setting()
    {
        $data='';
        $this ->view->msg = '';
        if(isset($_POST['updatesetting']))
        {
            $name   = $_POST['name'];
            $vitrin = $_POST['vitrin'];
            $this ->view->msg  = $this->model->setting($name,$vitrin);
        }
        $ret  = $this->model->getSetting(UID);
        $this ->view->name   = $ret['name'];
        $this ->view->vitrin = $ret['vitrin'];  
        $this->view->render('desktop/setting',$data,1); 
    }
    function logout()
    {
        session_start();
        unset($_SESSION['SUB_USER_ID']);
        header("Location: ../index.php");
    }
}
?>