<?php

class register extends Controller
{
    function __construct() 
    {
        parent::__construct();
        
    }
    
    public function Index($data=array())
    {
        $this->view->render('register/index',$data,1); 
    }
    public function Active($data=array())
    {
        $this->view->render('register/activation',$data,1); 
    }
    public function Confirm($data=array())
    {
        $this->view->render('register/confirmation',$data,1); 
    }
    function add()
    {	
        $this->Index();  
    }
    function activation()
    {	
        $this->Active();  
    }
    function confirmation($code)
    {	
        $data = $this->model->confirmation($code);
        $this->view->msg = $data;
        $this->Confirm();  
    }
}
?>