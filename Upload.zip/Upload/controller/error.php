<?php
class error extends Controller
{
    function __construct() 
    {
        parent::__construct();
    }
    public function Not_Exist_Function()
    {
       header("Location: ../index.php");
    }
    public function Not_Exist_Controller(){
        header("Location: ../index.php");
    }
}