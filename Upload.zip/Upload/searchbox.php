<form action='' method='post'>
	<input name="word" id="word" maxlength="20" class="inputbox" size="20" value="جستجو - عبارتی وارد کرده و کلید اینتر را بزنید" onblur="if(this.value=='') this.value='جستجو - عبارتی وارد کرده و کلید اینتر را بزنید';" onfocus="if(this.value=='جستجو - عبارتی وارد کرده و کلید اینتر را بزنید') this.value='';" type="text" />
	<input name="option" value="com_search" type="hidden" />
	<input name="task" value="search" type="hidden" />
	<input name="search" value="جستجو" type="submit" class="test" />
</form>
