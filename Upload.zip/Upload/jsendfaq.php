<?php	
include "include/config.php";

$m = $_GET["param"];
$y = explode(',',$m);
$qName  = $y[0];
$qEmail = $y[1];
$qText  = $y[2];
$userId = $y[3];
$adsId =  $y[4];
$result = 0;
if($qEmail == NULL) $qEmail = -1;
$date = time();
if($qName == NULL or $qText == NULL) $result = 1;
   
$sql = "INSERT INTO ".TABLE_PREFIX."message VALUES (NULL , '$userId', '$adsId', '$qName', '$qEmail', '$qText', '$date', '0' )";
if($result == 0)
{
	if($db->sql_query($sql))
	{
		$result = 2;
	}
	else
	{
		
        $result = mysql_error();
	}
}

echo $result;

?>