<?php
if(!file_exists("install/index.php") AND file_exists("include/config.php"))
{
require 'include/config.php';
require 'include/Bootstrap.php';
require 'lib/Database.php';
require 'lib/Controller.php';
require 'lib/View.php';
require 'lib/Model.php';
require 'include/db.php';
require 'visit.php';
require 'include/img.php';
$app = new Bootstarp();
}
else
{
	echo "You Must Install OpenAds Or remove Install directory";
	echo "<br/>";
	echo "<a href='install/install'>For install OpenAds click hear</a>";
}
?>