<?php	
include "include/config.php";
$adsprice='';
$m = $_GET["param"];
$y = explode(',',$m);
$kind   = $y[0];
$hasurl = $y[1];
$star   = $y[2];

$star_price   = Setting::GetSetting(2);
$link_price   = Setting::GetSetting(3);
$ads_sp_price = Setting::GetSetting(4);

if($kind == 1 OR $kind == 2) {$adsprice = $hasurl * $link_price;}
if($kind == 3 OR $kind == 4) {$adsprice = $ads_sp_price + $hasurl * $link_price + $star * $star_price;}

echo $adsprice.",".$hasurl.",".$kind;

?>