<?php
$ip = $_SERVER['REMOTE_ADDR'];
$timestamp = time();
$ref = $_SERVER['HTTP_REFERER'];
$ex  = explode('/',$ref);

$myIp1       = Setting::GetSetting(14);
$myIp2       = Setting::GetSetting(15);

$www = substr(SITE_ADDRESS,0,4);
$len = strlen(SITE_ADDRESS);
if($www == 'www.')
{
	$address  = SITE_ADDRESS;
	$address1 = substr(SITE_ADDRESS,4,$len-4);
}
else
{
	$address  = 'www.'.SITE_ADDRESS;
	$address1 =  SITE_ADDRESS;
}

if($ex[2] == $address OR $ex[2] == $address1 OR $ip == $myIp1 OR $ip != $myIp2)
{
  if($ref == NULL) $ref = -1;
	if($db->sql_query("INSERT INTO ".TABLE_PREFIX."visit VALUES (NULL, '2', '$timestamp', '-1', '$ip', '-1', '$ref', '0')"))
	{
	
	}
}
else
{
	if($ref == NULL) $ref = -1;
	if($db->sql_query("INSERT INTO ".TABLE_PREFIX."visit VALUES (NULL, '2', '$timestamp', '-1', '$ip', '-1', '$ref', '0')"))
	{
	
	}
}
?>