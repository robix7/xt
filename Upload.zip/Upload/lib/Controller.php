<?php

class Controller {

    function __construct() {

        $this->view=new View();
    }
    public function Header()
    {
        require 'view/header.php';
    }
    public function Footer()
    {
        require 'view/footer.php';
    }
    public function loadModel($name)
    {
        $path ='model/'.$name.'_model.php';
        if(file_exists($path))
        {
            require $path;
            $filename = $name.'_model';
            $this->model = new $filename();
        }
    }

}

?>