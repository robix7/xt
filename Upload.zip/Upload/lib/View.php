<?php

class View {

    function __construct() 
    {
        
    }
    public function render($name,$data=array(),$show=1)
    {
        //extract($data);
        if($show == 1)
        {
            require 'view/'.$name.'.php';
        }
        else 
        {
            require 'view/'.$name.'.php';
        }
        
    }

}