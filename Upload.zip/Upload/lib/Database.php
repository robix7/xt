<?php

class Database extends PDO
{
    function __construct() 
    {
        parent::__construct(DB_TYPE.':host='.DB_SERVER.';dbname='.DB_DATABASE.';charset='.DB_CHARSET, DB_USERNAME, DB_PASSWORD);
    }
}
?>