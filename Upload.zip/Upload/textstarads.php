<?php
$mgid1=0;$sgid1=0;$currentKind =0;$uid='';
$stars1="";$stars2="";$stars3="";$stars4="";$stars5="";$stars6="";$stars7="";

if(ADS_COL == 3)
{
	$wi = 230;
	$mg = 9;
        $wig = 20;
        $hei = 90;
}
else
{
	$wi = 180;
	$mg = 3;
        $wig = 9;
        $hei = 98;
}
if(isset($this->sgads)) 
{
	$currentKind = 2;
	$sgid1 =$this->sgid;
}
elseif(isset($this->mgads))
{
	$currentKind = 1;
	$mgid1 =$this->mgid;
}
elseif(isset($this->uads))
{
	$currentKind =4;
	$uid1 = $_GET['uid'];
}
else
{
	$currentKind =3;
}
$k = 0;
$u = '';
$n = '';
$lst = '';
$id  = array("0");
$id0 = array("0");
$con = 0;
$result                 = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."setting WHERE id = '1'");
$show_result            = $db->sql_fetcharray($result);
$numberOfAdsOnFirstPage = $show_result['value'];
if($currentKind != 4)  
{
	if($currentKind == 1)
	{
		$cnt   = my_count(TABLE_PREFIX.'advertise','id','status','1','kind','1','mgid',$mgid1,-1,-1) + my_count(TABLE_PREFIX.'advertise','id','status','1','kind','3','mgid',$mgid1,-1,-1);
		$star7 = my_count(TABLE_PREFIX.'advertise','id','star','7','status','1','kind','1','mgid',$mgid1) + my_count(TABLE_PREFIX.'advertise','id','star','7','status','1','kind','3','mgid',$mgid1);
		$star6 = my_count(TABLE_PREFIX.'advertise','id','star','6','status','1','kind','1','mgid',$mgid1) + my_count(TABLE_PREFIX.'advertise','id','star','6','status','1','kind','3','mgid',$mgid1);
		$star5 = my_count(TABLE_PREFIX.'advertise','id','star','5','status','1','kind','1','mgid',$mgid1) + my_count(TABLE_PREFIX.'advertise','id','star','5','status','1','kind','3','mgid',$mgid1);;
		$star4 = my_count(TABLE_PREFIX.'advertise','id','star','4','status','1','kind','1','mgid',$mgid1) + my_count(TABLE_PREFIX.'advertise','id','star','4','status','1','kind','3','mgid',$mgid1);
		$star3 = my_count(TABLE_PREFIX.'advertise','id','star','3','status','1','kind','1','mgid',$mgid1) + my_count(TABLE_PREFIX.'advertise','id','star','3','status','1','kind','3','mgid',$mgid1);
		$star2 = my_count(TABLE_PREFIX.'advertise','id','star','2','status','1','kind','1','mgid',$mgid1) + my_count(TABLE_PREFIX.'advertise','id','star','2','status','1','kind','3','mgid',$mgid1);
		$star1 = my_count(TABLE_PREFIX.'advertise','id','star','1','status','1','kind','1','mgid',$mgid1) + my_count(TABLE_PREFIX.'advertise','id','star','1','status','1','kind','3','mgid',$mgid1);
	}
	if($currentKind == 2)
	{
		$cnt   = my_count(TABLE_PREFIX.'advertise','id','status','1','kind','1','sgid',$sgid1,-1,-1) + my_count(TABLE_PREFIX.'advertise','id','status','1','kind','3','sgid',$sgid1,-1,-1);
		$star7 = my_count(TABLE_PREFIX.'advertise','id','star','7','status','1','kind','1','sgid',$sgid1) + my_count(TABLE_PREFIX.'advertise','id','star','7','status','1','kind','3','sgid',$sgid1);
		$star6 = my_count(TABLE_PREFIX.'advertise','id','star','6','status','1','kind','1','sgid',$sgid1) + my_count(TABLE_PREFIX.'advertise','id','star','6','status','1','kind','3','sgid',$sgid1);
		$star5 = my_count(TABLE_PREFIX.'advertise','id','star','5','status','1','kind','1','sgid',$sgid1) + my_count(TABLE_PREFIX.'advertise','id','star','5','status','1','kind','3','sgid',$sgid1);
		$star4 = my_count(TABLE_PREFIX.'advertise','id','star','4','status','1','kind','1','sgid',$sgid1) + my_count(TABLE_PREFIX.'advertise','id','star','4','status','1','kind','3','sgid',$sgid1);
		$star3 = my_count(TABLE_PREFIX.'advertise','id','star','3','status','1','kind','1','sgid',$sgid1) + my_count(TABLE_PREFIX.'advertise','id','star','3','status','1','kind','3','sgid',$sgid1);
		$star2 = my_count(TABLE_PREFIX.'advertise','id','star','2','status','1','kind','1','sgid',$sgid1) + my_count(TABLE_PREFIX.'advertise','id','star','2','status','1','kind','3','sgid',$sgid1);
		$star1 = my_count(TABLE_PREFIX.'advertise','id','star','1','status','1','kind','1','sgid',$sgid1) + my_count(TABLE_PREFIX.'advertise','id','star','1','status','1','kind','3','sgid',$sgid1);
	}
	if($currentKind == 3)
	{
		$cnt   = my_count(TABLE_PREFIX.'advertise','id','status','1','kind','1',-1,-1,-1,-1) + my_count(TABLE_PREFIX.'advertise','id','status','1','kind','3',-1,-1,-1,-1);
		$star7 = my_count(TABLE_PREFIX.'advertise','id','star','7','status','1','kind','1',-1,-1) + my_count(TABLE_PREFIX.'advertise','id','star','7','status','1','kind','3',-1,-1);
		$star6 = my_count(TABLE_PREFIX.'advertise','id','star','6','status','1','kind','1',-1,-1) + my_count(TABLE_PREFIX.'advertise','id','star','6','status','1','kind','3',-1,-1);
		$star5 = my_count(TABLE_PREFIX.'advertise','id','star','5','status','1','kind','1',-1,-1) + my_count(TABLE_PREFIX.'advertise','id','star','5','status','1','kind','3',-1,-1);
		$star4 = my_count(TABLE_PREFIX.'advertise','id','star','4','status','1','kind','1',-1,-1) + my_count(TABLE_PREFIX.'advertise','id','star','4','status','1','kind','3',-1,-1);
		$star3 = my_count(TABLE_PREFIX.'advertise','id','star','3','status','1','kind','1',-1,-1) + my_count(TABLE_PREFIX.'advertise','id','star','3','status','1','kind','3',-1,-1);
		$star2 = my_count(TABLE_PREFIX.'advertise','id','star','2','status','1','kind','1',-1,-1) + my_count(TABLE_PREFIX.'advertise','id','star','2','status','1','kind','3',-1,-1);
		$star1 = my_count(TABLE_PREFIX.'advertise','id','star','1','status','1','kind','1',-1,-1) + my_count(TABLE_PREFIX.'advertise','id','star','1','status','1','kind','3',-1,-1);
	}
	if($star7 > 0)
	{
		if($currentKind ==1) $result7  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."advertise WHERE star = 7 and status = 1 and (kind = 1 OR kind = 3) and mgid = '$mgid1'" );
		if($currentKind ==2) $result7  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."advertise WHERE star = 7 and status = 1 and (kind = 1 OR kind = 3) and sgid = '$sgid1'" );
		if($currentKind ==3) $result7  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."advertise WHERE star = 7 and status = 1 and (kind = 1 OR kind = 3) " );
		while($show_result7=$db->sql_fetcharray($result7))
		{
			$update   = $show_result7['update'];
			$timelong = $show_result7['timelong'];
			
			$exp    = time() - ($timelong*86400);
			if($update > $exp)
			{
				$k++;
				$id7[$k]      = $show_result7['id'];
				$con++;
			}
		}
		if($con > 0) {shuffle($id7);$id = array_merge($id,$id7);}
		$stars7 = $k;
	}
	if($star6 > 0)
	{
		$k=0;
		$con=0;
		if($currentKind ==1) $result6  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."advertise WHERE star = 6 and status = 1 and (kind = 1 OR kind = 3) and mgid = '$mgid1'" );
		if($currentKind ==2) $result6  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."advertise WHERE star = 6 and status = 1 and (kind = 1 OR kind = 3) and sgid = '$sgid1'" );
		if($currentKind ==3) $result6  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."advertise WHERE star = 6 and status = 1 and (kind = 1 OR kind = 3)" );
		while($show_result6=$db->sql_fetcharray($result6))
		{
			$update   = $show_result6['update'];
			$timelong = $show_result6['timelong'];
			
			$exp    = time() - ($timelong*86400);
			if($update > $exp)
			{
				$k++;
				$id6[$k]      = $show_result6['id'];
				$con++;
			}
		}
		if($con > 0) {shuffle($id6);$id = array_merge($id,$id6);}
		$stars6 = $k;
	}
	if($star5 > 0)
	{
		$k=0;
		$con=0;
		if($currentKind ==1) $result5  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."advertise WHERE star = 5 and status = 1 and (kind = 1 OR kind = 3) and mgid = '$mgid1'" );
		if($currentKind ==2) $result5  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."advertise WHERE star = 5 and status = 1 and (kind = 1 OR kind = 3) and sgid = '$sgid1'" );
		if($currentKind ==3) $result5  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."advertise WHERE star = 5 and status = 1 and (kind = 1 OR kind = 3)" );
		while($show_result5=$db->sql_fetcharray($result5))
		{
			$update   = $show_result5['update'];
			$timelong = $show_result5['timelong'];
			
			$exp    = time() - ($timelong*86400);
			if($update > $exp)
			{
				$k++;
				$id5[$k]      = $show_result5['id'];
				$con++;
			}
		}
		if($con > 0) {shuffle($id5);$id = array_merge($id,$id5);}
		$stars5 = $k;
	}
	if($star4 > 0)
	{
		$k=0;
		$con=0;
		if($currentKind ==1) $result4  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."advertise WHERE star = 4 and status = 1 and (kind = 1 OR kind = 3) and mgid = '$mgid1'" );
		if($currentKind ==2) $result4  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."advertise WHERE star = 4 and status = 1 and (kind = 1 OR kind = 3) and sgid = '$sgid1'" );
		if($currentKind ==3) $result4  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."advertise WHERE star = 4 and status = 1 and (kind = 1 OR kind = 3)" );
		while($show_result4=$db->sql_fetcharray($result4))
		{
			$k++;
			$id4[$k]      = $show_result4['id'];
		} 
		shuffle($id4);
		$id = array_merge($id,$id4);while($show_result4=$db->sql_fetcharray($result4))
		{
			$update   = $show_result4['update'];
			$timelong = $show_result4['timelong'];
			
			$exp    = time() - ($timelong*86400);
			if($update > $exp)
			{
				$k++;
				$id4[$k]      = $show_result4['id'];
				$con++;
			}
		}
		if($con > 0) {shuffle($id4);$id = array_merge($id,$id4);}
		$stars4 = $k;
	}
	if($star3 > 0)
	{
		$k=0;
		$con=0;
		if($currentKind ==1) $result3  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."advertise WHERE star = 3 and status = 1 and (kind = 1 OR kind = 3) and mgid = '$mgid1'" );
		if($currentKind ==2) $result3  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."advertise WHERE star = 3 and status = 1 and (kind = 1 OR kind = 3) and sgid = '$sgid1'" );
		if($currentKind ==3) $result3  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."advertise WHERE star = 3 and status = 1 and (kind = 1 OR kind = 3)" );
		while($show_result3=$db->sql_fetcharray($result3))
		{
			$update   = $show_result3['update'];
			$timelong = $show_result3['timelong'];
			
			$exp    = time() - ($timelong*86400);
			if($update > $exp)
			{
				$k++;
				$id3[$k]      = $show_result3['id'];
				$con++;
			}
		}
		if($con > 0) {shuffle($id3);$id = array_merge($id,$id3);}
		$stars3 = $k;
	}
	if($star2 > 0)
	{
		$k=0;
		$con=0;
		if($currentKind ==1) $result2  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."advertise WHERE star = 2 and status = 1 and (kind = 1 OR kind = 3) and mgid = '$mgid1'" );
		if($currentKind ==2) $result2  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."advertise WHERE star = 2 and status = 1 and (kind = 1 OR kind = 3) and sgid = '$sgid1'" );
		if($currentKind ==3) $result2  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."advertise WHERE star = 2 and status = 1 and (kind = 1 OR kind = 3)" );
		while($show_result2=$db->sql_fetcharray($result2))
		{
			$update   = $show_result2['update'];
			$timelong = $show_result2['timelong'];
			
			$exp    = time() - ($timelong*86400);
			if($update > $exp)
			{
				$k++;
				$id2[$k]      = $show_result2['id'];
				$con++;
			}
		}
		if($con > 0) {shuffle($id2);$id = array_merge($id,$id2);}
		$stars2 = $k;
	}
	if($star1 > 0)
	{
		$k=0;
		$con=0;
		if($currentKind ==1) $result1  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."advertise WHERE star = 1 and status = 1 and (kind = 1 OR kind = 3) and mgid = '$mgid1'" );
		if($currentKind ==2) $result1  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."advertise WHERE star = 1 and status = 1 and (kind = 1 OR kind = 3) and sgid = '$sgid1'" );
		if($currentKind ==3) $result1  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."advertise WHERE star = 1 and status = 1 and (kind = 1 OR kind = 3)" );
		while($show_result1=$db->sql_fetcharray($result1))
		{
			$update   = $show_result1['update'];
			$timelong = $show_result1['timelong'];
			
			$exp    = time() - ($timelong*86400);
			if($update > $exp)
			{
				$k++;
				$id1[$k]      = $show_result1['id'];
				$con++;
			}
		}
		if($con > 0) {shuffle($id1);$id = array_merge($id,$id1);}
		$stars1 = $k;
	}

	$sum      = $stars1 + $stars2 + $stars3 + $stars4 + $stars5 + $stars6 + $stars7;
        
	$reminder1 = $numberOfAdsOnFirstPage - $sum;
	$reminder2 = $cnt - $sum;
	$reminder = min($reminder1,$reminder2);
	if($reminder > 0)
	{
		if($sum < $numberOfAdsOnFirstPage)
		{
			$k=0;
			if($currentKind ==1) $result0  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."advertise WHERE star = 0 and status = 1 and (kind = 1 OR kind = 3) and mgid = '$mgid1'" );
			if($currentKind ==2) $result0  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."advertise WHERE star = 0 and status = 1 and (kind = 1 OR kind = 3) and sgid = '$sgid1'" );
			if($currentKind ==3) $result0  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."advertise WHERE star = 0 and status = 1 and (kind = 1 OR kind = 3)" );
			while($show_result0=$db->sql_fetcharray($result0))
			{
                                $update   = $show_result0['update'];
				$timelong = $show_result0['timelong'];
				
				$exp    = time() - ($timelong*86400);
				if($update > $exp)
				{
					if($k > $reminder) break;
					$id0[$k]      = $show_result0['id'];
                                        $k++;
					$con++;
				}
			}
			if($con > 0) {shuffle($id0);$id = array_merge($id,$id0);}
		}
	}
	$sum = count($id)-1;
	if($sum > $numberOfAdsOnFirstPage) $sum = $numberOfAdsOnFirstPage;
	$maxrow = floor($sum / 3);
	if($sum < 3)
	{
		$maxads = $sum;
	}
	else
	{
		$maxads = $sum;
	}
}
else
{
	$result  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."advertise WHERE uid = $uid1 and status = 1 ORDER BY star DESC " );
	while($show_result = $db->sql_fetcharray($result))
	{
		$k++;
		$id[$k]      = $show_result['id'];
	}
	$sum = count($id)-1;
	$maxads = $sum;
}
for($n=1;$n<=$sum;$n++)
{
        if($n > $maxads) break;
	$result      = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."advertise WHERE id = '$id[$n]' " );
	$show_result = $db->sql_fetcharray($result);
	$subject     = $show_result['subject'];
        $comment     = $show_result['comment'];
	$star        = $show_result['star'];
	$update      = $show_result['update'];
	$timelong    = $show_result['timelong'];
	$email       = $show_result['email'];
	?>
	<div class="side-deal secondary" style="width:<?php echo $wi; ?>px!important;margin:<?php echo $mg; ?>px" >
		<div style="padding-top:5px;">
			<div align="center">
                            <img alt="stars" src="<?php echo URL; ?>template/default/image/star_v_<?php echo $star; ?>.gif" width="70" height="9" />
			</div>	
			<div style="text-align:center;padding-top:15px;height:15px;">
                            <a href="<?php echo URL; ?>ads/view/<?php echo $id[$n]."/".space_rep($subject);?>">
                                <?php   echo $subject; ?>
                            </a>
			</div>
			<div style="text-align:center;padding-top:30px">
                            <div class="side-deal secondary" style="width:<?php echo $wi-$wig; ?>px!important;height:<?php echo $hei; ?>px;margin:<?php echo $mg; ?>px" >    
                            <?php 
                                    if(strlen($comment) < 360)
                                    {
                                        echo strip_tags($comment);
                                    }
                                    else
                                    {
                                        for($ii = 200; $ii < 420; $ii++)
                                        {
                                            $uuu = substr($comment,$ii,1);
                                            if($uuu == " ")
                                            {
                                                    $mn = $ii;
                                                    break;
                                            }
                                        }
                                        $comment = substr($comment,0,$mn);
                                        echo strip_tags($comment);
                                    }
                                    ?>
			</div>
                        </div>
		</div>
	</div>
	<?php
}
?>