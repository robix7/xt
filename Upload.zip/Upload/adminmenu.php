<?php
$admin='';$adslist='';$fish='';$onlinepay='';$setting='';$addmenu='';$content='';$adsmaingroup='';$adssubgroup='';$accounts='';
$onlinepayaccount='';$userlist='';$adminfooter='';$searchquery='';$keyword='';$amar ='';$visitor='';$emailtemplate='';
$email='';$rq ='';$resetpassword='';

$pt2 =  $_GET['url'];
$pt2 = trim($pt2,'/');
$pt2 = explode('/', $pt2);
$current  = $pt2[1];



switch($current)
{
	case 'admin': 				$admin 				= 'active';break;
	case 'adslist': 			$adslist			= 'active';break;
	case 'fish': 				$fish 				= 'active';break;
	case 'onlinepay':			$onlinepay 			= 'active';break;
	case 'setting':				$setting 			= 'active';break;
    case 'menu':				$menu 	    		= 'active';break;
	case 'content':				$content			= 'active';break;
	case 'adsmaingroup':		$adsmaingroup 		= 'active';break;
	case 'adssubgroup':			$adssubgroup 		= 'active';break;
    case 'account':			    $account 			= 'active';break;
	case 'onlinepayaccount':	$onlinepayaccount	= 'active';break;
	case 'userlist':			$userlist 			= 'active';break;
	case 'adminfooter':			$adminfooter		= 'active';break;
	case 'amar':				$amar 				= 'active';break;
	case 'visitor':				$visitor 			= 'active';break;
	case 'emailtemplate':		$emailtemplate		= 'active';break;
	case 'email':				$email				= 'active';break;
	case 'rq':					$rq 				= 'active';break;
	case 'resetpassword':		$resetpassword 		= 'active';break;
}

?>
<div id="ja-right" class="column sidebar" style="width:20%">
	<div class="ja-colswrap clearfix ja-r1">
		<div class="ja-col  column">
			<div class="ja-module ja-box-br module" id="Mod60">
				<div class="ja-box-bl">
					<div class="ja-box-tr">
						<div class="ja-box-tl clearfix">
							<?php
						if(isset($_SESSION['SUB_ADMIN_ID'])) 
						{
							?>
							<h3><span>فهرست</span></h3>
							<div class="jamod-content ja-box-ct clearfix">
								<div id='cssmenu'>
									<ul>
										<li class='<?php echo $admin; ?>'>
											<a href="<?php echo URL; ?>admin/admin">صفحه نخست</a>
										</li>
										<li class='<?php echo $adslist; ?>'>
											<a href="<?php echo URL; ?>admin/adslist">لیست آگهی ها</a>
										</li>
										<li class='<?php echo $fish; ?>'>
											<a href="<?php echo URL; ?>admin/fish">فیش های بانکی</a>
										</li>
										<li class='<?php echo $onlinepay; ?>'>
											<a href="<?php echo URL; ?>admin/onlinepay">پرداخت های آنلاین</a>
										</li>
										<li class='<?php echo $account; ?>'>
											<a href="<?php echo URL; ?>admin/account">حسابهای بانکی</a>
										</li>
										<li class='<?php echo $onlinepayaccount; ?>'>
											<a href="<?php echo URL; ?>admin/onlinepayaccount">روش های پرداخت آنلاین</a>
										</li>
										<li class='<?php echo $content; ?>'>
											<a href="<?php echo URL; ?>admin/content">ایجاد محتوا</a>
										</li>
										<li class='<?php echo $menu; ?>'>
											<a href="<?php echo URL; ?>admin/menu">فهرست</a>
										</li>
										<li class='<?php echo $adsmaingroup; ?>'>
											<a href="<?php echo URL; ?>admin/adsmaingroup">گروه اصلی نیازمندی ها</a>
										</li>
										<li class='<?php echo $adssubgroup; ?>'>
											<a href="<?php echo URL; ?>admin/adssubgroup">گروه فرعی نیازمندی ها</a>
										</li>
										<li class='<?php echo $userlist; ?>'>
											<a href="<?php echo URL; ?>admin/userlist">کاربران</a>
										</li>
										<li class='<?php echo $adminfooter; ?>'>
											<a href="<?php echo URL; ?>admin/adminfooter">پاصفحه</a>
										</li>
										<li class='<?php echo $emailtemplate; ?>'>
											<a href="<?php echo URL; ?>admin/emailtemplate">ایجاد نامه</a>
										</li>
										<li class='<?php echo $email; ?>'>
											<a href="<?php echo URL; ?>admin/email">ارسال ایمیل</a>
										</li>
										<li class='<?php echo $rq; ?>'>
											<a href="<?php echo URL; ?>admin/rq">سوال تصادفی</a>
										</li>
										<li class='<?php echo $amar; ?>'>
											<a href="<?php echo URL; ?>admin/amar">آمار</a>
										</li>
										<li class='<?php echo $visitor; ?>'>
											<a href="<?php echo URL; ?>admin/visitor">بازدید کننده ها</a>
										</li>
										<li class='<?php echo $setting; ?>'>
											<a href="<?php echo URL; ?>admin/setting">تنظیمات</a>
										</li>
										<li class='<?php echo $resetpassword; ?>'>
											<a href="<?php echo URL; ?>admin/resetpassword">تغییر کلمه عبور</a>
										</li>
										<li>
											<a href="logout">خروج</a>
										</li>
									</ul>
								</div>									
							</div>
							<?php
						}
						else
						{
							?>
							<h3><span>ورود مدیریت</span></h3>
							<div class="jamod-content ja-box-ct clearfix">
								<form action="" method="post">
									<div style="color:red;text-align:justify">
									</div>
									<fieldset class="input">
										<p id="form-login-username">
											<label id="username">
												نام کاربری<br>
												<input name="username" id="username" class="inputbox" alt="username" size="18" type="text">
											</label>
										</p>
										<p id="form-login-password">
											<label id="passwd">
												رمزعبور<br>
												<input name="password" id="password" class="inputbox" size="18" alt="password" type="password">
											</label>
										</p>
										<input name="login" class="button" value="ورود" type="submit">
									</fieldset>			
								</form>
							</div>
							<?php
							}
							?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>