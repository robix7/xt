<?php
class content_model extends Model
{
    function __construct()
    {
        parent::__construct();
    }
    function page($id)
    {
        
		$query = $this->db->prepare("SELECT * FROM ".TABLE_PREFIX."content WHERE id = $id ");
        $query->setFetchMode(PDO::FETCH_NUM);
        $query->execute();
		$data = $query->fetch();
		$count = $query->rowCount();
		if($count == 1)
		{
			return $data;
		}
		else
		{
			header("Location: ../../index.php");	
		}
    }
   
}
?>