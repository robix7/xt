<?php
class desktop_model extends Model
{
    function __construct()
    {
        parent::__construct();
    }
    function indexGetData()
    {
        $uid = $_SESSION['SUB_USER_ID'];
        $query = $this->db->prepare("SELECT * FROM ".TABLE_PREFIX."user WHERE id = :uid ");
        $query->setFetchMode(PDO::FETCH_ASSOC);
        $query->bindParam(':uid',$uid);
        $query->execute();
        $data = $query->fetch();
        return $active = $data['active'];
    }
    function indexSendEmail()
    {
        $uid         = UID;
        $siteAddress = URL;
        $siteEmail   = Setting::GetSetting(12);
        $siteName    = Setting::GetSetting(5);

        $query = $this->db->prepare("SELECT * FROM ".TABLE_PREFIX."user WHERE id = :uid");
        $query->setFetchMode(PDO::FETCH_ASSOC);
        $query->bindParam(':uid',$uid);
        $query->execute();
        $data = $query->fetch();
        $active      = $data['active'];
        $code        = $data['code'];
        $email       = $data['email'];

        $to  = $email;
        $to1 = $siteEmail;

        $url = $siteAddress;
        $subject="ارسال مجدد ایمیل فعال سازی";
        $header="from: $siteName <$siteEmail>";
        $message="
        لینک فعال سازی  
        برای فعال سازی ثبت نام روی لینک زیر کلیک کنید 
        $siteAddress"."register/confirmation/$code";
        $sentmail = mail($to,$subject,$message,$header);
        if($sentmail)
        {
            $ret[0] = "<strong><font color=green>ایمیل فعال سازی ارسال شد. به ایمیل خود مراجعه کنید و بر روی لینک ارسالی کلیک کنید تا ایمیل شما تایید شود.</font><strong>"; 
            $ret[1] = 1;
        }
        else
        {
            $ret[0] = "<strong><font color=red>مشکل در ارسال ایمیل. لحظاتی دیگر تلاش نمایید</font></strong>";     
            $ret[1] = 0;
        }
    }
    function inserAdsNewAds($editMode,$adsId,$userId,$mgroup,$sgroup,$subject,$comment,$adsPrice,$kind,$timelong,$hasurl,$url,$star,$name,$email,$tel,$mobile,$yahooid,$address,$keyword,$image)
    {
        $query = $this->db->prepare("SELECT * FROM ".TABLE_PREFIX."advertise WHERE id = :adsId ");
        $query->setFetchMode(PDO::FETCH_ASSOC);
        $query->bindParam(':adsId',$adsId);
        $query->execute();
        $data  = $query->fetch();
        $oldKind = $data['kind'];
        
        $image     = $_FILES['image']['name'];
        $msg = '';
        $error  = 0;
        $update = $crdate = time();
        if($kind == 3 OR $kind == 4) {$timelong = 30;$spdate=$update;}
        $items = explode("/", remainCredit($userId));
        $etebar        = $items[7];
        $star_price   = Setting::GetSetting(2);
        $link_price   = Setting::GetSetting(3);
        $ads_sp_price = Setting::GetSetting(4);
        if($kind == 1 OR $kind == 2) {$cost = $hasurl * $link_price;}
        if($kind == 3 OR $kind == 4) {$cost = $ads_sp_price + $hasurl * $link_price + $star * $star_price;}
        if($cost > $etebar)
        {
            $msg = "<font color=red>اعتبار شما برای درج این آگهی کافی نیست</font>";
        }
        else
        {
            if($kind == 2 OR $kind == 4) // The ads has image
            {
                //$filename  = stripslashes($image);
                $filename  = stripslashes($_FILES['image']['name']);
                $extension = getExtension($filename);
                $extension = strtolower($extension);

                $size   = getimagesize($_FILES['image']['tmp_name']);
                $sizekb = filesize($_FILES['image']['tmp_name']);
                if (($extension != "jpg") && ($extension != "jpeg") && ($extension != "png"))
                {
                    $msg   = "<font color=red>فرمت عکس ناشناخته است</font>";
                    $error = 1;
                }
                if ($sizekb > MAX_SIZE*1024)
                {
                    $msg = "<font color=red>حجم عکس بیش از حد مجاز است</font>";
                    $error = 1;
                }
            }
            if($error == 0)
            {
                if($editMode == 1)
                {
                    $query = $this->db->prepare("UPDATE ".TABLE_PREFIX."advertise SET `mgid` = '$mgroup', `sgid` = '$sgroup', `subject` = '$subject',
                                                `comment` = '$comment', `price` = '$adsPrice', `cost` = '$cost',
                                                `kind` = '$kind', `status` = '0', `star` = '$star', `hasimage` = '1',
                                                `update` = '$update', `timelong` = '$timelong', `url` = '$url',
                                                `hasurl` = '$hasurl',`name` = '$name', `email` = '$email',
                                                `tel` = '$tel',`mobile` = '$mobile', `yahoo` = '$yahooid',
                                                `address` = '$address',`keyword` = '$keyword' WHERE `id` = '$adsId' ");
                }
                else
                {
                    $query = $this->db->prepare("INSERT INTO ".TABLE_PREFIX."advertise VALUES (NULL , '$userId', '$mgroup',
                                                '$sgroup','$subject', '$comment','$adsPrice','$cost',
                                                '$kind','0', '$star', '1', '$crdate','$update','$spdate', '0',
                                                '$timelong', '$url', '$hasurl','$name', '$email', '$tel',
                                                '$mobile', '$yahooid','$address', '$keyword', '0', '0')");
                }
                if($res = $query->execute())
                {
                    $query = $this->db->prepare("SELECT MAX(id) FROM ".TABLE_PREFIX."advertise");
                    $query->execute();
                    $data  = $query->fetch();
                    $adsId = $data[0];
                    if(($editMode == 0 AND ($kind == 3 OR $kind == 4)) OR ($editMode == 1 AND ($kind == 3 OR $kind == 4) AND ($oldKind == 1 OR $oldKind == 2)))
                    {
                        $query = $this->db->prepare("INSERT INTO ".TABLE_PREFIX."adscost VALUES (NULL , '$userId', '$adsId', '$cost', '$crdate', '0')");
                        $res1  = $query->execute();
                    }
                    if($kind == 2 OR $kind == 4)
                    {
                        $image_name=$adsId.'.'.$extension;
                        $newname="images/ads/temp/".$image_name;
                        $copied = copy($_FILES['image']['tmp_name'], $newname);
                        if (!$copied)
                        {
                                $msg = "<font color = red>انتقال عکس ناموفق بود</font>";
                        }
                        else
                        {
                            $thumb_name_small = 'images/ads/small/'.$image_name;
                            $thumb=make_thumb($newname,$thumb_name_small,50,50);

                            $thumb_name_med   = 'images/ads/med/'.$image_name;
                            $thumb=make_thumb($newname,$thumb_name_med,120,84);

                            $thumb_name_big   = 'images/ads/big/'.$image_name;
                            $thumb=make_thumb($newname,$thumb_name_big,250,400);
                            unlink('images/ads/temp/'.$adsId.'.jpg');
                            $msg = "<font color = green>انتقال عکس موفق بود</font>";
                            
                        }
                    }
                    header("Location:".URL."desktop/adslist");                    
                }
            }
        }
        $data[0]  = $mgroup;
        $data[1]  = $sgroup;
        $data[2]  = $subject;
        $data[3]  = $comment;
        $data[4]  = $adsPrice;
        $data[5]  = $kind;
        $data[6]  = $timelong;
        $data[7]  = $hasurl;
        $data[8]  = $url;
        $data[9]  = $star;
        $data[10] = $name;
        $data[11] = $email;
        $data[12] = $tel;
        $data[13] = $mobile;
        $data[14] = $yahooid;
        $data[15] = $address;
        $data[16] = $keyword;
        $data[17] = $msg;
        $data[18] = $cost;
        return $data;
    }
    function inserAdsGetAds($id)
    {
        $cnt = my_count(TABLE_PREFIX.'advertise','id','id',$id,'uid',UID,-1,-1,-1,-1);
        if($cnt == 0)
        {
            header("Location:".URL."desktop/adslist");
        }
        else
        {
            $query = $this->db->prepare("SELECT * FROM ".TABLE_PREFIX."advertise WHERE id = :id ");
            $query->setFetchMode(PDO::FETCH_ASSOC);
            $query->bindParam(':id',$id);
            $query->execute();
            $data = $query->fetchAll();
            return $data[0];
        }
    }
    function adsDelete($id)
    {
        $query = $this->db->prepare("DELETE FROM ".TABLE_PREFIX."advertise WHERE id = :id ");
        $query->bindParam(':id',$id);
        $res = $query->execute();
        if($res)
        {
            if(file_exists("images/ads/big/$id.jpg"))   unlink("images/ads/big/$id.jpg");
            if(file_exists("images/ads/med/$id.jpg"))   unlink("images/ads/med/$id.jpg");
            if(file_exists("images/ads/small/$id.jpg")) unlink("images/ads/small/$id.jpg");
            if(file_exists("images/ads/temp/$id.jpg"))  unlink("images/ads/temp/$id.jpg");		

            $gcnt = my_count(TABLE_PREFIX.'galery','id','adsid',$id,-1,-1,-1,-1,-1,-1);

            if($gcnt > 0)
            {
                
                $query = $this->db->prepare("SELECT id,name FROM ".TABLE_PREFIX."galery WHERE adsid = :id ");
                $query->setFetchMode(PDO::FETCH_ASSOC);
                $query->bindParam(':id',$id);
                $query->execute();
                $data = $query->fetchAll();
                for($i=0;$i <= count($data);$i++)
                {
                    $gid  = $data[$i][id];
                    $name = $data[$i][name];
                    $query = $this->db->prepare("DELETE FROM ".TABLE_PREFIX."galery WHERE id = $gid ");
                    $res = $quermenuDeletey->execute();
                    if($res)
                    {
                        if(file_exists("images/galery/big/$name"))    unlink("images/galery/big/$name");	
                        if(file_exists("images/galery/med/$name"))    unlink("images/galery/med/$name");	
                        if(file_exists("images/galery/small/$name"))  unlink("images/galery/small/$name");	
                        if(file_exists("images/galery/temp/$name"))   unlink("images/galery/temp/$name");	
                    }
                }
            }
        }
    }
    function adsRefresh($id)
    {
        $update=time();
        $query = $this->db->prepare("UPDATE ".TABLE_PREFIX."advertise SET `update` = '$update' WHERE `id` = :id ");
        $query->bindParam(':id',$id);
        $query->execute();
    }
    function readMessage($id)
    {
        $query = $this->db->prepare("UPDATE ".TABLE_PREFIX."message SET `read` = '1' WHERE `id` = :id ");
        $query->bindParam(':id',$id);
        $query->execute();

        $query = $this->db->prepare("SELECT * FROM ".TABLE_PREFIX."message WHERE id = :id ");
        $query->setFetchMode(PDO::FETCH_ASSOC);
        $query->bindParam(':id',$id);
        $query->execute();
        $data = $query->fetchAll();
        return $data;
    }
    function viewGalery($id)
    {
        
        $query = $this->db->prepare("SELECT * FROM ".TABLE_PREFIX."advertise WHERE id = :id ");
        $query->setFetchMode(PDO::FETCH_ASSOC);
        $query->bindParam(':id',$id);
        $query->execute();
        $data = $query->fetchAll();
        return $data[0];
    }
    function sendGaleryImage($uid,$id,$image,$al,$name)
    {
        $namelang = get_lang1($name);
        if($image AND $al != NULL AND $name != NULL)
        {
            if($namelang == 1)
            {
                $file  = stripslashes($_FILES['image']['name']);
                $extension = getExtension($file);
                $extension = strtolower($extension);


                if (($extension != "jpg") && ($extension != "jpeg") && ($extension != "png"))
                {
                    $msg = "<font color=red>فرمت عکس ناشناخته است</font>";
                }
                else
                {
                    $size=getimagesize($_FILES['image']['tmp_name']);
                    $xi = $size[0];
                    $yi = $size[1];
                    $xtarget = 1000;
                    $ytarget = 400;

                    if($xi > $xtarget)
                    {
                        $zarib = $xi/$xtarget;
                        $xi = $xi/$zarib;
                        $yi = $yi/$zarib;
                    }
                    if($yi > $ytarget)
                    {
                        $zarib = $yi/$ytarget;
                        $xi = $xi/$zarib;
                        $yi = $yi/$zarib;
                    }


                    $sizekb=filesize($_FILES['image']['tmp_name']);
                    if ($sizekb > MAX_SIZE*1024)
                    {
                        $msg = "<font color=red>حجم عکس بیش از حد مجاز است</font>";
                    }
                    else
                    {
                        $newfilename = $id."-".$name.'.'.$extension;
                        $newname="images/galery/temp/".$newfilename;
                        $copied = copy($_FILES['image']['tmp_name'], $newname);

                        if (!$copied)
                        {
                            $msg = "<font color = red>انتقال عکس ناموفق بود</font>";
                        }
                        else
                        {
                            $thumb_name_small='images/galery/small/'.$newfilename;
                            $thumb=make_thumb($newname,$thumb_name_small,50,50);


                            $thumb_name_med='images/galery/med/'.$newfilename;
                            $thumb=make_thumb($newname,$thumb_name_med,120,84);

                            $thumb_name_big='images/galery/big/'.$newfilename;
                            $thumb=make_thumb($newname,$thumb_name_big,$xi,$yi);

                            $time = time();
                            $query = $this->db->prepare("INSERT INTO ".TABLE_PREFIX."galery (`id` ,`adsid` ,`name` ,`alt` ,`date`)VALUES 
                                                         (NULL , '$id', '$newfilename', '$al', '$time')");
                            $res = $query->execute();
                            if($res)
                            {
                                unlink("images/galery/temp/$newfilename");
                                $msg = "<strong><font color = green>عکس با موفقیت ارسال شد.</font></strong>";
                                $query = $this->db->prepare("UPDATE ".TABLE_PREFIX."advertise SET `status` = '0' WHERE `id` = '$id'");
                                $query->execute();
                                
                            }
                            else
                            {
                                unlink("images/galery/big/$newfilename");
                                unlink("images/galery/med/$newfilename");
                                unlink("images/galery/small/$newfilename");
                                $msg = "<strong><font color = red>ایراد در یانک اطلاعاتی</font></strong>";
                            }
                        }
                    }
                }
            }
            else
            {
                $msg = "<font color=red>در نام عکس فقط باید از اعداد و حروف انگلیسی استفاده نمایید</font>";
            }
        }
        else
        {
            $msg = "<font color=red>اطلاعات را کامل وارد نمایید</font>";
        }
        return $msg;;
    }
    function deleteGalery($id)
    {
        $query = $this->db->prepare("SELECT * FROM ".TABLE_PREFIX."galery WHERE id = :id ");
        $query->setFetchMode(PDO::FETCH_ASSOC);
        $query->bindParam(':id',$id);
        $query->execute();
        $data  = $query->fetch();
        $name  = $data['name'];
        $adsid = $data['adsid'];
        
        $query = $this->db->prepare("DELETE FROM ".TABLE_PREFIX."galery WHERE `id`= :id ");
        $query->bindParam(':id',$id);
        $res = $query->execute();
        if($res)
        {
            if(file_exists("images/galery/big/$name"))   unlink("images/galery/big/$name");
            if(file_exists("images/galery/med/$name"))   unlink("images/galery/med/$name");
            if(file_exists("images/galery/small/$name")) unlink("images/galery/small/$name");
            if(file_exists("images/galery/temp/$name"))  unlink("images/galery/temp/$name");		
        }
        return $adsid;
    }
    function setting($name,$vitrin)
    {
        $uid = UID;
        $query = $this->db->prepare("UPDATE ".TABLE_PREFIX."user SET `name` = :name,`vitrin` = :vitrin  WHERE `id` = :uid");
        $query->bindParam(':name',$name);
        $query->bindParam(':vitrin',$vitrin);
        $query->bindParam(':id',$id);
        $query->execute();
        
        if($query)
        {
            $msg = "<font color=green>تغییرات با موفقیت اعمال شد</font>";
        }
        else
        {
            $msg = "<font color=green>تغییرات اعمال نشد. مجددا تلاش کنید</font>";
        }             
        return $msg;
    }
    function getSetting($uid)
    {
        $query = $this->db->prepare("SELECT * FROM ".TABLE_PREFIX."user WHERE id = :uid ");
        $query->setFetchMode(PDO::FETCH_ASSOC);
        $query->bindParam(':uid',$uid);
        $query->execute();
        $data = $query->fetch();
        return $data;
    }
    function resetPassword($currentPassword,$newPassword,$renewPassword)
    {
        $userId = UID;        
        $query = $this->db->prepare("SELECT * FROM ".TABLE_PREFIX."user WHERE `id` = :userId ");
        $query->setFetchMode(PDO::FETCH_ASSOC);
        $query->bindParam(':userId',$userId);
        $query->execute();
        $data = $query->fetch();
        $password = $data['password'];

        if(md5($currentPassword) == $password)
        {
            if($newPassword == $renewPassword)
            {
                $query = $this->db->prepare("UPDATE ".TABLE_PREFIX."user SET `password` = '".md5($newPassword)."' WHERE id = :userId ");
                $query->bindParam(':userId',$userId);
                $query->execute();
                if($query)
                {
                    $msg = "<font color=green>تغییر کلمه عبور با موفقیت انجام شد</font>";
                }
                else
                {
                    $msg = "<font color=red>ایراد در ارتباط با بانک اطلاعاتی</font>";
                }
            }
            else
            {
                $msg = "<font color=red>کلمه عبور جدید و تکرار آن یکسان نمی باشد</font>";
            }
        }
        else
        {
            $msg = "<font color=red>کلمه عبور فعلی صحیح نمی باشد</font>";
        }
        return $msg;;
    }
    function registerFish($aid,$uid,$fishdate,$tig,$resid,$amount,$sender,$comment)
    {
        $query = $this->db->prepare("INSERT INTO ".TABLE_PREFIX."fish (`id` ,`aid` ,`uid` ,`fdate` ,`date` ,`fnumber` , `amount` ,`sender` ,`comment` ,`status`)VALUES (NULL , :aid, :uid, :fishdate, :tig, :resid, :amount, :sender, :comment, '0');");
        $query->bindParam(':aid',$aid);
        $query->bindParam(':uid',$uid);
        $query->bindParam(':fishdate',$fishdate);
        $query->bindParam(':tig',$tig);
        $query->bindParam(':resid',$resid);
        $query->bindParam(':amount',$amount);
        $query->bindParam(':sender',$sender);
        $query->bindParam(':comment',$comment);
        $res = $query->execute();
        if($res)
        {
            $msg = "<font color=green>فیش با موفقیت ثبت گردید</font>";
        }
        else
        {
            $msg = "<font color=red>مشکل در ثبت فیش. مجددا تلاش نمایید</font>";
        }
        return $msg;
    }
    function onlinepay($amount,$getway)
    {
        $uid = UID;
        $query = $this->db->prepare("SELECT * FROM ".TABLE_PREFIX."onlinebank WHERE id = :getway ");
        $query->setFetchMode(PDO::FETCH_ASSOC);
        $query->bindParam(':getway',$getway);
        $query->execute();
        $data = $query->fetch();
        $bankname = $data['name'];
        $_SESSION['bank'] = $bankname;
        /****************************** Parsian   *****************************************/
        if($bankname == 'parsian')
        {
            $siteAddress = URL;

            $query = $this->db->prepare("SELECT * FROM ".TABLE_PREFIX."onlinebank WHERE name = 'parsian'");
            $query->setFetchMode(PDO::FETCH_ASSOC);
            $query->execute();
            $data = $query->fetch();
            $bankid = $data['id'];

            $query = $this->db->prepare("SELECT * FROM ".TABLE_PREFIX."onlinemethod WHERE bankid = :bankid ");
            $query->setFetchMode(PDO::FETCH_ASSOC);
            $query->bindParam(':bankid',$bankid);
            $query->execute();
            $data = $query->fetch();
            $param1 = $data['parameter1'];
            
            $dte    = time();

            if($amount == "")
            {
                $msg = "<strong><font color=red>مبلغ را وارد نمایید</font></strong>";
            }
            else
            {
                $query = $this->db->prepare("INSERT INTO ".TABLE_PREFIX."onlinepay VALUES (NULL, '$uid', '$getway', '$amount', '$dte', '-1', '-1', '0')");
                $res = $query->execute();
                if($res)
                {
                    $payOrderId = my_max(TABLE_PREFIX.'onlinepay','id',-1,-1,-1,-1,-1,-1,-1,-1);   
                    
                    $price  = $amount;
                    $PayID  = $payOrderId;
                    $RedirectURL = $siteAddress."desktop/onlinepay/?payorderid=$payOrderId";

                    $soapclient = new nusoap_client('https://pec.shaparak.ir/pecpaymentgateway/eshopservice.asmx?wsdl','wsdl');
                    $soapProxy = $soapclient->getProxy() ;
                    $params = array(
                            'pin' => $param1 ,
                            'amount' => $price,
                            'orderId' => $PayID,
                            'callbackUrl' => $RedirectURL,
                            'authority' => 0,
                            'status' => 0
                    );
                    $sendParams = array($params) ;
                    $res = $soapclient->call('PinPaymentRequest', $sendParams);
                    $authority = $res['authority'];
                    $status = $res['status'];

                    if ( ($authority) and ($status==0) )  
                    {
                        $query = $this->db->prepare("UPDATE ".TABLE_PREFIX."onlinepay SET  authority = '$authority' WHERE id = '$payOrderId' ");
                        $query->execute();
                        if($query)
                        {
                            header("location:"."https://pec.shaparak.ir/pecpaymentgateway/?au=".$authority);
                        }
                        else
                        {
                            $msg = "<strong><font color=red>خطای شماره".$status."-1"."</font></strong>";
                            $k = 10;
                        }
                    }
                    elseif (isset($status) != NULL and $status != 0)
                    {
                        $query = $this->db->prepare("UPDATE ".TABLE_PREFIX."onlinepay SET status = '$status' WHERE id = '$payOrderId' ");
                        $query->execute();
                        if($query)
                        {
                            $msg = "<strong><font color=red>خطای شماره".$status."-2"."</font></strong>";
                            $k = 10;
                        }
                        else
                        {
                            $msg = "<strong><font color=red>خطای شماره 101</font></strong>";
                            $k = 10;
                        }
                    }
                    else
                    {
                        $msg = "<strong><font color=red>خطای شماره 102</font></strong>";
                        $k = 10;
                    }
                }
                else
                {
                    $msg = "<strong><font color=red>خطای شماره103</font></strong>";
                    $k = 10;
                }
            }	
        }
        /****************************** END Parsian ***********************************/

        /****************************** Zarin Pal   ***********************************/
        if($bankname == 'zarinpal')
        {	
            $siteAddress = URL;

            $query = $this->db->prepare("SELECT * FROM ".TABLE_PREFIX."onlinebank WHERE name = 'zarinpal'");
            $query->setFetchMode(PDO::FETCH_ASSOC);
            $query->execute();
            $data = $query->fetch();
            $bankid = $data['id'];

            $query = $this->db->prepare("SELECT * FROM ".TABLE_PREFIX."onlinemethod WHERE bankid = '$bankid'");
            $query->setFetchMode(PDO::FETCH_ASSOC);
            $query->execute();
            $data = $query->fetch();
            $param1 = $data['parameter1'];

            $dte    = time();

            if($amount == "")
            {
                $msg = "<strong><font color=red>مبلغ را وارد نمایید</font></strong>";
            }
            else
            {
                $query = $this->db->prepare("INSERT INTO ".TABLE_PREFIX."onlinepay VALUES (NULL, '$uid', '$getway', '$amount', '$dte', '-1', '-1', '0')");
                $res = $query->execute();
                if($res)
                {
                    $payOrderId = my_max(TABLE_PREFIX.'onlinepay','id',-1,-1,-1,-1,-1,-1,-1,-1);   

                    $price  = $amount/10;
                    $PayID  = $payOrderId;

                    $redirectUrl = $siteAddress."desktop/onlinepay/";			

                    $Description = 'خرید';
                    $Email       = '';
                    $Mobile      = '';

                    $client = new nusoap_client('https://de.zarinpal.com/pg/services/WebGate/wsdl', 'wsdl'); 
                    $client->soap_defencoding = 'UTF-8';
                    $result = $client->call('PaymentRequest', array(
                                                                    array(
                                                                            'MerchantID' 	=> $param1,
                                                                                    'Amount' 		=> $price,
                                                                                    'Description' 	=> $Description,
                                                                                    'Email' 		=> $Email,
                                                                                    'Mobile' 		=> $Mobile,
                                                                                    'CallbackURL' 	=> $redirectUrl
                                                                            )
                                                                    )
                                            );

                    $res = $result['Status'];
                    $au  = $result['Authority'];
                    if ( $res == 100 )  
                    {
                        $query = $this->db->prepare("UPDATE ".TABLE_PREFIX."onlinepay SET authority = '$au' WHERE id = '$payOrderId' ");
                        $query->execute();
                        if($query)
                        {
                            header('Location: https://www.zarinpal.com/pg/StartPay/'.$au);
                        }
                        else
                        {
                            $msg = "خطای شماره".$status;
                            $k = 10;
                        }
                    }
                    else
                    {
                        $query = $this->db->prepare("UPDATE ".TABLE_PREFIX."onlinepay SET status = '$res' WHERE id = '$payOrderId' ");
                        $query->execute();
                        if($query)
                        {
                            $msg = "<font color=red>خطای شماره$res</font>";
                            $k = 10;
                        }
                        else
                        {
                            $msg = "<font color=red>خطای شماره 12</font>";
                            $k = 10;
                        }
                    }
                }
                else
                {
                    $msg = "<strong><font color=red>خطای شماره11</font></strong>";
                    $k = 10;
                }
            }	
        }
    
        return $msg;     
    }
    function onlinepayback()
    {
        /****************************** Zarin Pal   *****************************************/
        if((isset($_SESSION['bank'])) AND ($_SESSION['bank'] == "zarinpal"))
        {
            if(isset($_GET['Status']))
            {
                $authority = $_GET['Authority'];
                $status    = $_GET['Status'];

                if($status == 'OK')
                {
                    $query = $this->db->prepare("SELECT * FROM ".TABLE_PREFIX."onlinebank WHERE name = 'zarinpal'");
                    $query->setFetchMode(PDO::FETCH_ASSOC);
                    $query->execute();
                    $data = $query->fetch();
                    $bankid = $data['id'];

                    $query = $this->db->prepare("SELECT * FROM ".TABLE_PREFIX."onlinemethod WHERE bankid = '$bankid'");
                    $query->setFetchMode(PDO::FETCH_ASSOC);
                    $query->execute();
                    $data = $query->fetch();
                    $param1 = $data['parameter1'];
                    
                    $query = $this->db->prepare("SELECT * FROM ".TABLE_PREFIX."onlinepay WHERE `authority` = '$authority'");
                    $query->setFetchMode(PDO::FETCH_ASSOC);
                    $query->execute();
                    $data = $query->fetch();
                    $amount = $data['amount']/10;

                    $client = new nusoap_client('https://de.zarinpal.com/pg/services/WebGate/wsdl', 'wsdl'); 
                    $client->soap_defencoding = 'UTF-8';

                    $result = $client->call('PaymentVerification', array(
                                                                    array(
                                                                                    'MerchantID'	 => $param1,
                                                                                    'Authority' 	 => $authority,
                                                                                        'Amount'	 	 => $amount
                                                                                )
                                                                            )
                        );


                    $res = $result['Status'];
                    if($result['Status'] == 100)
                    {
                        $date = time();
                        $query = $this->db->prepare("UPDATE ".TABLE_PREFIX."onlinepay SET status = '$res', finalized ='1' WHERE `authority` = '$authority' ");
                        $query->execute();
                        if($query)
                        {
                            $msg = "<strong><font color=green>پرداخت با موفقیت انجام شد</font></strong>";
                            $k = 20;
                        }
                        else
                        {
                            $k = 10;
                            $query = $this->db->prepare("UPDATE ".TABLE_PREFIX."onlinepay SET status = '$status'  WHERE `authority` = '$authority' ");
                            $query->execute();
                            $msg = "<strong><font color=red>پرداخت انجام نشد</font></strong>";
                        }
                    }
                }
                if($_GET['Status'] == 'NOK')
                {
                    $query = $this->db->prepare("UPDATE ".TABLE_PREFIX."onlinepay SET status = '-7' WHERE `authority` = '$authority' ");
                    $query->execute();    
                    $msg = "<strong><font color=red>عملیات توسط کاربر لغو شد</font></strong>";
                }
            }
        }
        /************************************** END Zarin Pal **********************************************/


        /****************************** Parsian   *****************************************/
        if(isset($_SESSION['bank']) and ($_SESSION['bank'] == "parsian"))
        {
            if((isset($_GET['payorderid']) != NULL) && (!isset($_POST['send'])))
            {
                $query = $this->db->prepare("SELECT * FROM ".TABLE_PREFIX."onlinebank WHERE name = 'parsian'");
                $query->setFetchMode(PDO::FETCH_ASSOC);
                $query->execute();
                $data = $query->fetch();
                $bankid = $data['id'];

                $query = $this->db->prepare("SELECT * FROM ".TABLE_PREFIX."onlinemethod WHERE bankid = '$bankid'");
                $query->setFetchMode(PDO::FETCH_ASSOC);
                $query->execute();
                $data = $query->fetch();
                $param1 = $data['parameter1'];

                $payOrderId   = $_GET['payorderid'];
                $authority    = $_GET['au'];
                $rs    = $_GET['rs'];


                $soapclient = new nusoap_client('https://pec.shaparak.ir/pecpaymentgateway/eshopservice.asmx?wsdl','wsdl');

                $status = 1;
                $params = array(
                                        'pin' => $param1 ,
                                        'authority' => $authority,
                                        'status' => $status ) ;
                $sendParams = array($params);
                $result = $soapclient->call('PinPaymentEnquiry', $sendParams);		
                $status = $result['status'];
                if ($status == 0)
                {
                    $date = time();
                    $query = $this->db->prepare("UPDATE ".TABLE_PREFIX."onlinepay SET status = '$status', finalized ='1' WHERE id = '$payOrderId' ");
                    $query->execute();
                    if($query)
                    {
                        $msg = "<strong><font color=green>پرداخت با موفقیت انجام شد</font></strong>";
                        $k = 20;
                    }
                }
                else
                {
                    $k = 10;
                    $query = $this->db->prepare("UPDATE ".TABLE_PREFIX."onlinepay SET status = '$status' WHERE id = '$payOrderId' ");
                    $query->execute();
                    $msg = "<strong><font color=red>پرداخت انجام نشد</font></strong>";
                }
            }
        }
        /************************************** END Parsian **********************************************/
        return $msg;
    }
    
}
?>