<?php
class register_model extends Model
{
    function __construct()
    {
        parent::__construct();
    }
    function confirmation($code)
    {
        
		$query = $this->db->prepare("SELECT * FROM ".TABLE_PREFIX."user WHERE code = $code ");
        $query->setFetchMode(PDO::FETCH_NUM);
        $query->execute();
		$query->fetch();
		$count = $query->rowCount();
		if($count == 1)
		{
			$query = $this->db->prepare("UPDATE ".TABLE_PREFIX."user SET active = 1 WHERE code = $code ");
            $query->execute();
			$msg =  "ایمیل شما با موفقیت تایید گردید";
		}
		else
		{
			$msg =  "فعال سازی انجام نشد";
		}
        return $msg;
    }
   
}
?>