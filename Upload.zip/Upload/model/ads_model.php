<?php
class ads_model extends Model
{
    function __construct()
    {
        parent::__construct();
    }
    function view($id)
    {
        
		$query = $this->db->prepare("SELECT * FROM ".TABLE_PREFIX."advertise WHERE id = $id ");
        $query->setFetchMode(PDO::FETCH_NUM);
        $query->execute();
		$data = $query->fetch();
		$count = $query->rowCount();
		if($count == 1)
		{
			return $data;
		}
		else
		{
			header("Location: ../../index.php");	
		}
    }
    function group($id)
    {
        
		$query = $this->db->prepare("SELECT * FROM ".TABLE_PREFIX."adssubgroup WHERE sgid = $id ");
        $query->setFetchMode(PDO::FETCH_NUM);
        $query->execute();
		$data = $query->fetch();
		return $data;

    }
   
}
?>