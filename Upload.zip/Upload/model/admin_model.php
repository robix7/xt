<?php
class admin_model extends Model
{
    function __construct()
    {
        parent::__construct();
    }
    function admin()
    {  
        $m='';
        $m = $m."/".$numberOfUser      = my_count(TABLE_PREFIX.'user','id',-1,-1,-1,-1,-1,-1,-1,-1);
        $m = $m."/".$activeUser        = my_count(TABLE_PREFIX.'user','id','active',1,-1,-1,-1,-1,-1,-1);
        $m = $m."/".$deactiveUser      = my_count(TABLE_PREFIX.'user','id','active',0,-1,-1,-1,-1,-1,-1);
        $m = $m."/".$allAdvertise      = my_count(TABLE_PREFIX.'advertise','id',-1,-1,-1,-1,-1,-1,-1,-1);
        $m = $m."/".$activeAdvertise   = my_count(TABLE_PREFIX.'advertise','id','status',1,-1,-1,-1,-1,-1,-1);
        $m = $m."/".$deactiveAdvertise = my_count(TABLE_PREFIX.'advertise','id','status',0,-1,-1,-1,-1,-1,-1);
        $m = $m."/".$visit             = Setting::GetSetting(22);
        $m = $m."/".$advertiseVisit    = my_count(TABLE_PREFIX.'visit','id',-1,-1,-1,-1,-1,-1,-1,-1);
        $m = trim($m,'/');
        $m = explode('/',$m);
        return $m;
    }
    function getEmail($id)
    {
        $query = $this->db->prepare("SELECT email FROM ".TABLE_PREFIX."user WHERE id = :id ");
        $query->setFetchMode(PDO::FETCH_NUM);
        $query->bindParam(':id',$id);
        $query->execute();
	$email = $query->fetch();       
        return $email; 
    }
    function inserAdsGetAds($id)
    {
        $cnt = my_count(TABLE_PREFIX.'advertise','id','id',$id,-1,-1,-1,-1,-1,-1);
        if($cnt == 0)
        {
            header("Location:".URL."desktop/adslist");
        }
        else
        {
            $query = $this->db->prepare("SELECT * FROM ".TABLE_PREFIX."advertise WHERE id = $id");
            $query->setFetchMode(PDO::FETCH_ASSOC);
            $query->execute();
            $data = $query->fetchAll();
            return $data[0];
        }
    }
    function inserAdsNewAds($editMode,$adsId,$mgroup,$sgroup,$subject,$comment,$adsPrice,$kind,$timelong,$hasurl,$url,$star,$name,$email,$tel,$mobile,$yahooid,$address,$keyword,$image)
    {
        $query = $this->db->prepare("SELECT * FROM ".TABLE_PREFIX."advertise WHERE id = $adsId");
        $query->setFetchMode(PDO::FETCH_ASSOC);
        $query->execute();
        $data  = $query->fetch();
        $oldKind = $data['kind'];
        
        $image     = $_FILES['image']['name'];
        $msg = '';
        $error  = 0;
        if($kind == 2 OR $kind == 4) // The ads has image
        {
            $filename  = stripslashes($_FILES['image']['name']);
            $extension = getExtension($filename);
            $extension = strtolower($extension);

            $size   = getimagesize($_FILES['image']['tmp_name']);
            $sizekb = filesize($_FILES['image']['tmp_name']);
            if ($extension != "jpg")
            {
                $msg   = "<font color=red>تنها فرمت  jpg قابل قبول است.</font>";
                $error = 1;
            }
            if ($sizekb > MAX_SIZE*1024)
            {
                $msg = "<font color=red>حجم عکس بیش از حد مجاز است</font>";
                $error = 1;
            }
        }
        if($error == 0)
        {
            if($editMode == 1)
            {
                $query = $this->db->prepare("UPDATE ".TABLE_PREFIX."advertise SET `mgid` = '$mgroup', `sgid` = '$sgroup', `subject` = '$subject',
                                            `comment` = '$comment', `price` = '$adsPrice',
                                            `kind` = '$kind', `status` = '0', `star` = '$star', `hasimage` = '1',
                                            `update` = '$update', `timelong` = '$timelong', `url` = '$url',
                                            `hasurl` = '$hasurl',`name` = '$name', `email` = '$email',
                                            `tel` = '$tel',`mobile` = '$mobile', `yahoo` = '$yahooid',
                                            `address` = '$address',`keyword` = '$keyword' WHERE `id` = '$adsId' ");
            }
            else
            {
                $query = $this->db->prepare("INSERT INTO ".TABLE_PREFIX."advertise VALUES (NULL , '$userId', '$mgroup',
                                            '$sgroup','$subject', '$comment','$adsPrice','$cost',
                                            '$kind','0', '$star', '1', '$crdate','$update','$spdate', '0',
                                            '$timelong', '$url', '$hasurl','$name', '$email', '$tel',
                                            '$mobile', '$yahooid','$address', '$keyword', '0', '0')");
            }
            if($res = $query->execute())
            {
                if($kind == 2 OR $kind == 4)
                {
                    $image_name=$adsId.'.'.$extension;
                    $newname="images/ads/temp/".$image_name;
                    $copied = copy($_FILES['image']['tmp_name'], $newname);
                    if (!$copied)
                    {
                            $msg = "<font color = red>انتقال عکس ناموفق بود</font>";
                    }
                    else
                    {
                        $thumb_name_small = 'images/ads/small/'.$image_name;
                        $thumb=make_thumb($newname,$thumb_name_small,50,50);

                        $thumb_name_med   = 'images/ads/med/'.$image_name;
                        $thumb=make_thumb($newname,$thumb_name_med,120,84);

                        $thumb_name_big   = 'images/ads/big/'.$image_name;
                        $thumb=make_thumb($newname,$thumb_name_big,250,400);
                        unlink('images/ads/temp/'.$adsId.'.jpg');
                        $msg = "<font color = green>انتقال عکس موفق بود</font>";

                    }
                }
                header("Location:".URL."admin/adslist");                    
            }
        }
        $data[0]  = $mgroup;
        $data[1]  = $sgroup;
        $data[2]  = $subject;
        $data[3]  = $comment;
        $data[4]  = $adsPrice;
        $data[5]  = $kind;
        $data[6]  = $timelong;
        $data[7]  = $hasurl;
        $data[8]  = $url;
        $data[9]  = $star;
        $data[10] = $name;
        $data[11] = $email;
        $data[12] = $tel;
        $data[13] = $mobile;
        $data[14] = $yahooid;
        $data[15] = $address;
        $data[16] = $keyword;
        $data[17] = $msg;
        //$data[18] = $cost;
        return $data;
    }
    function adsDelete($id)
    {
        $query = $this->db->prepare("DELETE FROM ".TABLE_PREFIX."advertise WHERE id = :id ");
        $query->bindParam(':id',$id);
        $res = $query->execute();
        if($res)
        {
            if(file_exists("images/ads/big/$id.jpg"))   unlink("images/ads/big/$id.jpg");
            if(file_exists("images/ads/med/$id.jpg"))   unlink("images/ads/med/$id.jpg");
            if(file_exists("images/ads/small/$id.jpg")) unlink("images/ads/small/$id.jpg");
            if(file_exists("images/ads/temp/$id.jpg"))  unlink("images/ads/temp/$id.jpg");		

            $gcnt = my_count(TABLE_PREFIX.'galery','id','adsid',$id,-1,-1,-1,-1,-1,-1);

            if($gcnt > 0)
            {
                
                $query = $this->db->prepare("SELECT id,name FROM ".TABLE_PREFIX."galery WHERE adsid = $id");
                $query->setFetchMode(PDO::FETCH_ASSOC);
                $query->execute();
                $data = $query->fetchAll();
                for($i=0;$i <= count($data);$i++)
                {
                    $gid  = $data[$i][id];
                    $name = $data[$i][name];
                    $query = $this->db->prepare("DELETE FROM ".TABLE_PREFIX."galery WHERE id = $gid ");
                    $res = $quermenuDeletey->execute();
                    if($res)
                    {
                        if(file_exists("images/galery/big/$name"))    unlink("images/galery/big/$name");	
                        if(file_exists("images/galery/med/$name"))    unlink("images/galery/med/$name");	
                        if(file_exists("images/galery/small/$name"))  unlink("images/galery/small/$name");	
                        if(file_exists("images/galery/temp/$name"))   unlink("images/galery/temp/$name");	
                    }
                }
            }
        }
    }
    function adsRefresh($id)
    {
        $update = time();
        $query  = $this->db->prepare("UPDATE ".TABLE_PREFIX."advertise SET `status` = '1' WHERE id= :id");
        $query->bindParam(':id',$id);
        $query->execute();
    }
    function galeryDelete($id)
    {
        $result      = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."galery WHERE id = $id" );
        $show_result = $db->sql_fetcharray($result); 
        $name        = $show_result['name'];
        if($db->sql_query("DELETE FROM ".TABLE_PREFIX."galery WHERE `id`='$id' "))
        {
            if(file_exists(URL."images/galery/big/$name"))   unlink(URL."images/galery/big/$name");
            if(file_exists(URL."images/galery/med/$name"))   unlink(URL."images/galery/med/$name");
            if(file_exists(URL."images/galery/small/$name")) unlink(URL."images/galery/small/$name");
            if(file_exists(URL."images/galery/temp/$name"))  unlink(URL."images/galery/temp/$name");		
            header("Location: adslist.php");
        }
    }
    function fishDelete($id)
    {
        $query = $this->db->prepare("DELETE FROM ".TABLE_PREFIX."fish WHERE id = :id ");
        $query->bindParam(':id',$id);
        $query->execute();
    }
    function fishconfirm($id)
    {
        $query = $this->db->prepare("SELECT status FROM ".TABLE_PREFIX."fish WHERE id = :id ");
        $query->setFetchMode(PDO::FETCH_NUM);
        $query->bindParam(':id',$id);
        $query->execute();
	$data = $query->fetch();
        $status = $data[0];
        if($status == 0) $status = 1; else $status = 0; 
        $query = $this->db->prepare("UPDATE ".TABLE_PREFIX."fish SET `status` = '$status' WHERE id='$id'");
        $res = $query->execute();
    }
    function fishGetData($id)
    {
        
        $query = $this->db->prepare("SELECT * FROM ".TABLE_PREFIX."fish WHERE id = :id ");
        $query->setFetchMode(PDO::FETCH_NUM);
        $query->bindParam(':id',$id);
        $query->execute();
	$data = $query->fetch();       
        return $data;
    }
    function fishEditConfirm($id,$aid,$resid,$amount,$fishdate,$sender,$comment)
    {
        $ti      = date('Y-m-d',time());
        $tij     = g_to_j($ti);
        $date3   = explode("-",$tij);

        $dte1 = 0;$dte2 = 0;$dte3 = 0;$dte4 = 0;
        $date2   = explode("-",$fishdate);
        if($date2[1] >= 1 and $date2[1] <= 12) $dte2 = 2;
        if($date2[2] >= 1 and $date2[2] <= 31) $dte3 = 3;
        if($dte2 == 2 and $dte3 == 3) $dte4 = 4;

        $er = 0;
        if($resid == NULL)  {$er = 1; }
        if($amount == NULL) {$er = 1; }
        if($sender == NULL) {$er = 1; }
        if($dte4 == 0)      {$er = 1; }
        if($er == 0)
        {
            $query = $this->db->prepare("UPDATE ".TABLE_PREFIX."fish SET `aid` = :aid, `fdate` = :fishdate, `fnumber` = :$resid, `amount` = :amount, `sender` = :sender, `comment` = :comment WHERE `id` = :id ");
            $query->bindParam(':id',$id);
            $query->bindParam(':aid',$aid);
            $query->bindParam(':resid',$resid);
            $query->bindParam(':amount',$amount);
            $query->bindParam(':fishdate',$fishdate);
            $query->bindParam(':sender',$sender);
            $query->bindParam(':comment',$comment);
            $res = $query->execute();
            if($res)
            {
                    $msg = "<font color=green>فیش با موفقیت ویرایش گردید</font>";
            }
            else
            {
                    $msg = "<font color=red>مشکل در ویرایش فیش، مجددا تلاش نمایید</font>";
            }
        }
        return $msg;
    }
    function onlinePayAccountDelete($id)
    {
        $query = $this->db->prepare("DELETE FROM ".TABLE_PREFIX."onlinemethod WHERE `id`= :id ");
        $query->bindParam(':id',$id);
        $query->execute();
    }
    function onlinepayDelete($id)
    {
        $query = $this->db->prepare("DELETE FROM ".TABLE_PREFIX."onlinepay WHERE `id`=:id ");
        $query->bindParam(':id',$id);
        $query->execute();
    }
    function onlinepayConfirm($id)
    {
        $query     = $this->db->prepare("SELECT finalized FROM ".TABLE_PREFIX."onlinepay WHERE id = :id ");
        $query->setFetchMode(PDO::FETCH_NUM);
        $query->bindParam(':id',$id);
        $query->execute();
	$data      = $query->fetch();
        $finalized = $data[0];
        if($finalized == 0) $finalized = 1; else $finalized = 0; 
        
        $query = $this->db->prepare("UPDATE ".TABLE_PREFIX."onlinepay SET `finalized` = '$finalized' WHERE id = '$id'");
        $res = $query->execute();
    }
    function onlinepayAdd($bankid,$parameter1,$parameter2,$accountstatus)
    {
        $query = $this->db->prepare("INSERT INTO ".TABLE_PREFIX."onlinemethod (`id`, `bankid`, `parameter1`, `parameter2`, `accountstatus`)VALUES (NULL ,'$bankid', '$parameter1', '$parameter2', '$accountstatus');");
        $res = $query->execute();
        if($res)
        {
            $msg = "<font color=green>حساب با موفقیت ثبت گردید</font>";
        }
        else
        {
            $msg = "<font color=red>مشکل در ثبت حساب. مجددا تلاش نمایید</font>";
        }
        return $msg;
    }
    function onlinepayAccountEdit($id,$bankid,$parameter1,$parameter2,$accountstatus)
    {
        $query = $this->db->prepare("UPDATE ".TABLE_PREFIX."onlinemethod SET `bankid` = '$bankid',`parameter1` = '$parameter1',`parameter2` = '$parameter2',`accountstatus` = '$accountstatus' WHERE `id` = '$id'");
        $res = $query->execute();
        if($res)
        {
            $msg = "<font color=green>روش پرداخت با موفقیت ویرایش گردید</font>";
        }
        else
        {
            $msg = "<font color=red>خطا در ویرایش</font>";
        }
        return $msg;
    }
    function onlineGetAccount($id)
    {
        $query = $this->db->prepare("SELECT * FROM ".TABLE_PREFIX."onlinemethod WHERE id = $id");
        $query->setFetchMode(PDO::FETCH_ASSOC);
        $query->execute();
        $data = $query->fetch();
        return $data;
    }
    function accountDelete($id)
    {
        $query = $this->db->prepare("DELETE FROM ".TABLE_PREFIX."accounts WHERE `id`='$id'");
        $res = $query->execute();
    }
    function accountAdd($accountname,$accountnumber,$accountatm,$accountsheba,$accountholder)
    {
        $query = $this->db->prepare("INSERT INTO ".TABLE_PREFIX."accounts VALUES(NULL,'$accountname','$accountnumber','$accountatm','$accountsheba','$accountholder',1)");
        $res = $query->execute();
        if($res)
        {
            $msg = "<font color=green>حساب با موفقیت ثبت گردید</font>";
        }
        else
        {
            $msg = "<font color=red>مشکل در ثبت حساب. مجددا تلاش نمایید</font>";
        }
        return $msg;
    }
    function contentAdd($name,$content)
    {
        $query = $this->db->prepare("INSERT INTO ".TABLE_PREFIX."content VALUES (NULL , '$name', '$content')");
        $res = $query->execute();
        if($res)
        {
            $msg = "<font color=green>صفحه با موفقیت ایجاد شد</font>";
        }
        else
        {
            $msg = "<font color=red>مشکل در ایجاد صفحه</font>";
        }
        return $msg;
    }
    function contentEdit($id,$name,$content)
    {
        $query = $this->db->prepare("UPDATE ".TABLE_PREFIX."content SET `name` = '$name',`content` = '$content' WHERE `id` ='$id'");
        $res = $query->execute();
        if($res)
        {
            $msg = "<font color=green>صفحه با موفقیت ویرایش شد</font>";
        }
        else
        {
            $msg = "<font color=red>مشکل در ویرایش صفحه</font>";
        }
        return $msg;
    }
    function contentGetData($id)
    {
        $query = $this->db->prepare("SELECT * FROM ".TABLE_PREFIX."content WHERE id = $id");
        $query->setFetchMode(PDO::FETCH_ASSOC);
        $query->execute();
        $data = $query->fetch();
        return $data;
    }
    function contentDelete($id)
    {
        $query = $this->db->prepare("DELETE FROM ".TABLE_PREFIX."content WHERE `id`='$id'");
        $res = $query->execute();
    }
    function menuAdd($menuname,$file,$menukind,$ordering,$menuposition,$menustatus)
    {
        $query = $this->db->prepare("INSERT INTO ".TABLE_PREFIX."menu VALUES (NULL ,'$menuname','$file' ,'$menukind' ,'$ordering'  ,'$menuposition','$menustatus')");
        $res = $query->execute();
        if($res)
        {
            $msg = "<font color=green>فهرست با موفقیت ایجاد گردید</font>";
        }
        else
        {
            $msg = "<font color=red>خطا در بانک اطلاعاتی</font>";
        }
        return $msg;
    }
    function menuEdit($id,$menuname,$file,$menukind,$menuposition,$menustatus)
    {
        $ordering =  my_max(TABLE_PREFIX.'menu','ordering','pos',$menuposition,-1,-1,-1,-1,-1,-1);
        $ordering  = $ordering + 1;
        $query = $this->db->prepare("UPDATE ".TABLE_PREFIX."menu SET `name` = '$menuname',`file` = '$file',`kind` = '$menukind',
                                    `ordering` = '$ordering',`pos` = '$menuposition',`status` = '$menustatus'  WHERE `id` = '$id'");
        $res = $query->execute();
        if($res)
        {
            $msg = "<font color=green>فهرست با موفقیت ویرایش گردید</font>";
        }
        else
        {
            $msg = "<font color=red>خطا در بانک اطلاعاتی</font>";
        }
        return $msg;
    }
    function menuDelete($id)
    {
        $query = $this->db->prepare("DELETE FROM ".TABLE_PREFIX."menu WHERE `id`='$id'");
        $res = $query->execute();
    }
    function menuGetData($id)
    {
        $query = $this->db->prepare("SELECT * FROM ".TABLE_PREFIX."menu WHERE id = $id");
        $query->setFetchMode(PDO::FETCH_ASSOC);
        $query->execute();
        $data = $query->fetch();
        return $data;
    }
    function menuUpOrdering($id)
    {
        $query = $this->db->prepare("SELECT * FROM ".TABLE_PREFIX."menu WHERE id = '$id'");
        $query->setFetchMode(PDO::FETCH_ASSOC);
        $query->execute();
        $data       = $query->fetch();
        $ordering   = $data['ordering'];
        $pos        = $data['pos'];
        $uporder    =  my_count(TABLE_PREFIX.'menu','id','ordering',$ordering-1,'pos',$pos,-1,-1,-1,-1);
        $newordering = $ordering-1;
        if($uporder > 0)
        {
            $query = $this->db->prepare("SELECT * FROM ".TABLE_PREFIX."menu WHERE ordering = '$newordering' AND pos = '$pos'");
            $query->setFetchMode(PDO::FETCH_ASSOC);
            $query->execute();
            $data       = $query->fetch();
            $upid       = $data['id'];
            $query      = $this->db->prepare("UPDATE ".TABLE_PREFIX."menu SET `ordering` = '$ordering' WHERE `id` = $upid");
            $query->execute();
            $query      = $this->db->prepare("UPDATE ".TABLE_PREFIX."menu SET `ordering` = '$newordering' WHERE `id` = $id");
            $query->execute();
        }
        else
        {
            $query = $this->db->prepare("UPDATE ".TABLE_PREFIX."menu SET `ordering` = '$newordering' WHERE `id` = $id");
            $query->execute();
        }
    }
    function menuDnOrdering($id)
    {
        $query = $this->db->prepare("SELECT * FROM ".TABLE_PREFIX."menu WHERE id = '$id'");
        $query->setFetchMode(PDO::FETCH_ASSOC);
        $query->execute();
        $data       = $query->fetch();
        $ordering   = $data['ordering'];
        $pos        = $data['pos'];
        $dnorder     =  my_count(TABLE_PREFIX.'menu','id','ordering',$ordering+1,'pos',$pos,-1,-1,-1,-1);
        $newordering = $ordering+1;
        if($dnorder > 0)
        {
            $query = $this->db->prepare("SELECT * FROM ".TABLE_PREFIX."menu WHERE ordering = '$newordering' AND pos = '$pos'");
            $query->setFetchMode(PDO::FETCH_ASSOC);
            $query->execute();
            $data       = $query->fetch();
            $dnid       = $data['id'];
            $query      = $this->db->prepare("UPDATE ".TABLE_PREFIX."menu SET `ordering` = '$ordering' WHERE `id` = $dnid");
            $query->execute();
            $query      = $this->db->prepare("UPDATE ".TABLE_PREFIX."menu SET `ordering` = '$newordering' WHERE `id` = $id");
            $query->execute();
        }
        else
        {
            $query = $this->db->prepare("UPDATE ".TABLE_PREFIX."menu SET `ordering` = '$newordering' WHERE `id` = $id");
            $query->execute();
        }
    }
    function adsMainGroupAdd($mgname,$mgimage)
    {
        $query = $this->db->prepare("INSERT INTO ".TABLE_PREFIX."adsmaingroup VALUES (NULL , '$mgname', '$mgimage')");
        $res = $query->execute();
        if($res)
        {
            $msg = "<font color=green>گروه با موفقیت ثبت گردید</font>";
        }
        else
        {
            $msg = "<font color=red>مشکل در ثبت گروه. مجددا تلاش نمایید</font>";
        }
        return $msg;
    }
    function adsMainGroupEdit($id,$mgname,$mgimage)
    {
        $query = $this->db->prepare("UPDATE ".TABLE_PREFIX."adsmaingroup SET `mgname` = '$mgname',`mgjpg` = '$mgimage' WHERE `mgid` ='$id'");
        $res = $query->execute();
        if($res)
        {
            $msg = "<font color=green>گروه با موفقیت ویرایش گردید</font>";
        }
        else
        {
            $msg = "<font color=red>مشکل در ویرایش گروه</font>";
        }
        return $msg;
    }
    function adsMainGroupGetData($id)
    {
        $query = $this->db->prepare("SELECT * FROM ".TABLE_PREFIX."adsmaingroup WHERE mgid = $id");
        $query->setFetchMode(PDO::FETCH_ASSOC);
        $query->execute();
        $data = $query->fetch();
        return $data;
    }
    function adsMainGroupDelete($id)
    {
        $query = $this->db->prepare("DELETE FROM ".TABLE_PREFIX."adsmaingroup WHERE mgid = $id ");
        $res = $query->execute();
    }
    function adsSubGroupAdd($sgname,$mgid)
    {
        $query = $this->db->prepare("INSERT INTO ".TABLE_PREFIX."adssubgroup VALUES (NULL , '$mgid', '$sgname')");
        $res = $query->execute();
        if($res)
        {
            $msg = "<font color=green>گروه با موفقیت ثبت گردید</font>";
        }
        else
        {
            $msg = "<font color=red>مشکل در ثبت گروه. مجددا تلاش نمایید</font>";
        }
        return $msg;
    }
    function adsSubGroupEdit($id,$sgname,$mgid)
    {
        $query = $this->db->prepare("UPDATE ".TABLE_PREFIX."adssubgroup SET `sgname` = '$sgname',`mgid` = '$mgid' WHERE `sgid` ='$id'");
        $res = $query->execute();
        if($res)
        {
            $msg = "<font color=green>گروه با موفقیت ویرایش گردید</font>";
        }
        else
        {
            $msg = "<font color=red>مشکل در ویرایش گروه</font>";
        }
        return $msg;
    }
    function adsSubGroupGetData($id)
    {
        $query = $this->db->prepare("SELECT * FROM ".TABLE_PREFIX."adssubgroup WHERE sgid = $id");
        $query->setFetchMode(PDO::FETCH_ASSOC);
        $query->execute();
        $data = $query->fetch();
        return $data;
    }
    function adsSubGroupDelete($id)
    {
        $query = $this->db->prepare("DELETE FROM ".TABLE_PREFIX."adssubgroup WHERE sgid = $id ");
        $res = $query->execute();
    }
    function userListDelete($id)
    {
        $query = $this->db->prepare("DELETE FROM ".TABLE_PREFIX."user WHERE `id` = '$id'");
        $res = $query->execute();       
        if($res)
        {
            $query = $this->db->prepare("DELETE FROM ".TABLE_PREFIX."advertise WHERE `uid` = '$id'");
            $res = $query->execute();
            if($res)
            {
                $query = $this->db->prepare("DELETE FROM ".TABLE_PREFIX."message WHERE `uid` = '$id'");
                $res = $query->execute();
                if($res)
                {
                    $query = $this->db->prepare("DELETE FROM ".TABLE_PREFIX."adscost WHERE `uid` = '$id'");
                    $res = $query->execute();
                    if($res)
                    {
                        $query = $this->db->prepare("DELETE FROM ".TABLE_PREFIX."fish WHERE `uid` = '$id'");
                        $res = $query->execute();
                        if($res)
                        {
                            $msg = "<font color=green>کاربر با موفقیت حذف گردید</font>";
                        }
                        else
                        {
                           $msg = "<font color=red>کاربر، آگهی و پیام ها و فیش های مرتبط با کاربر حذف گردید.هزینه آگهی های این کاربر باقی مانده است</font>";
                        }
                    }
                    else
                    {
                        $msg = "<font color=red>کاربر، آگهی و پیام های مرتبط با کاربر حذف گردید.فیش و هزینه آگهی های این کاربر باقی مانده است</font>";
                    }
                }
                else
                {
                    $msg = "<font color=red>تنها کاربر و آگهی های مرتبط حذف گردید. پیام،فیش و هزینه آگهی های این کاربر باقی مانده است</font>";
                }
            }
            else
            {
                $msg = "<font color=red>تنها کاربر حذف گردید. آگهی،پیام،فیش و هزینه آگهی های این کاربر باقی مانده است</font>";
            }
        }
        else
        {
            $msg = "<font color=red>ایراد در حذف کاربر</font>";
        }
        return $msg;
    }
    function adminFooterGetData()
    {
        $query = $this->db->prepare("SELECT * FROM ".TABLE_PREFIX."setting WHERE `id` = 19");
        $query->setFetchMode(PDO::FETCH_ASSOC);
        $query->execute();
        $data = $query->fetch();
        return $data;
    }
    function adminFooterEdit($comment)
    {
        $query = $this->db->prepare("UPDATE ".TABLE_PREFIX."setting SET `value` = '$comment' WHERE `id` = 19");
        $res = $query->execute();
        if($res)
        {
            $msg = "<font color=green>پاصفحه با موفقیت ویرایش شد.</font>";
        }
        else
        {
            $msg = "<font color=red>ویرایش با مشکل مواجه شد.</font>";
        }
        return $msg;;
    }
    function emailTemplateDelete($id)
    {
        $query = $this->db->prepare("DELETE FROM ".TABLE_PREFIX."emailtemplate WHERE `id`='$id' ");
        $res = $query->execute();
        if($res)
        {
            $msg = "<font color=green>نامه با موفقیت حذف گردید</font>";
        }
        else
        {
            $msg = "<font color=red>خطا در حذف نامه</font>";
        }
    }
    function emailTemplateGetData($id)
    {
        $query = $this->db->prepare("SELECT * FROM ".TABLE_PREFIX."emailtemplate WHERE `id` = '$id' ");
        $query->setFetchMode(PDO::FETCH_ASSOC);
        $query->execute();
        $data = $query->fetch();
        return $data;
    }
    function emailTemplateAdd($name,$content)
    {
        $query = $this->db->prepare("INSERT INTO ".TABLE_PREFIX."emailtemplate (`id` ,`name` ,`content` )VALUES (NULL , '$name', '$content')");
        $res = $query->execute();
        if($res)
        {
			$msg = "<font color=green>نامه ایجاد شد.</font>";
		}
		else
		{
			$msg = "<font color=red>ایرا در بانک اطلاعاتی</font>";
		}
        return $msg;   
    }
    function emailTemplateEdit($id,$name,$content)
    {   
        $query = $this->db->prepare("UPDATE ".TABLE_PREFIX."emailtemplate SET name = $name,content = $content WHERE id = $id ");
        $res = $query->execute();
        if($res)
        {
			$msg = "<font color=green>صفحه با موفقیت ویرایش شد</font>";
		}
		else
		{
			$msg = "<font color=red>مشکل در ویرایش صفحه</font>";
		}
        return $msg;;
    }
    function emailSend($eid,$subject,$userId)
    {
            $query = $this->db->prepare("SELECT * FROM ".TABLE_PREFIX."emailtemplate WHERE `id` = '$eid' ");
            $query->setFetchMode(PDO::FETCH_ASSOC);
            $query->execute();
            $data    = $query->fetch();
            $content = $data['content'];
            
            $len = count($userId);
            $com = ",";	
            
            for($i = 0;$i <= $len;$i++)
            {		
                $query = $this->db->prepare("SELECT * FROM ".TABLE_PREFIX."user WHERE `id` = '$userId[$i]'");
                $query->setFetchMode(PDO::FETCH_ASSOC);
                $query->execute();
                $data  = $query->fetch();
                $email = $data['email'];
                
                $header  = 'MIME-Version: 1.0' . "\r\n";
                $header .= 'Content-type: text/html; charset=utf-8' . "\r\n";
                $header .= 'From: ';
                $header .= SITE_NAME;
                $header .= '<';
                $header .= SITE_EMAIL;
                $header .= '>' . "\r\n";

                $message = $content;

                $time = time();

                $sentmail = mail($email,$subject,$message,$header);

                if($sentmail)
                {
                    $status = "<font color=green>ارسال شد</font>";
                }
                else
                {
                    $status = "<font color=red>ارسال نشد</font>";       
                } 
                sleep(2);
            }
            return $status;
    }
    function rqDelete($id)
    {
        $query = $this->db->prepare("DELETE FROM ".TABLE_PREFIX."rq WHERE `id`='$id'");
        $res = $query->execute();
        if($res)
        {
            $query = $this->db->prepare("SELECT * FROM ".TABLE_PREFIX."rq");
            $query->setFetchMode(PDO::FETCH_ASSOC);
            $query->execute();
            $data  = $query->fetchAll();
            count($data);
            
            for($i=0;$i<count($data);$i++)
            {
                $j=$i+1;
                $id = $data[$i]['id'];
                $query = $this->db->prepare("UPDATE ".TABLE_PREFIX."rq SET `row` = '$j' WHERE `id` = '$id'");
                $res = $query->execute();
                $msg = "<font color=red>حذف با موفقیت انجام شد.</font>";
            }	
        }
        else
        {
            $msg = "<font color=red>خطا در حذف</font>";
        }
        return $msg;
    }
    function rqGetData($id)
    {
        $query = $this->db->prepare("SELECT * FROM ".TABLE_PREFIX."rq WHERE `id` = '$id' ");
        $query->setFetchMode(PDO::FETCH_ASSOC);
        $query->execute();
        $data = $query->fetch();
        return $data;
    }
    function rqAdd($question,$answer)
    {
        $row = my_max(TABLE_PREFIX.'rq','row',-1,-1,-1,-1,-1,-1,-1,-1);
        $row = $row + 1;
        $query = $this->db->prepare("INSERT INTO ".TABLE_PREFIX."rq VALUES (NULL , '$row', '$question', '$answer')");
        $res = $query->execute();
        if($res)
        {
            $query = $this->db->prepare("SELECT * FROM ".TABLE_PREFIX."rq");
            $query->setFetchMode(PDO::FETCH_ASSOC);
            $query->execute();
            $data  = $query->fetchAll();
            count($data);
            
            for($i=0;$i<count($data);$i++)
            {
                $j=$i+1;
                $id = $data[$i]['id'];
                $query = $this->db->prepare("UPDATE ".TABLE_PREFIX."rq SET `row` = '$j' WHERE `id` = '$id'");
                $res = $query->execute();
            }
            $msg = "<font color=green>عملیات با موفقیت انجام شد.</font>";
        }
        else
        {
            $msg = "<font color=red>مشکل در ثیت</font>";
        }
        return $msg;
    }
    function rqEdit($id,$question,$answer)
    {   
        $query = $this->db->prepare("UPDATE ".TABLE_PREFIX."rq SET `answer` = '$answer',`question` = '$question' WHERE `id` ='$id'");
        $res = $query->execute();
        if($res)
        {
			$msg = "<font color=green>ویرایش با موفقیت انجام شد</font>";
		}
		else
		{
			$msg = "<font color=red>مشکل در ویرایش</font>";
		}
        return $msg;;
    }
    function settingEdit($ads_on_first_page,$star_price ,$link_price,$ads_sp_price,$gift,$onvan,$image_ads_show,$smsWebservise,$smsNumber,$smsUsername,$smsPassword,$siteEmail,$ip1,$ip2,$registerMode,$loginNotConfirmedEmail,$galeryThemes,$adsCol)
    {
        $query = $this->db->prepare("UPDATE ".TABLE_PREFIX."setting SET `value` = '$ads_on_first_page' WHERE `id` = '1'");
        if($query->execute())
        {
            $query = $this->db->prepare("UPDATE ".TABLE_PREFIX."setting SET `value` = '$star_price' WHERE `id` = '2'");
            if($query->execute())
            {
                $query = $this->db->prepare("UPDATE ".TABLE_PREFIX."setting SET `value` = '$link_price' WHERE `id` = '3'");
                if($query->execute())
                {
                    $query = $this->db->prepare("UPDATE ".TABLE_PREFIX."setting SET `value` = '$ads_sp_price' WHERE `id` = '4'");
                    if($query->execute())
                    {
                        $query = $this->db->prepare("UPDATE ".TABLE_PREFIX."setting SET `value` = '$onvan' WHERE `id` = '5'");
                        if($query->execute())
                        {
                            $query = $this->db->prepare("UPDATE ".TABLE_PREFIX."setting SET `value` = '$image_ads_show' WHERE `id` = '6'");
                            if($query->execute())
                            {
                                $query = $this->db->prepare("UPDATE ".TABLE_PREFIX."setting SET `value` = '$smsWebservise' WHERE `id` = '7'");
                                if($query->execute())
                                {
                                    $query = $this->db->prepare("UPDATE ".TABLE_PREFIX."setting SET `value` = '$smsNumber' WHERE `id` = '8'");
                                    if($query->execute())
                                    {
                                        $query = $this->db->prepare("UPDATE ".TABLE_PREFIX."setting SET `value` = '$smsUsername' WHERE `id` = '9'");
                                        if($query->execute())
                                        {
                                            $query = $this->db->prepare("UPDATE ".TABLE_PREFIX."setting SET `value` = '$smsPassword' WHERE `id` = '10'");
                                            if($query->execute())
                                            {
                                                $query = $this->db->prepare("UPDATE ".TABLE_PREFIX."setting SET `value` = '$siteEmail' WHERE `id` = '12'");
                                                if($query->execute())
                                                {
                                                    $query = $this->db->prepare("UPDATE ".TABLE_PREFIX."setting SET `value` = '$ip1' WHERE `id` = '14'");
                                                    if($query->execute())
                                                    {
                                                        $query = $this->db->prepare("UPDATE ".TABLE_PREFIX."setting SET `value` = '$ip2' WHERE `id` = '15'");
                                                        if($query->execute())
                                                        {
                                                            $query = $this->db->prepare("UPDATE ".TABLE_PREFIX."setting SET `value` = '$registerMode' WHERE `id` = '16'");
                                                            if($query->execute())
                                                            {
                                                                $query = $this->db->prepare("UPDATE ".TABLE_PREFIX."setting SET `value` = '$loginNotConfirmedEmail' WHERE `id` = '17'");
                                                                if($query->execute())
                                                                {
                                                                    $query = $this->db->prepare("UPDATE ".TABLE_PREFIX."setting SET `value` = '$galeryThemes' WHERE `id` = '18'");
                                                                    if($query->execute())
                                                                    {
                                                                        $query = $this->db->prepare("UPDATE ".TABLE_PREFIX."setting SET `value` = '$gift' WHERE `id` = '20'");
                                                                        if($query->execute())
                                                                        {
                                                                            $query = $this->db->prepare("UPDATE ".TABLE_PREFIX."setting SET `value` = '$adsCol' WHERE `id` = '21'");
                                                                            if($query->execute())
                                                                            {
                                                                                $msg = "<font color=green>تغییرات با موفقیت اعمال شد</font>";
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }					
                        }
                    }
                }
            }
        }
        else
        {
            $msg = "<font color=green>تغییرات اعمال نشد. مجددا تلاش کنید</font>";
        }
        return $msg;
    }
    function resetPassword($adminId,$currentPassword,$newPassword,$renewPassword) 
    {
        $query = $this->db->prepare("SELECT * FROM ".TABLE_PREFIX."admin WHERE id = '$adminId'");
        $query->setFetchMode(PDO::FETCH_ASSOC);
        $query->execute();
        $data     = $query->fetch();
        $password = $data['password'];
        
        if(md5($currentPassword) == $password)
        {
            if($newPassword == $renewPassword)
            {
                $query = $this->db->prepare("UPDATE ".TABLE_PREFIX."admin SET `password` = '".md5($newPassword)."' WHERE id='$adminId'");
                if($query->execute())
                {
                    $msg = "<font color=green>تغییر کلمه عبور با موفقیت انجام شد</font>";
                }
                else
                {
                    $msg = "<font color=red>ایراد در ارتباط با بانک اطلاعاتی</font>";
                }
            }
            else
            {
                $msg = "<font color=red>کلمه عبور جدید و تکرار آن یکسان نمی باشد</font>";
            }
        }
        else
        {
            $msg = "<font color=red>کلمه عبور فعلی صحیح نمی باشد</font>";
        }
        return $msg;
    }
}
?>