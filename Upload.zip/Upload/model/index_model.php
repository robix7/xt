<?php
class index_model extends Model
{
    function __construct()
    {
        parent::__construct();
    }
    function maingroup($id)
    {
        
		$query = $this->db->prepare("SELECT * FROM ".TABLE_PREFIX."adsmaingroup WHERE `mgid` = '$id' ");
        $query->setFetchMode(PDO::FETCH_NUM);
        $query->execute();
		$data = $query->fetch();
		$count = $query->rowCount();
        if($count > 0)
        {
            $query = $this->db->prepare("SELECT * FROM ".TABLE_PREFIX."advertise WHERE mgid = '$id' ");
            $query->setFetchMode(PDO::FETCH_ASSOC);
            $query->execute();
            $data = $query->fetchAll();
            return $data;
        }
        else
        {
           header("Location:".URL); 
        }
    }
    function subgroup($id)
    {
		$query = $this->db->prepare("SELECT * FROM ".TABLE_PREFIX."adssubgroup WHERE sgid = '$id' ");
        $query->setFetchMode(PDO::FETCH_NUM);
        $query->execute();
		$data = $query->fetch();
		$count = $query->rowCount();
        if($count > 0)
        {
            $query = $this->db->prepare("SELECT * FROM ".TABLE_PREFIX."advertise WHERE sgid = '$id' ");
            $query->setFetchMode(PDO::FETCH_ASSOC);
            $query->execute();
            $data = $query->fetchAll();
            return $data;
        }
        else
        {
            header("Location:".URL); 
        }
    }
}
?>