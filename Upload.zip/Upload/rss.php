<?php
$rssfeed = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
$rssfeed .= "<rss version=\"2.0\">";
$rssfeed .= "<channel>";
$rssfeed .= "<title>تیتر</title>";
$rssfeed .= "<link>http://yoursite.com</link>";
$rssfeed .= "<description>توضیحات</description>";
$rssfeed .= "<language>fa</language>";
$rssfeed .= "<copyright>Copyright (C) 2014 http://yoursite</copyright>";
mysql_connect("localhost","root","");
mysql_select_db("agahi17");
mysql_query('SET NAMES utf8');
$result = mysql_query("SELECT * FROM ".TABLE_PREFIX."advertise WHERE status = 1")
or die (mysql_error());


while($row = mysql_fetch_array($result)){
 $id = $row['id'];
 $title = $row['subject'];
 
 $title = htmlspecialchars($title, ENT_QUOTES, 'UTF-8');
 $summary = $row['comment'];

 $summary = htmlspecialchars($summary, ENT_QUOTES, 'UTF-8');
 $date = $row['crdate'];// 22-12-1999
 $date = date('Y-m-d',$date);
 $stringArray = explode("-", $date); 
 $date = mktime(0,0,0,$stringArray[1],$stringArray[2],$stringArray[0]); 
 $convert = date("D, j M Y", $date);
 $date = $convert .' '. $row['update'].' '.'GMT';
 $link = "http://domain/viewads.php?adsid=$id";
 $rssfeed .= "<item>";
 $rssfeed .= "<title>" . $title . "</title>";
 $rssfeed .= "<description>" . $summary . "</description>";
 $rssfeed .= "<link>" . $link . "</link>";
 $rssfeed .= "<guid>" . $link . "</guid>"; 
 $rssfeed .= "<pubDate>12333</pubDate>";
 $rssfeed .= "<source url=\"http://domain/rss.xml\">title</source>"; 
 $rssfeed .= "</item>";
 }
$rssfeed .= "</channel>";
$rssfeed .= "</rss>";

$file = "rss.xml";
chmod($file, 0755);
$fileHandle = fopen($file, 'w+') 
or die("خطا: سطح دسترسی برای ویرایش فایل در سرور تنظیم نیست!");
$stringData = $rssfeed;
fwrite($fileHandle, $stringData);
fclose($fileHandle);
?>