<?php
header("Content-Type: text/xml; charset=utf-8");
require "include/config.php";
require "include/db.php";
?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">

   <url>
      <loc>URL</loc>
      <changefreq>always</changefreq>
      <priority>1.0</priority>
   </url>

<?php
$result  = $db->sql_query("SELECT mgid FROM ".TABLE_PREFIX."adsmaingroup");
while($show_result=$db->sql_fetcharray($result))
{
	$mgid = $show_result['mgid'];
	echo "<url><loc>".URL."index/maingroup/".$mgid."</loc><changefreq>always</changefreq><priority>0.6</priority></url>\r\n";	
}

$result  = $db->sql_query("SELECT sgid FROM ".TABLE_PREFIX."adssubgroup");
while($show_result=$db->sql_fetcharray($result))
{
	$sgid = $show_result['sgid'];
	echo "<url><loc>".URL."index/subgroup/".$sgid."</loc><changefreq>always</changefreq><priority>0.6</priority></url>\r\n";	
}

$result  = $db->sql_query("SELECT id,subject FROM ".TABLE_PREFIX."advertise");
while($show_result=$db->sql_fetcharray($result))
{
	$id = $show_result['id'];
	$subject = trim($show_result['subject']);
	echo "<url><loc>".URL."ads/view/".$id."/".space_rep($subject)."</loc><changefreq>always</changefreq><priority>0.6</priority></url>\r\n";	
}
?>

</urlset>