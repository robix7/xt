<?php
include "include/config.php";
$m='';$k='';$n='';$o='';$j='';
$mgid = $_GET["param"];

$cnt = my_count(TABLE_PREFIX.'adssubgroup','sgid','mgid',$mgid,-1,-1,-1,-1,-1,-1);

$subGroup = Group::GetSubGroupById($mgid);
for ($i = 0; $i < count($subGroup); $i++)
{
	$k++;
	$sgid   = $subGroup[$i]['sgid'];
	if($k == 1)
	{
		$m = $cnt.'#'.$sgid;
	}
	else
	{
		$m = $m.'#'.$sgid;
	}
}
$subGroupp = Group::GetSubGroupById($mgid);
for ($i = 0; $i < count($subGroupp); $i++)
{
	$j++;
	$sgname   = $subGroupp[$i]['sgname'];
	if($j == 1)
	{
		$n = $sgname;
	}
	else
	{
		$n = $n.'#'.$sgname;
	}
}
$o = $m."/".$n;
echo $o

?>