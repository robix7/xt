<?php
/*
define('DB_TYPE',        'mysql');
define('DB_PERSISTENCY', 'true');
define('DB_SERVER',      'localhost');
define('DB_USERNAME',    'root');
define('DB_PASSWORD',    '');
define('DB_DATABASE',    'agahi17');
define('DB_CHARSET',     'UTF8');
define('URL', 'http://localhost/agahi17n/');
define('TABLE_PREFIX', 'tbl_');
define('PDO_DSN', 'mysql:host=' . DB_SERVER . ';dbname=' . DB_DATABASE);
include "../../include/mysql.class.php";
include "../../include/database_handler.php";
include "../../include/function.php";
include "../../include/sp/group.php";
$db = new MYSQL(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_DATABASE, FALSE);
$db->sql_connect();
mysql_query('SET NAMES utf8');*/ 
include "../../include/config.php";
$m='';$k='';$n='';$o='';$j='';
$mgid = $_GET["param"];

$cnt = my_count(TABLE_PREFIX.'adssubgroup','sgid','mgid',$mgid,-1,-1,-1,-1,-1,-1);

$subGroup = Group::GetSubGroupById($mgid);
for ($i = 0; $i < count($subGroup); $i++)
{
	$k++;
	$sgid   = $subGroup[$i]['sgid'];
	if($k == 1)
	{
		$m = $cnt.'#'.$sgid;
	}
	else
	{
		$m = $m.'#'.$sgid;
	}
}
$subGroupp = Group::GetSubGroupById($mgid);
for ($i = 0; $i < count($subGroupp); $i++)
{
	$j++;
	$sgname   = $subGroupp[$i]['sgname'];
	if($j == 1)
	{
		$n = $sgname;
	}
	else
	{
		$n = $n.'#'.$sgname;
	}
}
$o = $m."/".$n;
echo $o

?>