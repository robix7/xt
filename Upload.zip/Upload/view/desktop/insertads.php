<?php
require "include/db.php";
if($_SESSION['SUB_USER_ID']){
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fa-ir" lang="fa-ir"><head>
<meta name="Template" content="">
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="robots" content="index, follow">
<meta name="keywords" content="">
<meta name="description" content="">
<title><?php echo SITE_NAME; ?></title>

<script src = "<?php echo URL; ?>include/ajax.js" language="javascript" type="text/javascript" ></script>
<link   href= "<?php echo URL; ?>template/default/css/template.css" rel="stylesheet"      type="text/css" />


<script>
	function adschange(param)
	{
            var b = param.split(",");
            if(b[1] == 1) document.getElementById('url').disabled = false;
            if(b[1] == 0) document.getElementById('url').disabled = true;

            if(b[2] == 3 || b[2] == 4) document.getElementById('star').disabled = false;
            if(b[2] == 3 || b[2] == 4) document.getElementById('timelong').disabled = true;
            if(b[2] == 1 || b[2] == 2) document.getElementById('star').disabled = true;
            if(b[2] == 1 || b[2] == 2) document.getElementById('star').value = 0;
            if(b[2] == 1 || b[2] == 2) document.getElementById('timelong').disabled = false;
		
            var img   = document.getElementById('img');
            if(b[2] == 2 || b[2] == 4)
            {
                img.style.display = "inline";
            }
            else
            {
                img.style.display = "none";
            }

            var lnk   = document.getElementById('lnk');
            if(b[1] == 1)
            {

                lnk.style.display = "inline";
            }
            else
            {
                lnk.style.display = "none";
            }

            document.getElementById('adscost').innerHTML=b[0]+"ریال";
            var lod1   = document.getElementById('lod1');
            lod1.style.display = "none";
            var lod2   = document.getElementById('lod2');
            lod2.style.display = "none";
	}
	function conf(subject,comment,kind,timelong,hasurl,url,mgroup,sgroup,name,email,image,star,star_price,link_price,spads_price,etebar)
	{
            var purl = 0;
            var cost = 0;
            var vtimelong = 0;
            var img = 0;
            if((kind == 2 || kind == 4) && image == '') img = 1;
            if((kind == 1 || kind == 2) && timelong == 0) vtimelong = 1;
            if(hasurl == 1 && url == '') purl = 1;

            if(kind == 1 || kind == 2)
            {
                cost = hasurl * link_price;
            }
            if(kind == 3 || kind == 4)
            {
                cost = spads_price + hasurl * link_price + star * star_price;
            }

            if(subject == '' || comment == '' || name =='' || email =='' || vtimelong == 1 || purl == 1 || mgroup == 0 || sgroup == 0 || sgroup == -1 || img == 1)
            {
                alert("فیلدهای ستاره دار را کامل نمایید");
                return false;
            }
            else
            {
                if(cost > etebar)
                {
                    alert("اعتبار شما برای درج این آگهی کافی نیست");
                    return false;
                }
                else
                {
                    if(confirm("آیا برای ثبت این آگهی مطمئن هستید؟"))
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
            }
	}
	function adsChangeMainGroup(mg)
	{
            var mgs = mg.split("/");
            var mgid   = mgs[0];
            var mgname = mgs[1];
            var idm   = mgid.split("#");
            var namem = mgname.split("#");
            var i = 0;
            var j = 0;
            var len = idm[0];

            with(document.getElementById('sgroup'))
            {
                    options.length = 0;
                    options[0] = new Option('زیرگروه را انتخاب کنید' , '-1');
                    for(i = 0; i < len; i++)
                    {
                            k = i+1;
                            j = i+1;
                            options[k] = new Option(namem[i],idm[j]);
                    }
            }
            document.getElementById('sgroup').disabled = false;
            var lod   = document.getElementById('lod');
            lod.style.display = "none";
	}
	function load()
	{
            var lod   = document.getElementById('lod');
            lod.style.display = "inline";
	}
	function load1()
	{
            var lod1   = document.getElementById('lod1');
            lod1.style.display = "inline";
            var lod2   = document.getElementById('lod2');
            lod2.style.display = "inline";
	}
</script>
</head>
<body id="bd" class="fs3 FF">
<div id="ja-wrapper">
	<a name="Top" id="Top"></a>
	<div id="ja-container" class="wrap ja-l1r1">
		<div class="main clearfix">
			<div id="ja-mainbody" style="width:80%">
                <div id="ja-main" style="width:100%">
                    <div class="inner ja-box-br">
                        <div class="ja-box-bl">
                            <div class="ja-box-tr">
                                <div class="ja-box-tl clearfix">
                                    <div id="ja-breadcrums">
                                        <div class="inner clearfix">
                                            <strong></strong> <span class="breadcrumbs pathway">درج آگهی</span>
                                        </div>
                                    </div>
                                    <div id="ja-contentwrap" class="">
                                        <div id="ja-content" class="column" style="width:100%">
                                            <div id="ja-current-content" class="column" style="width:100%">
                                                <div class="ja-content-main clearfix">
                                                    <form name="newad" method="post" enctype="multipart/form-data" action="">	
                                                        <div>
                                                            <div style="float:right; text-align:right; width:20%;height:30px;">
                                                                گروه <font color=red>*</font>
                                                            </div>
                                                            <div style="text-align:right; width:60%;height:30px;">
                                                                <select name="mgroup" id="mgroup" class="inp2" OnChange="changeMainGroup(this.value,<?php echo $this->edit; ?>);sgroup.disabled=true;load()">
                                                                    <option value='0'>گروه را انتخاب کنید</option>
                                                                    <?php	

                                                                        $mainGroup = Group::GetMainGroup();
                                                                        for ($i = 0; $i < count($mainGroup); $i++)
                                                                        {
                                                                            $mgid1   = $mainGroup[$i]['mgid'];
                                                                            $mgname1 = $mainGroup[$i]['mgname'];
                                                                            if($mgid1 == $this->mgid) $s ="selected";
                                                                            echo "<option value='$mgid1' $s>$mgname1</option>";
                                                                            $s = "";
                                                                        }
                                                                    ?>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <div>
                                                            <div style="float:right; text-align:right; width:20%;height:30px;">
                                                                زیرگروه <font color=red>*</font>
                                                            </div>
                                                            <div style="float:left; text-align:right; width:80%;height:30px;">
                                                                <div style="float:right; text-align:right;">
                                                                    <select name="sgroup" id="sgroup" class="inp2" onChange="cha(this.value)">
                                                                        <option value='0'>زیرگروه را انتخاب کنید</option>
                                                                        <?php 					
                                                                        if($this->edit == 1)
                                                                        {

                                                                            $subGroup = Group::GetSubGroup();
                                                                            for ($i = 0; $i < count($subGroup); $i++)
                                                                            {
                                                                                $sgid1   = $subGroup[$i]['sgid'];
                                                                                $sgname1 = $subGroup[$i]['sgname'];
                                                                                if($sgid1 == $this->sgid) $s ="selected";
                                                                                echo "<option value='$sgid1' $s>$sgname1</option>";
                                                                                $s = "";
                                                                            }
                                                                        }
                                                                        ?>
                                                                    </select>
                                                                </div>
                                                                <div id="lod" 	style="float:right; text-align:left;display:none;">
                                                                    <img src="<?php echo URL; ?>template/default/image/loading.gif" />
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div>
                                                            <div style="float:right; text-align:right; width:20%;height:30px;">
                                                                عنوان <font color=red>*</font>
                                                            </div>
                                                            <div style="float:left; text-align:right; width:80%;height:30px;">
                                                                <input name="subject" id="subject" value="<?php echo $this->subject; ?>" class="inp1" type="text">
                                                            </div>

                                                        </div>
                                                        <div>
                                                            <div style="float:right; text-align:right; width:20%;height:225px;">
                                                                شرح آگهی <font color=red>*</font>
                                                            </div>
                                                            <div style="float:left; text-align:right; width:80%;height:235px;">
                                                                <textarea name="comment" id="comment" rows="10" cols="44" style="color:#414141;background-color:LightGrey;"><?php echo $this->comment; ?></textarea>
                                                            </div>
                                                        </div>
                                                        <div>
                                                            <div style="float:left; text-align:right; width:35%;height:30px;">
                                                                کلمات را با "+" از هم جدا نمایید
                                                            </div>
                                                            <div style="float:right; text-align:right; width:20%;height:30px;">
                                                                کلمات کلیدی
                                                            </div>
                                                            <div style="float:left; text-align:right; width:45%;height:30px;">
                                                                <input name="keyword" id="keyword" value="<?php echo $this->keyword; ?>" class="inp1" type="text" maxlength="100">
                                                            </div>

                                                        </div>
                                                        <div>
                                                            <div style="float:right; text-align:right; width:20%;height:30px;">
                                                                قیمت
                                                            </div>
                                                            <div style="float:left; text-align:right; width:80%;height:30px;">
                                                                <input name="adsprice" id="adsprice" value="<?php echo $this->price; ?>" class="inp1" type="text">
                                                            </div>
                                                        </div>
                                                        <div style="display:<?php echo $this->sp; ?>">
                                                            <div style="float:right; text-align:right; width:20%;height:30px;">
                                                                نوع
                                                            </div>
                                                            <div style="float:left; text-align:right; width:80%;height:30px;">
                                                                <select name="kind" id="kind" dir="rtl" class="inp2" onChange="link_change(kind.value,hasurl.value,star.value,<?php echo $this->edit; ?>);load1();" <?php echo $this->kind_dis; ?> >
                                                                    <?php
                                                                    if($this->edit == 1)
                                                                    {
                                                                        
                                                                        if($this->kind == 1)
                                                                        {
                                                                            ?>
                                                                            <option value="1" selected="selected" >رایگان متنی</option>
                                                                            <option value="2">رایگان عکس دار</option>
                                                                            <option value="3">ویژه متنی</option>
                                                                            <option value="4">ویژه عکس دار</option>
                                                                            <?php
                                                                        }
                                                                        if($this->kind == 2)
                                                                        {
                                                                            ?>
                                                                            <option value="1">رایگان متنی</option>
                                                                            <option value="2" selected="selected" >رایگان عکس دار</option>
                                                                            <option value="3">ویژه متنی</option>
                                                                            <option value="4">ویژه عکس دار</option>
                                                                            <?php
                                                                        }
                                                                        if($this->kind == 3)
                                                                        {
                                                                            ?>
                                                                            <option value="1">رایگان متنی</option>
                                                                            <option value="2">رایگان عکس دار</option>
                                                                            <option value="3" selected="selected" >ویژه متنی</option>
                                                                            <option value="4">ویژه عکس دار</option>
                                                                            <?php
                                                                        }
                                                                        if($this->kind == 4)
                                                                        {
                                                                            ?>
                                                                            <option value="1">رایگان متنی</option>
                                                                            <option value="2">رایگان عکس دار</option>
                                                                            <option value="3">ویژه متنی</option>
                                                                            <option value="4" selected="selected" >ویژه عکس دار</option>
                                                                            <?php
                                                                        }
                                                                    }
                                                                    else
                                                                    {
                                                                        ?>
                                                                            <option value="1" selected="selected" >رایگان متنی</option>
                                                                            <option value="2">رایگان عکس دار</option>
                                                                            <option value="3">ویژه متنی</option>
                                                                            <option value="4">ویژه عکس دار</option>
                                                                        <?php
                                                                    }
                                                                    ?>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <div style="display:<?php echo $this->sp; ?>">
                                                            <div style="float:right; text-align:right; width:20%;height:30px;">
                                                                اعتبار<font color=red>*</font>
                                                            </div>
                                                            <div style="float:left; text-align:right; width:80%;height:30px;">
                                                                <div style="float:right; text-align:right;">
                                                                    <select name="timelong" id="timelong" class="inp2" <?php echo $this->timelong_dis; ?> >
                                                                        <?php
                                                                        if($this->edit == 1)
                                                                        {
                                                                            if($this->kind == 3 OR $this->kind == 4)
                                                                            {
                                                                                ?>
                                                                                <option value="0" selected="selected"></option>     
                                                                                <option value="7">یک هفته</option>
                                                                                <option value="30">یک ماه</option>
                                                                                <option value="60">دو ماه</option>
                                                                                <?php
                                                                            }
                                                                            else
                                                                            {
                                                                                if($this->timelong == 7)
                                                                                {
                                                                                    ?>		
                                                                                        <option selected="selected" value="7">یک هفته</option>
                                                                                        <option value="30">یک ماه</option>
                                                                                        <option value="60">دو ماه</option>
                                                                                    <?php
                                                                                }
                                                                                if($this->timelong == 30)
                                                                                {
                                                                                    ?>		
                                                                                        <option value="7">یک هفته</option>
                                                                                        <option selected="selected" value="30">یک ماه</option>
                                                                                        <option value="60">دو ماه</option>
                                                                                    <?php
                                                                                }
                                                                                if($this->timelong == 60)
                                                                                {
                                                                                    ?>		
                                                                                        <option value="7">یک هفته</option>
                                                                                        <option value="30">یک ماه</option>
                                                                                        <option selected="selected" value="60">دو ماه</option>
                                                                                    <?php
                                                                                }
                                                                            }
                                                                        }
                                                                        else
                                                                        {
                                                                            ?>
                                                                            <option value="0" selected="selected"></option>     
                                                                            <option value="7">یک هفته</option>
                                                                            <option value="30">یک ماه</option>
                                                                            <option value="60">دو ماه</option>
                                                                            <?php
                                                                        }
                                                                        ?>
                                                                    </select>
                                                                </div>
                                                                <div id="lod1" style="float:right; text-align:left;display:none;">
                                                                    <img src="<?php echo URL; ?>template/default/image/loading.gif">
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <?php
                                                        if($this->edit == 1 AND ($this->kind == 2 OR $this->kind == 4))
                                                        {
                                                            ?>
                                                            <div>
                                                                <div style="float:right; text-align:right; width:20%;height:120px;">
                                                                    تصویر فعلی
                                                                </div>
                                                                <div style="float:left; text-align:right; width:80%;height:120px;">
                                                                    <img src="<?php echo URL; ?>images/ads/med/<?php echo $this->adsid; ?>.jpg" border="0" tabindex="8">
                                                                </div>
                                                            </div>
                                                            <?php
                                                        }
                                                        ?>
                                                        <?php
                                                            if($this->kind == 2 OR $this->kind == 4)
                                                            {
                                                                ?>
                                                                <div id="img">
                                                                <?php
                                                            }
                                                            else
                                                            {
                                                                ?>
                                                                <div id="img" style="display:none">   
                                                                <?php
                                                            }
                                                        ?>
                                                        <div style="float:right; text-align:right; width:20%;height:30px;">
                                                            تصویر<font color=red>*</font>
                                                        </div>
                                                        <div style="float:left; text-align:right; width:80%;height:30px;">
                                                            <input name="image" id="image" class="inp1" type="file">
                                                        </div>
                                                        </div>
                                                        <div style="display:<?php echo $this->sp; ?>">
                                                            <div style="float:right; text-align:right; width:20%;height:30px;">
                                                                لینک سایت
                                                            </div>
                                                            <div style="float:left; text-align:right; width:80%;height:30px;">
                                                                <?php
                                                                if($this->edit == 1)
                                                                {
                                                                    ?>
                                                                    <select name="hasurl" id="hasurl" class="inp2" onChange="link_change(kind.value,hasurl.value,star.value,<?php echo $this->edit; ?>)">
                                                                        <?php
                                                                        if($this->hasurl == 0)
                                                                        {
                                                                            ?>
                                                                            <option selected="selected" value="0">بدون لینک</option>
                                                                            <option value="1">لینک دار</option>
                                                                            <?php
                                                                        }
                                                                        if($this->hasurl == 1)
                                                                        {
                                                                            ?>
                                                                            <option value="0">بدون لینک</option>
                                                                            <option selected="selected" value="1">لینک دار</option>
                                                                            <?php
                                                                        }
                                                                        ?>
                                                                    </select>
                                                                    <?php
                                                                }
                                                                else
                                                                {
                                                                    ?>
                                                                    <select name="hasurl" id="hasurl" class="inp2"  onChange="link_change(kind.value,hasurl.value,star.value,<?php echo $this->edit; ?>)">
                                                                        <option selected="selected" value="0">بدون لینک</option>
                                                                        <option value="1">لینک دار</option>
                                                                    </select>
                                                                    <?php
                                                                }
                                                                ?>
                                                            </div>
                                                        </div>
                                                        <div id="lnk" style="display:<?php echo $this->linkdiv; ?>">
                                                            <div style="float:right; text-align:right; width:20%;height:30px;">
                                                            
                                                            </div>
                                                            <div style="float:left; text-align:right; width:80%;height:30px;">
                                                                <input name="url" id="url" <?php echo $this->link_dis; ?> value = "<?php echo $this->link_value; ?>" <?php echo $this->linkvalue_dis; ?> dir = "ltr" class="inp1" type="text" />
                                                                لینک باید با http:// شروع شود.
                                                            </div>
                                                        </div>
                                                        <div  style="display:<?php echo $this->sp; ?>">
                                                            <div style="float:right; text-align:right; width:20%;height:30px;">
                                                                ستاره
                                                            </div>
                                                            <div style="float:left; text-align:right; width:80%;height:30px;">
                                                                <div style="float:right; text-align:right;">
                                                                    <?php
                                                                    if($this->edit == 1)
                                                                    {
                                                                        ?>
                                                                        <select name="star" id="star" <?php echo $this->star_dis; ?> class="inp2" onChange="link_change(kind.value,hasurl.value,star.value,<?php echo $this->edit; ?>)" >
                                                                            <?php if($this->star == 0) { ?> <option selected="selected" value=0>0</option><option value=1>1</option><option value=2>2</option><option value=3>3</option><option value=4>4</option><option value=5>5</option><option value=6>6</option><option value=7>7</option> <?php } ?>
                                                                            <?php if($this->star == 1) { ?> <option value=0>0</option><option selected="selected" value=1>1</option><option value=2>2</option><option value=3>3</option><option value=4>4</option><option value=5>5</option><option value=6>6</option><option value=7>7</option> <?php } ?>
                                                                            <?php if($this->star == 2) { ?> <option value=0>0</option><option value=1>1</option><option selected="selected" value=2>2</option><option value=3>3</option><option value=4>4</option><option value=5>5</option><option value=6>6</option><option value=7>7</option> <?php } ?>
                                                                            <?php if($this->star == 3) { ?> <option value=0>0</option><option value=1>1</option><option value=2>2</option><option selected="selected" value=3>3</option><option value=4>4</option><option value=5>5</option><option value=6>6</option><option value=7>7</option> <?php } ?>
                                                                            <?php if($this->star == 4) { ?> <option value=0>0</option><option value=1>1</option><option value=2>2</option><option value=3>3</option><option selected="selected" value=4>4</option><option value=5>5</option><option value=6>6</option><option value=7>7</option> <?php } ?>
                                                                            <?php if($this->star == 5) { ?> <option value=0>0</option><option value=1>1</option><option value=2>2</option><option value=3>3</option><option value=4>4</option><option selected="selected" value=5>5</option><option value=6>6</option><option value=7>7</option> <?php } ?>
                                                                            <?php if($this->star == 6) { ?> <option value=0>0</option><option value=1>1</option><option value=2>2</option><option value=3>3</option><option value=4>4</option><option value=5>5</option><option selected="selected" value=6>6</option><option value=7>7</option> <?php } ?>
                                                                            <?php if($this->star == 7) { ?> <option value=0>0</option><option value=1>1</option><option value=2>2</option><option value=3>3</option><option value=4>4</option><option value=5>5</option><option value=6>6</option><option selected="selected" value=7>7</option> <?php } ?>
                                                                        </select>
                                                                        <?php

                                                                    }
                                                                    else
                                                                    {
                                                                        ?>
                                                                        <select name="star" id="star" <?php echo $this->star_dis; ?> class="inp2" onChange="link_change(kind.value,hasurl.value,star.value,<?php echo $this->edit; ?>)">
                                                                            <option selected="selected" value = 0>0</option>
                                                                            <option value = 1 >1</option>
                                                                            <option value = 2 >2</option>
                                                                            <option value = 3 >3</option>
                                                                            <option value = 4 >4</option>
                                                                            <option value = 5 >5</option>
                                                                            <option value = 6 >6</option>
                                                                            <option value = 7 >7</option>
                                                                        </select>
                                                                        <?php
                                                                    }
                                                                    ?>
                                                                </div>
                                                                <div id="lod2" 	style="float:right; text-align:left;display:none;">
                                                                    <img src="<?php echo URL; ?>template/default/image/loading.gif">
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div>
                                                            <div style="float:right; text-align:right; width:20%;height:30px;">
                                                                نام<font color=red>*</font>
                                                            </div>
                                                            <div style="float:left; text-align:right; width:80%;height:30px;">
                                                                <input name="name" id="name" class="inp1" type="text" value = "<?php echo $this->name; ?>" >
                                                            </div>
                                                        </div>
                                                        <div>
                                                            <div style="float:right; text-align:right; width:20%;height:30px;">
                                                                ایمیل<font color=red>*</font>
                                                            </div>
                                                            <div style="float:left; text-align:right; width:80%;height:30px;">
                                                                <input name="email" id="email" dir="ltr" value = "<?php echo $this->email; ?>" class="inp1" type="text">
                                                            </div>
                                                        </div>
                                                        <div>
                                                            <div style="float:right; text-align:right; width:20%;height:30px;">
                                                                تلفن
                                                            </div>
                                                            <div style="float:left; text-align:right; width:80%;height:30px;">
                                                                <input name="tel" id="tel" dir="ltr" value = "<?php echo $this->tel; ?>" class="inp1" type="text" >
                                                            </div>
                                                        </div>
                                                        <div>
                                                            <div style="float:right; text-align:right; width:20%;height:30px;">
                                                                موبایل
                                                            </div>
                                                            <div style="float:left; text-align:right; width:80%;height:30px;">
                                                                <input name="mobile" id="mobile" dir="ltr" value = "<?php echo $this->mobile; ?>" class="inp1" type="text">
                                                            </div>
                                                        </div>
                                                        <div>
                                                            <div style="float:right; text-align:right; width:20%;height:30px;">
                                                                Yahoo ID
                                                            </div>
                                                            <div style="float:left; text-align:right; width:80%;height:30px;">
                                                                <input name="yahooid" id="yahooid" dir="ltr" value = "<?php echo $this->yahooid; ?>" class="inp1" type="text">
                                                            </div>
                                                        </div>
                                                        <div>
                                                            <div style="float:right; text-align:right; width:20%;height:30px;">
                                                                آدرس
                                                            </div>
                                                            <div style="float:left; text-align:right; width:80%;height:30px;">
                                                                <input name="address" id="address" value = "<?php echo $this->address; ?>" class="inp1" type="text" maxlength="80">
                                                            </div>
                                                        </div>
                                                        <div style="display:<?php echo $this->sp; ?>">
                                                            <div style="float:right; text-align:right; width:20%;height:30px;">
                                                                مبلغ این آگهی
                                                            </div>
                                                            <div name="adscost" id="adscost" style="float:left; text-align:right; width:80%;height:30px;">
                                                                <?php
                                                                if($this->edit == 1)
                                                                {
                                                                    echo $this->cost."ریال";
                                                                }
                                                                else
                                                                {
                                                                    echo "0 ریال";
                                                                }
                                                                ?>
                                                            </div>
                                                        </div>
                                                        <div style="display:<?php echo $this->sp; ?>">
                                                            <div style="float:right; text-align:right; width:20%;height:30px;">
                                                                اعتبار شما
                                                            </div>
                                                            <div style="float:left; text-align:right; width:80%;height:30px;">
                                                                <strong><?php echo sefr($this->etebar); ?>ریال</strong>
                                                            </div>
                                                        </div>
                                                        <div>
                                                            <div style="float:right; text-align:right; width:20%;height:30px;">

                                                            </div>                                                                           
                                                            <div style="float:left; text-align:right; width:80%;height:30px;">
                                                                <?php
                                                                if($this->edit == 1)
                                                                {
                                                                    ?>
                                                                    <input value="<?php echo $this->adsid; ?>" name="adsid" id="adsid" type="hidden" />
                                                                    <input value="1" name="editmode" id="editmode" type="hidden" />
                                                                    <input class="inputbox" dir="rtl" value="  ویرایش  " name="addads" id="addads" style="width: 100px;" type="submit" onclick="return conf(subject.value,comment.value,kind.value,timelong.value,hasurl.value,url.value,mgroup.value,sgroup.value,name.value,email.value,image.value,star.value,<?php echo STAR_PRICE;?>,<?php echo LINK_PRICE;?>,<?php echo SPADS_PRICE;?>,<?php echo $this->etebar; ?>)" />
                                                                    <?php
                                                                }
                                                                else
                                                                {
                                                                    ?>
                                                                    <input value="0" name="editmode" id="editmode" type="hidden" />
                                                                    <input class="inputbox" dir="rtl" value="  ثبت  " name="addads" id="addads" style="width: 100px;" type="submit" onclick="return conf(subject.value,comment.value,kind.value,timelong.value,hasurl.value,url.value,mgroup.value,sgroup.value,name.value,email.value,image.value,star.value,<?php echo STAR_PRICE;?>,<?php echo LINK_PRICE;?>,<?php echo SPADS_PRICE;?>,<?php echo $this->etebar; ?>)" />
                                                                    <?php
                                                                }
                                                                ?>
                                                                <input class="inputbox" dir="rtl" value="  انصراف  " name="canads" id="canads" style="width: 100px;" type="button" onclick=window.location='<?php echo URL; ?>desktop/index' /> 
                                                            </div>
                                                        </div>
                                                        <div>
                                                            <div style="float:right; text-align:right; width:20%;height:30px;">

                                                            </div>
                                                            <div style="float:left; text-align:right; width:80%;height:30px;">
                                                                <?php 
                                                                echo $this->msg;
                                                                ?>
                                                            </div>
                                                        </div>
                                                        <div>
                                                            <div style="float:right; text-align:right; width:20%;height:50px;">

                                                            </div>
                                                            <div style="float:left; text-align:right; width:80%;height:50px;">

                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
			</div>
			<?php include "usermenu.php"; ?>
		</div>
	</div>
	<div id="ja-footer" class="wrap">
		<div class="main clearfix">
			<div class="ja-footnav clearfix">
				<ul class="ja-links">
					<li class="top">
						<a href="#Top" title="Back to Top">بالا</a>
					</li>
				</ul>
			</div>

			<div>
				<div align="center">
					<p><?php echo SITE_FOOTER; ?></p>
					﻿<p align ="center"><?php include "copyright.php"; ?></p>
				</div>
			</div>
		</div>
	</div>
</div>
</body></html>
<?php
}
else
{
    header("Location: index.php");    
}
?>