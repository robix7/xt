<?php
require "include/db.php";
if(isset($_SESSION['SUB_USER_ID'])){

$msg = '';$msg1 = '';$msg10 = '';$msg11 = '';$msg12 = '';$msg13 = '';$name = '';$empty = '';$hasimage = 0;$c="";

$uid = $_SESSION['SUB_USER_ID'];

if((isset($_GET['cmd']) == "del") && (isset($_GET['id']) != ""))
{
	$id = $_GET['id'];
	if($db->sql_query("DELETE FROM ".TABLE_PREFIX."message WHERE `id`='$id' "))
    {
        redirector("message.php");
    }
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fa-ir" lang="fa-ir"><head>
<meta name="Template" content="">
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="robots" content="index, follow">
<meta name="keywords" content="">
<meta name="description" content="">
<title><?php echo SITE_NAME; ?></title>

<link href="<?php echo URL; ?>template/default/css/template.css" rel="stylesheet" type="text/css">

<script>
	function conf()
	{
		if(confirm("آیا برای حذف پیام اطمینان دارید؟"))
		{
		return true;
		}
		else
		{
		return false;
		}
	}
</script>
</head>
<body id="bd" class="fs3 FF">
<div id="ja-wrapper">
	<a name="Top" id="Top"></a>
	<div id="ja-container" class="wrap ja-l1r1">
		<div class="main clearfix">
			<div id="ja-mainbody" style="width:80%">
				<div class="ja-box1">
					<div class="ja-box2">
						<div id="ja-main" style="width:100%">
							<div class="inner ja-box-br">
								<div class="ja-box-bl">
									<div class="ja-box-tr">
										<div class="ja-box-tl clearfix">
											<div id="ja-breadcrums">
												<div class="inner clearfix">
													<strong></strong> <span class="breadcrumbs pathway">پیام ها</span>
												</div>
											</div>
											<div id="ja-contentwrap" class="">
												<div id="ja-content" class="column" style="width:100%">
													<div id="ja-current-content" class="column" style="width:100%">
														<div class="ja-content-main clearfix">
														<?php
															$cnt_query = $db->sql_query("SELECT COUNT(id) FROM ".TABLE_PREFIX."message WHERE uid='$uid'");
															$cnt_a     = mysql_fetch_row($cnt_query);
															$cnt       = $cnt_a[0];
															$r=0;
															if(isset($_GET['page']))
															{
																$page = $_GET['page']; 
															}
															else
															{
																$page = 1;
															}
															$ipp = 10;							
															$pageconf = array(
															'all'=>$cnt ,	 // select count(*) from post where 
															'range'=>$ipp , 	// select * from post limit (inpage-1)*range,range
															'inpage'=>$page,	// current page. example $_GET[]
															'limit'=>5 ,	// use number of li for minimize
															'url'=>'message.php?page=' // url of page. the number showed in end of url
															);

															$pagenumber = new pagination($pageconf);
															echo $pagenumber->pagenumber();
														?>
														  <table id="table1" class="sortable" style="font: 11px Tahoma; background: #fff; color: #091f30; width: 100%" border="0" cellpadding="0" cellspacing="0">
																<thead>
																	<tr style="height:5px;vertical-align:middle">
																		<th class="tabl">
																			ردیف
																		</th>
																		<th class="tabl">
																			تاریخ
																		</th>
																		<th class="tabl">
																			موضوع نامه
																		</th>
																		<th class="tabl">
																			نام فرستنده
																		</th>
																		<th class="tabl">
																			ایمیل فرستنده
																		</th>
																		<th class="tabl">
																			وضعیت
																		</th>
																		<th class="tabl">
																		   عملیات
																		</th>
																	</tr>
																</thead>
																<tbody>
																	<?php
																	$result  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."message WHERE uid='$uid' ORDER BY `date` DESC" );
																	while($show_result=$db->sql_fetcharray($result))
																	{
																		$r++;
																		if($r > $page*$ipp) break;
																		if($r <= $page*$ipp and $r >= $page*$ipp-$ipp+1)
																		{
																			$id  = $show_result['id'];
																			$adsid  = $show_result['adsid'];
																			$name = $show_result['name'];
																			$email      = $show_result['email'];
																			$message    = $show_result['message']; 
																			$date    = $show_result['date'];   
																			$read   = $show_result['read']; 
																			$ti      = date('Y-m-d',$date);
																			$tij     = g_to_j($ti);
																			
																			
																			$result1 = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."advertise WHERE id = '$adsid'");
																			$show_result1 = $db->sql_fetcharray($result1);
																			$subject = $show_result1['subject'];
																			
																			if($read == 0) $cs = "خوانده نشده";
																			if($read == 1) $cs = "خوانده شده";
																			
																			$col = "#FFFFFF";
																			if($read == 0) 
																			{
																				$col = "#CC9";
																			}
																		

																			$c++;
																			?>
																			<tr style="background-color:#FFFFFF">
																				<td style="text-align: center;background-color:<?php echo $col; ?>"><?php echo $r; ?></td>
																				<td style="text-align: center;background-color:<?php echo $col; ?>"><?php echo $tij; ?></td>
																				<td style="text-align: center; background-color:<?php echo $col; ?>"><a href="<?php echo URL;?>desktop/message/view/<?php echo $id; ?>"><?php echo $subject; ?></a></td>
																				<td style="text-align:right; background-color:<?php echo $col; ?>"><?php echo $name; ?></td>
																				<td style="text-align:center; background-color:<?php echo $col; ?>"><?php echo $email; ?></td>
																				<td style="text-align:center; background-color:<?php echo $col; ?>"><?php echo $cs; ?></td>
																				<td style="text-align: center; background-color:<?php echo $col; ?>">
																					<table>
																						<tbody>
																							<tr>
																								<td>
																									<a href="<?php echo URL;?>desktop/message/delete/<?php echo $id; ?>">
																										<img src="<?php echo URL;?>template/default/image/delete.gif" onclick="return conf()">
																									</a>
																								</td>
																							</tr>
																						</tbody>
																					</table>
																				</td>
																			</tr>
																			<?php
																		}
																	}
																	?>
																</tbody>
															</table>
                                                            <table>
                                                                <tr>
                                                                    <td>
                                                                       <?php echo nl2br($this->message); ?> 
                                                                    </td>
                                                                </tr>
                                                            </table>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php include "usermenu.php"; ?>
		</div>
	</div>
	<div id="ja-footer" class="wrap">
		<div class="main clearfix">
			<div class="ja-footnav clearfix">
				<ul class="ja-links">
					<li class="top">
						<a href="#Top" title="Back to Top">بالا</a>
					</li>
				</ul>
			</div>

			<div>
				<div align="center">
					<p><?php echo SITE_FOOTER; ?></p>
					﻿<p align ="center"><?php include "copyright.php"; ?></p>
				</div>
			</div>
		</div>
	</div>
</div>
</body></html>
<?php
}
else
{
    header("Location: ../index.php");
}
?>