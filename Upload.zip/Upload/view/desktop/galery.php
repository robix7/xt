<?php
require "include/db.php";
require "include/galery/UberGallery.php";
$gallery = new UberGallery();
if(isset($_SESSION['SUB_USER_ID'])){
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fa-ir" lang="fa-ir">
<head>
<meta name="Template" content="">
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="robots" content="index, follow">
<meta name="keywords" content="">
<meta name="description" content="">
<title><?php echo SITE_NAME; ?></title>
	
<link href="<?php echo URL; ?>template/default/css/template.css" rel="stylesheet" type="text/css">

<link rel="stylesheet" type="text/css" href="<?php echo URL; ?>template/default/css/galery/style.css" />
<link rel="stylesheet" type="text/css" href="<?php echo URL; ?>template/default/css/galery/colorbox/<?php echo GALERY_THEMES; ?>/colorbox.css" />
<script type="text/javascript" src="<?php echo URL; ?>template/default/css/galery/jquery-2.1.0.min.js"></script>
<script type="text/javascript" src="<?php echo URL; ?>template/default/css/galery/colorbox/jquery.colorbox.js"></script>

<script type="text/javascript">
$(document).ready(function() {
	  $('input[type="checkbox"]').ezMark();
	  $('input[type="radio"]').ezMark();
	  $().piroBox_ext({
	  piro_speed : 700,
		  bg_alpha : 0.5,
		  piro_scroll : true
	  });
  
});
$(function(){
	$("#menu ul li:has(ul)").find("span:first").addClass("down");
	$("#menu ul li ul li:has(ul)").find("span:first").removeClass("down");
	$("#menu ul li ul li:has(ul)").find("a:first").addClass("fly");
});
$(function(){
  $('#errid').click();
});
</script>

</head>
<body id="bd" class="fs3 FF">
<div id="ja-wrapper">
	<a name="Top" id="Top"></a>
	<div id="ja-container" class="wrap ja-l1r1">
		<div class="main clearfix">
			<div id="ja-mainbody" style="width:80%">
				<div class="ja-box1">
					<div class="ja-box2">
						<div id="ja-main" style="width:100%">
							<div class="inner ja-box-br">
								<div class="ja-box-bl">
									<div class="ja-box-tr">
										<div class="ja-box-tl clearfix">
											<div id="ja-breadcrums">
												<div class="inner clearfix">
													<strong></strong> <span class="breadcrumbs pathway">ویرایش گارلری تصاویر</span>
												</div>
											</div>
											<div id="ja-contentwrap" class="">
												<div id="ja-content" class="column" style="width:100%">
													<div id="ja-current-content" class="column" style="width:100%">
																												<div class="ja-content-main clearfix">
															<form name="newad" method="post" enctype="multipart/form-data" action="">
																<div>
																	<div style="float:right; text-align:right; width:20%;height:30px;">
																		عکس
																	</div>
																	<div style="float:right; text-align:right; width:35%;height:30px;">
																		<input name="image" id="image" class="inp2" type="file" >
																	</div>
																	<div style="float:right; text-align:right; width:45%;height:30px;">
																	
																	</div>
																</div>
																<div>
																	<div style="float:right; text-align:right; width:20%;height:30px;">
																		نام دلخواه عکس
																	</div>
																	<div style="float:right; text-align:right; width:35%;height:30px;">
																		<input name="name" id="name" class="inp2" type="text">
																	</div>
																	<div style="float:right; text-align:right; width:45%;height:30px;">
																	این نام حتما باید لاتین باشد.
																	</div>
																</div>
																<div>
																	<div style="float:right; text-align:right; width:20%;height:30px;">
																		متن عکس
																	</div>
																	<div style="float:right; text-align:right; width:35%;height:30px;">
																		<input name="al" id="al" class="inp2" type="text">
																	</div>
																	<div style="float:right; text-align:right; width:45%;height:30px;">
																	متنی که در صورت عدم نمایش عکس نمایش داده می شود.
																	</div>
																</div>
																<div>
																	<div style="float:right; text-align:right; width:20%;height:30px;">
																		
																	</div>
																	<div style="float:left; text-align:right; width:80%;height:30px;">
																		<input class="inputbox" dir="rtl" value="  ارسال  " name="sendimage" id="sendimage" style="width: 100px;" type="submit">&nbsp;  
																		<input class="inputbox" dir="rtl" value="  انصراف  " name="canfish" id="canfish" style="width: 100px;" type="button" onclick=window.location='index.php'>&nbsp;  
																	</div>
																	<div>
																		<?php echo $this->msg; ?>
																	</div>
																</div>
																<div>
																	<div style="float:right; text-align:right; width:100%;height:120px;">
																		1- نام عکس حتما باید لاتین باشد.
																		<br/>
																		2- در یک آگهی نام عکس ها نمی توانند تکراری باشند.
																		<br/>
																		3- متن عکس می تواند فارسی و یا لاتین باشد ولی بهتر است فارسی باشد.
																		<br/>
																		4- متن عکس در دو زمان نمایش داده خواهد شد. یکی زمانی که کاربر موس را روی عکس نگاه می دارد و دیگری زمانی که به هر دلیلی در رایانه کاربر عکس لود نمی شود.
																		<br/>
																		5- توجه داشته باشید با انتخاب نام و متن مناسب آگهی شما در جستجوهای بهتر دیده می شود.
																	</div>
																	<div style="float:right; text-align:right; width:0%;height:30px;">
																		
																	</div>
																	<div style="float:right; text-align:right; width:0%;height:30px;">
																	
																	</div>
																</div>																
															</form>
															<?php
																$cnt_query = $db->sql_query("SELECT COUNT(`id`) FROM ".TABLE_PREFIX."onlinepay WHERE `uid` = '$this->uid'");
																$cnt_a     = mysql_fetch_row($cnt_query);
																$cnt       = $cnt_a[0];
																$r=0;
																if(isset($_GET['page']))
																{
																	$page = $_GET['page']; 
																}
																else
																{
																	$page = 1;
																}
																$ipp = 10;							
																$pageconf = array(
																'all'=>$cnt ,
																'range'=>$ipp ,
																'inpage'=>$page,
																'limit'=>5 ,
																'url'=>'onlinepay.php?page='
																);

																$pagenumber = new pagination($pageconf);
																echo $pagenumber->pagenumber();

															?>
															<table id="table1" class="sortable" style="font: 11px Tahoma; background: #fff; color: #091f30; width: 100%" border="0" cellpadding="0" cellspacing="0">
																<thead>
																	<tr style="height:5px;vertical-align:middle">
																		<th class="tabl">
																			ردیف
																		</th>
																		<th class="tabl">
																			تاریخ
																		</th>
																		<th class="tabl">
																			عکس
																		</th>
																		<th class="tabl">
																			نام عکس
																		</th>
																		<th class="tabl">
																			متن عکس
																		</th>
																		<th class="tabl">
																			حجم
																		</th>
																		<th class="tabl">
																		   عملیات
																		</th>
																	</tr>
																</thead>
																<tbody>
																	<?php
																	$result  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."galery WHERE `adsid` = '$this->id' ORDER BY `date` DESC" );
																	while($show_result=$db->sql_fetcharray($result))
																	{
																		$r++;
																		if($r > $page*$ipp) break;
																		if($r <= $page*$ipp and $r >= $page*$ipp-$ipp+1)
																		{
																			$id   = $show_result['id'];
																			$name = $show_result['name'];
																			$alt  = $show_result['alt'];
																			$date = $show_result['date'];
																			
																			$nn = explode('-',$name);
																			$name1 = $nn[1];
																			
																			if(file_exists("images/galery/big/$name"))
																			{
																				if(filesize ("images/galery/big/$name")/1024 < 1000)
																				{
																					$size = round(filesize ("images/galery/big/$name")/1024,0)."KB";
																				}
																				else
																				{
																					$size = round(filesize ("images/galery/big/$name")/1024/1024,1)."MB";
																				}
																			}
																			
																			?>
																			<tr style="background-color:#FFFFFF">
																				<td style="text-align:center;"><?php echo $r; ?></td>
																				<td style="text-align:center;"><?php echo s_to_j($date); ?></td>
																				<td style="text-align:center;"><img src="<?php echo URL; ?>images/galery/small/<?php echo $name; ?>" border="0" /></td>
																				<td style="text-align:center;"><?php echo $name1; ?></td>
																				<td style="text-align:center;"><?php echo $alt; ?></td>
																				<td style="text-align:right;"><?php echo $size; ?></td>
																				<td style="text-align:center;">
																					<table>
																						<tbody>
																							<tr>
																								<td>
																									<a href="<?php echo URL; ?>desktop/galery/delete/<?php echo $id;?>" onclick="return conf()">
																										<img src="<?php echo URL; ?>template/default/image/delete.gif" title="حذف عکس" />
																									</a>
																								</td>
																							</tr>
																						</tbody>
																					</table>
																				</td>
																			</tr>
																			<?php
																		}
																	}
																	?>
																</tbody>
															</table>
														</div>
														<div>
															<div id="galleryListWrapper">
																<ul id="galleryList" class="clearfix">
																	<?php
																	$result  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."galery WHERE `adsid` = '$this->id' ORDER BY `date` DESC" );
																	while($show_result=$db->sql_fetcharray($result))
																	{
																		$name = $show_result['name'];
																		$al  = $show_result['alt'];
																		
																		?>
																		<li><a href="../images/galery/big/<?php echo $name; ?>" title="<?php echo $al; ?>" alt="<?php echo $al; ?>" rel="colorbox"> <img src="../images/galery/med/<?php echo $name; ?>" alt=""></a></li>
																		<?php
																	}
																	?>
																</ul>
															</div>
															<br clear="right"><br clear="right">
														</div>
														<div class="ja-content-main clearfix">
															<div class="main-deal-bottom2 pie">
																<div class="details">
																	<div class="title">
																		<h1 class="fv c0 s18">
																			<b><?php echo $this->subject; ?></b> 
																		</h1>
																	</div>
																	<div style="padding: 0px 15px;">
																		<div class="img1" style="text-align: center;">
																			<div style="text-align: center;">
																				<img alt="stars" src="<?php echo URL; ?>template/default/image/star_v_<?php echo $this->star; ?>.gif" width="70" height="9" />
																			</div>
																			<div style="text-align: center;">
																				<br>
																				<img alt="" src="<?php echo URL; ?>images/ads/big/<?php echo $this->id ?>.jpg" border="0">
																			</div>
																		</div>
																		<div>
																			<div style="float: left; width: 297px;"></div>
																			<div>
																				<?php echo nl2br($this->comment); ?>
																			</div>
																			<div id="Specification1"></div>
																			<div class="clr"></div>
																		</div>
																		<div class="clr"></div>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php include "usermenu.php"; ?>
		</div>
	</div>
	<div id="ja-footer" class="wrap">
		<div class="main clearfix">
			<div class="ja-footnav clearfix">
				<ul class="ja-links">
					<li class="top">
						<a href="#Top" title="Back to Top">بالا</a>
					</li>
				</ul>
			</div>
			<div>
				<div align="center">
					<p><?php echo SITE_FOOTER; ?></p>
					﻿<p align ="center"><?php include "copyright.php"; ?></p>
				</div>
			</div>
		</div>
	</div>
</div>
</body></html>
<?php
}
else
{
    header("Location: ../index.php");
}
?>