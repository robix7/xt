<?php
require "include/db.php";
if(isset($_GET['log']) == "out")
{	
	unset($_SESSION['SUB_USER_ID']);
}
if(isset($_SESSION['SUB_USER_ID'])) {


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fa-ir" lang="fa-ir"><head>
<meta name="Template" content="">
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="robots" content="index, follow">
<meta name="keywords" content="">
<meta name="description" content="">
<title><?php echo SITE_NAME; ?></title>

<link href="<?php echo URL; ?>template/default/css/template.css" rel="stylesheet" type="text/css">

</head>
<body id="bd" class="fs3 FF">
<div id="ja-wrapper">
	<a name="Top" id="Top"></a>
	<div id="ja-container" class="wrap ja-l1r1">
		<div class="main clearfix">
			<div id="ja-mainbody" style="width:80%">
				<div class="ja-box1">
					<div class="ja-box2">
						<div id="ja-main" style="width:100%">
							<div class="inner ja-box-br">
								<div class="ja-box-bl">
									<div class="ja-box-tr">
										<div class="ja-box-tl clearfix">
											<div id="ja-breadcrums">
												<div class="inner clearfix">
													<strong></strong> <span class="breadcrumbs pathway">صفحه نخست</span>
												</div>
											</div>
											<div id="ja-contentwrap" class="">
												<?php
												if($this->active == 0)
												{
													?>
													<div id="ja-content" class="column" style="width:100%">
														<div id="ja-current-content" class="column" style="width:100%">
															<div class="ja-content-main clearfix">
																<div class="main-deal-bottom pie">
																	<table class="adsh" cellpadding="0" cellspacing="0" width="100%">
																		<tbody>
																		   <tr>
																				<td class="nLines">
																					<form action="" method="post">						
																						<table class="nLines" cellspacing="0" width="100%">
																							<tbody>
																								<?php
																								if($this->sentok != 1)
																								{
																									?>
																									<tr>
																										<td colspan="2"><font color="red"><b>ایمیل شما هنوز تایید نشده است. برای تایید ایمیل دکمه ارسال را کلیک کنید.</b></font></td>
																									</tr>
																									<tr>
																										<td></td>
																										<td>
																											<div style="text-align:center;margin-top:8px;"> 
																												<input name="send" id="send" value="ارسال ایمیل فعال سازی" type="submit" class="button" >
																											</div>
																										</td>
																									</tr>
																									<?php
																								}
																								?>
																								<tr>
																									<td colspan="2"><?php echo $this->msg; ?></td>
																								</tr>
																							</tbody>
																						</table>
																					</form>
																				</td>
																			</tr>
																		</tbody>
																	</table> 	 			
																</div>
															</div>
														</div>
													</div>
													<?php
												}
												?>
												<div id="ja-content" class="column" style="width:100%">
													<div id="ja-current-content" class="column" style="width:100%">
														<div class="ja-content-main clearfix">
															<div class="main-deal-bottom pie">
																<table id="table1" class="sortable" style="font: 11px Tahoma; background: #fff; color: #091f30; width: 100%" border="0" cellpadding="0" cellspacing="0">
																	<tbody>
																		<tr style="background-color:#FFFFFF">
																			<td class="tabl">
																				پرداخت از طریق فیش بانکی
																			</td>
																			<td style="text-align:center;width:70%">
																				<?php echo sefr($this->fishAmount); ?> ریال
																			</td>
																		</tr>
																		<tr style="background-color:#FFFFFF">
																			<td class="tabl">
																				پرداخت آنلاین
																			</td>
																			<td style="text-align:center;width:70%">
																				<?php echo sefr($this->onlineAmount); ?> ریال
																			</td>
																		</tr>
																		<tr style="background-color:#FFFFFF">
																			<td class="tabl">
																				پرداخت های منتظر تایید
																			</td>
																			<td style="text-align:center;width:70%">
																				<?php echo sefr($this->amountPending); ?> ریال
																			</td>
																		</tr>
																		<tr style="background-color:#FFFFFF">
																			<td class="tabl">
																				اعتبار هدیه
																			</td>
																			<td style="text-align:center;width:70%">
																				<?php echo sefr($this->fishGift); ?> ریال
																			</td>
																		</tr>
																		<tr style="background-color:#FFFFFF">
																			<td class="tabl">
																				مجموع مبالغ تایید شده
																			</td>
																			<td style="text-align:center;width:70%">
																				<?php echo sefr($this->fishAmount + $this->onlineAmount); ?> ریال
																			</td>
																		</tr>
																		<tr style="background-color:#FFFFFF">
																			<td class="tabl">
																				مجموع هزینه آگهی ها
																			</td>
																			<td style="text-align:center;width:70%">
																				<?php echo sefr($this->adsCost); ?> ریال
																			</td>
																		</tr>
																		<tr style="background-color:#FFFFFF">
																			<td class="tabl">
																				مجموع هزینه آگهی های در انتظار تایید
																			</td>
																			<td style="text-align:center;width:70%">
																				<?php echo sefr($this->adsPending); ?> ریال
																			</td>
																		</tr>
																		<tr style="background-color:#FFFFFF">
																			<td class="tabl">
																				اعتبار باقی مانده
																			</td>
																			<td style="text-align:center;width:70%">
																				<?php echo sefr($this->remainCredit); ?> ریال
																			</td>
																		</tr>
																	</tbody>
																</table>	
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php include "usermenu.php"; ?>
		</div>
	</div>
	<div id="ja-footer" class="wrap">
		<div class="main clearfix">
			<div class="ja-footnav clearfix">
				<ul class="ja-links">
					<li class="top">
						<a href="#Top" title="Back to Top">بالا</a>
					</li>
				</ul>
			</div>
			<div>
				<div align="center">
					<p><?php echo SITE_FOOTER; ?></p>
					﻿<p align ="center"><?php include "copyright.php"; ?></p>
				</div>
			</div>
		</div>
	</div>
</div>
</body></html>
<?php
}
else
{
   header("Location: ../index.php");  
}
?>