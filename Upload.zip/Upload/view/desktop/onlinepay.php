<?php
require "include/db.php";
if(isset($_SESSION['SUB_USER_ID'])){
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fa-ir" lang="fa-ir">
<head>
<meta name="Template" content="">
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="robots" content="index, follow">
<meta name="keywords" content="">
<meta name="description" content="">
<title><?php echo SITE_NAME; ?></title>
	
<link href="<?php echo URL; ?>template/default/css/template.css" rel="stylesheet" type="text/css">

</head>
<body id="bd" class="fs3 FF">
<div id="ja-wrapper">
	<a name="Top" id="Top"></a>
	<div id="ja-container" class="wrap ja-l1r1">
		<div class="main clearfix">
			<div id="ja-mainbody" style="width:80%">
				<div class="ja-box1">
					<div class="ja-box2">
						<div id="ja-main" style="width:100%">
							<div class="inner ja-box-br">
								<div class="ja-box-bl">
									<div class="ja-box-tr">
										<div class="ja-box-tl clearfix">
											<div id="ja-breadcrums">
												<div class="inner clearfix">
													<strong></strong> <span class="breadcrumbs pathway">ثبت فیش بانکی</span>
												</div>
											</div>
											<div id="ja-contentwrap" class="">
												<div id="ja-content" class="column" style="width:100%">
													<div id="ja-current-content" class="column" style="width:100%">
														<div class="ja-content-main clearfix">
															<form name="newad" method="post" enctype="multipart/form-data" action="">
																<div>
																	<div style="float:right; text-align:right; width:20%;height:30px;">
																		مبلغ
																	</div>
																	<div style="float:right; text-align:right; width:32%;height:30px;">
																		<input name="amount" id="amount" value="<?php echo $this->amount; ?>" class="inp1" type="text">
																	</div>
																	<div style="float:right; text-align:right; width:48%;height:30px;">
																	ریال
																	</div>
																</div>
																<div>
																	<div style="float:right; text-align:right; width:20%;height:30px;">
																		دروازه پرداخت
																	</div>
																	<div style="float:right; text-align:right; width:30%;height:30px;">
																		<select name="getway" id="getway" class="inp2">
																			<?php  

																				$result  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."onlinemethod WHERE accountstatus = 1 ");
																				while($show_result = $db->sql_fetcharray($result))
																				{
																					
																					$bankid = $show_result['bankid'];
																					$result1  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."onlinebank WHERE id = '$bankid' ");
																					$show_result1  = $db->sql_fetcharray($result1);
																					$bankName      = $show_result1['name'];
																					$bankNameFarsi = $show_result1['comment'];
																					
																					echo $t = "<option value='$bankid'>$bankNameFarsi</option>";
																				}
																				?>
																		</select>
																	</div>
																	<div style="float:right; text-align:right; width:50%;height:30px;">
																	</div>
																</div>
																<div>
																	<div style="float:right; text-align:right; width:20%;height:30px;">
																		
																	</div>
																	<div style="float:left; text-align:right; width:80%;height:30px;">
																		<input class="inputbox" dir="rtl" value="  ارسال  " name="onlinepay" id="onlinepay" style="width: 100px;" type="submit">&nbsp;  
																		<input class="inputbox" dir="rtl" value="  انصراف  " name="canfish" id="canfish" style="width: 100px;" type="button" onclick=window.location='index.php'>&nbsp;  
																	</div>
																</div>
																<div>
																	<div style="float:right; text-align:right; width:20%;height:30px;">
																		
																	</div>
																	<div style="float:left; text-align:right; width:80%;height:80px;">
																		<?php
																				echo $this->msg;
																				if(strlen($this->msg10) > 5) { echo $this->msg10; echo "<br>"; }
																				if(strlen($this->msg11) > 5) { echo $this->msg11; echo "<br>"; }
																				if(strlen($this->msg12) > 5) { echo $this->msg12; echo "<br>"; }
																				if(strlen($this->msg13) > 5) { echo $this->msg13; echo "<br>"; }
																			?>
																	</div>
																</div>
																
																
																
															</form>
															<?php
																$cnt_query = $db->sql_query("SELECT COUNT(`id`) FROM ".TABLE_PREFIX."onlinepay WHERE `uid` = '$this->uid'");
																$cnt_a     = mysql_fetch_row($cnt_query);
																$cnt       = $cnt_a[0];
																$r=0;
																if(isset($_GET['page']))
																{
																	$page = $_GET['page']; 
																}
																else
																{
																	$page = 1;
																}
																$ipp = 10;							
																$pageconf = array(
																'all'=>$cnt ,	 // select count(*) from post where 
																'range'=>$ipp , 	// select * from post limit (inpage-1)*range,range
																'inpage'=>$page,	// current page. example $_GET[]
																'limit'=>5 ,	// use number of li for minimize
																'url'=>'onlinepay.php?page=' // url of page. the number showed in end of url
																);

																$pagenumber = new pagination($pageconf);
																echo $pagenumber->pagenumber();

															?>
															<table id="table1" class="sortable" style="font: 11px Tahoma; background: #fff; color: #091f30; width: 100%" border="0" cellpadding="0" cellspacing="0">
																<thead>
																	<tr style="height:5px;vertical-align:middle">
																		<th class="tabl">
																			ردیف
																		</th>
																		<th class="tabl">
																			دروازه پرداخت
																		</th>
																		<th class="tabl">
																			شماره فاکتور
																		</th>
																		<th class="tabl">
																			شماره رسید
																		</th>
																		<th class="tabl">
																			مبلغ
																		</th>
																		<th class="tabl">
																		   تاریخ واریز
																		</th>
																		<th class="tabl">
																			وضعیت
																		</th>

																	</tr>
																</thead>
																<tbody>
																	<?php
                                                                                                                                        $c=0;
																	$result  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."onlinepay WHERE `uid` = '$this->uid' ORDER BY `time` DESC" );
																	while($show_result=$db->sql_fetcharray($result))
																	{
																		$r++;
																		if($r > $page*$ipp) break;
																		if($r <= $page*$ipp and $r >= $page*$ipp-$ipp+1)
																		{
																			$id          = $show_result['id'];
																			$oid         = $show_result['oid'];
																			$amount      = $show_result['amount'];
																			$finalized   = $show_result['finalized'];
																			$authority   = $show_result['authority'];
																			$time        = $show_result['time']; 
																			$time        = date('Y-m-d',$time);
																			$timeJalali = g_to_j($time);
																			
																			$result1      = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."onlinebank WHERE id = '$oid'");
																			$show_result1 = $db->sql_fetcharray($result1);
																			$bankName     = $show_result1['comment'];						

																			if($finalized == 1) 
																			{
																				$col = "#FFFFFF";
																				$cs = "تایید شده";
																			}
																			else
																			{
																				$col = "#CC9";
																				$cs = "تراکنش ناموفق";
																			}
																			$c++;
																			?>
																			<tr style="background-color:<?php echo $col; ?>">
																				<td style="text-align: center;"><?php echo $r; ?></td>
																				<td style="text-align: center;"><?php echo $bankName; ?></td>
																				<td style="text-align: center;"><?php echo $id; ?></td>
																				<td style="text-align: center;"><?php echo $authority; ?></td>
																				<td style="text-align:right;"><?php echo sefr($amount); ?></td>
																				<td style="text-align:center;"><?php echo $timeJalali; ?></td>
																				<td style="text-align:center;"><?php echo $cs; ?></td>
																			</tr>
																			<?php
																		}
																	}
																	?>
																</tbody>
															</table>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php include "usermenu.php"; ?>
		</div>
	</div>
	<div id="ja-footer" class="wrap">
		<div class="main clearfix">
			<div class="ja-footnav clearfix">
				<ul class="ja-links">
					<li class="top">
						<a href="#Top" title="Back to Top">بالا</a>
					</li>
				</ul>
			</div>
			<div>
				<div align="center">
					<p><?php echo SITE_FOOTER; ?></p>
					﻿<p align ="center"><?php include "copyright.php"; ?></p>
				</div>
			</div>
		</div>
	</div>
</div>
</body></html>
<?php
}
else
{
    header("Location: ../index.php");
}
?>