<?php
session_start();
include "include/db.php";
$msg = '';$msg1='';$find='';$r='';$mn='';$subject='';

$word = $this->word;
$data = $this->word;
$data  = get_dataf($data);
if($data != 1) 	header("Location: ../../index.php");
$word = strtolower($word);
$date = time();
$word_qty   = $db->sql_query("SELECT COUNT(id) FROM ".TABLE_PREFIX."tag WHERE word = '$word'");
$word_a = mysql_fetch_row($word_qty);
if($word_a[0] > 0)
{
    $result_tag = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."tag WHERE word = '$word' ");
    $show_tag   = $db->sql_fetcharray($result_tag);
    $id = $show_tag['id'];
    $qty = $show_tag['qty'] + 1;
    $db->sql_query("UPDATE ".TABLE_PREFIX."tag SET `qty` = '$qty',`date` = '$date' WHERE `id` ='$id';");
    $ltag = $id;
}
else
{
    $db->sql_query("INSERT INTO ".TABLE_PREFIX."tag VALUES (NULL, '$word', '1', '0', '$date', '-1', '-1', '-1', '-1', '0')");
    $word_qty   = $db->sql_query("SELECT MAX(id) FROM ".TABLE_PREFIX."tag ");
    $word_a     = mysql_fetch_row($word_qty);
    $ltag       = $word_a[0];
}

$search_qty   = $db->sql_query("SELECT COUNT(`id`) FROM ".TABLE_PREFIX."advertise WHERE `subject` LIKE '%$word%' OR `comment` LIKE '%$word%' ");
$search_a     = mysql_fetch_row($search_qty);
if($search_a[0] > 0)
{
    $result2 = $db->sql_query(" SELECT * FROM ".TABLE_PREFIX."advertise WHERE `subject` LIKE '%$word%' OR `comment` LIKE '%$word%' ORDER BY `update` DESC");
    $_SESSION['result2'] = $result2;
    $cnt = $search_a[0];
    $cnt10 = $cnt;
}
else
{
    $find = -1;
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fa-ir" lang="fa-ir">
<head>
	<meta name="Template" content="" />
	<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
	<meta name="robots" content="index, follow" />
	<meta name="keywords" content="<?php echo $keywords ?>" />
	<meta name="description" content="<?php echo $subject ?>" />
	<title><?php echo SITE_NAME.'-'.$word; ?></title>

	<link   href="<?php echo URL; ?>template/default/css/template.css" rel="stylesheet"  type="text/css" />
	<link   href="<?php echo URL; ?>template/default/css/menu.css" rel="stylesheet"      type="text/css" />

</head>
<body id="bd" class="fs3 FF">
<div id="ja-wrapper">
	<a name="Top" id="Top"></a>
		<div class="wrap">
		<div class="main">
			<div class="inner clearfix">
				<?php include "topmenu.php" ?>
			</div>
		</div>
	</div>
	<div id="ja-header" class="wrap">
		<div class="main">
			<div class="inner clearfix">
				<div class="logo-text">
					<?php include "logo.php"; ?>
				</div>	
				<div id="ja-search">
					<?php include "searchbox.php"; ?>
				</div>
			</div>
		</div>
	</div>
	<div id="ja-mainnav" class="wrap">
		<div >
			<?php include "topgroup.php"; ?>
		</div>
	</div>
	<ul class="no-display">
		<li><a href="" title=""></a></li>
	</ul>
	<div id="ja-container" class="wrap ja-l1r1">
		<div class="main clearfix">
			<div id="ja-mainbody" style="width:80%">
				<div class="ja-box1">
					<div class="ja-box2">
						<?php
						if($find != -1)
						{
							if(isset($_GET['page']))
							{
								$page = $_GET['page'];	
								$pages = -1;								
							}
							else
							{
								$pages = -1;
								$page = 1;
							}
							if($pages == -1)
							{							
								$ipp = 10;							
								$pageconf = array(
								'all'=>$cnt10 ,
								'range'=>$ipp ,
								'inpage'=>$page,
								'limit'=>3 ,
								'url'=>'search.php?word='.$word.'&page=' // url of page. the number showed in end of url
								);
							}
						}
						?>
						<div id="ja-main" style="width:70%">
							<div class="inner ja-box-br">
								<div class="ja-box-bl">
									<div class="ja-box-tr">
										<div class="ja-box-tl clearfix">
											<div id="ja-breadcrums">
												<div class="inner clearfix">
													<strong></strong> <span class="breadcrumbs pathway">نتایج جستجو :: <?php echo $word; ?></span>
												</div>
											</div>
											<div id="ja-contentwrap" class="">
												<div id="ja-content" class="column" style="width:100%">
													<div id="ja-current-content" class="column" style="width:100%">
													<div class="ja-content-main clearfix">
															
														<div class="main-deal-bottom2 pie">
															<div class="jamod-content ja-box-ct clearfix">
																<?php
																if($find != -1)
																{
																	$k = 0;
																	$allid=NULL;
																	while($show_result2=$db->sql_fetcharray($result2))
																	{
																		$r++;
																		if($r > $page*$ipp) break;
																		if($r <= $page*$ipp and $r >= $page*$ipp-$ipp+1)
																		{
																			$k++;
																			$imid       = $show_result2['id'];
																			$imsgid[$k] = $show_result2['sgid'];
																			$imcomment  = $show_result2['comment'];
																			$imsubject  = $show_result2['subject'];
																			$imname     = $show_result2['name'];
																			$imtel      = $show_result2['tel'];
																			$immobile   = $show_result2['mobile'];
																			$update     = $show_result2['update'];
																			$update     = s_to_j($update);
																			
																			?>
																			<div>
																				<div style="float: left; width:80%;">
                                                                                    <a href="<?php echo URL; ?>ads/view/<?php echo $imid; ?>/<?php echo space_rep($imsubject); ?>">
                                                                                    <?php echo $imsubject; ?>
                                                                                    </a>
																				</div>
																				<div style="float: right; width:20%;">
                                                                                    <?php echo $update; ?>
																				</div>
																			</div>
																			<div>
																				<div style="float: left; width:80%;height:60px;text-align:justify;">
																					<?php 
																					if(strlen($imcomment) < 355)
																					{
																						echo strip_tags($imcomment);
																					 
																					}
																					else
																					{
																						for($ii = 355; $ii < 420; $ii++)
																						{
																							$uuu = substr($imcomment,$ii,1);
																							if($uuu == " ")
																							{
																								$mn = $ii;
																								break;
																							}
																						}
																						$imcomment = substr($imcomment,0,$mn);
																						echo strip_tags($imcomment);
																					}
																					
																					
																					?>
																				</div>
																				<div style="float: right; width:20%;height:60px;">
																					<a href="<?php echo URL; ?>ads/view/<?php echo $imid; ?>/<?php echo space_rep($imsubject); ?>"><img alt="<?php echo $imsubject; ?>" src="<?php echo URL; ?>images/ads/small/<?php echo $imid; ?>.jpg" border="0" /> </a>
																				</div>
																			</div>
																			
																			<div>
																				<div style="float: left; width:80%;">
																					<br/>
																					<strong><font color="blue"><?php echo $imname; ?></font>
																					<?php
																					if($immobile != NULL)
																					{
																						?>
																						<font color="red"> همراه: <span dir="ltr"><?php echo $immobile; ?></span></font>
																						<?php
																					}
																					elseif($imtel != NULL)
																					{
																						?>
																						<font color="red"> تلفن: <span dir="ltr"><?php echo $imtel; ?></span></font>
																						<?php
																					}
																					?>
																					
																					
																					</strong>
																				</div>
																				<div style="float: right; width:20%;">
																				
																				</div>
																			</div>
																			<div>
																				<p style="color:#FFFFFF">-<br/>-</p/>
																				<hr style="color:#FFDDBB" align="center">
																			</div>

																			<?php
																			
																			if($k == 1) 
																			{
																				$allid = $imid;
																			}
																			else
																			{
																				$allid .= ",".$imid;
																			}
																		}
																	}
																	
																	for($i2 = 1; $i2 <= $r ; $i2++)
																	{
																		$temp = $i2;
																		for($j2 = $i2+1; $j2 <= $r; $j2++)
																		{
																			if($imsgid[$temp] < $imsgid[$j2])
																			{
																				$temp = $j2;                    
																			}
																		}

																		$mytemp        = $imsgid[$i2];
																		$imsgid[$i2]   = $imsgid[$temp];
																		$imsgid[$temp] = $mytemp;
																	}
																	$sgid = $imsgid[1]; 
																	for($i3 = 1; $i3 <= $r ; $i3++)
																	{
																		if($i3 == 1)
																		{
																			$allsgid = $imsgid[$i3];
																		}
																		else
																		{
																			if($imsgid[$i3] == $imsgid[$i3-1])
																			{
																			
																			}
																			else
																			{
																				$allsgid .= ",".$imsgid[$i3];
																			}
																		}
																	}
																	
																	$db->sql_query("UPDATE ".TABLE_PREFIX."tag SET adsid = '$allid', groupid= '$allsgid' WHERE id = '$ltag' ");
																}
																else
																{
																	echo "موردی یافت نشد.";
																}
																?>
															</div>
														</div>
													</div>
													</div>
												</div>
											</div>
											<?php
											if($find != -1)
											{
												?>
												<div style="padding-right: 50px;">
													<?php
														$pagenumber = new pagination($pageconf);
														echo $pagenumber->pagenumber();
														?>
												</div>
												<?php
											}
											?>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div id="ja-left" class="column sidebar" style="width:30%">
							<div class="ja-colswrap clearfix ja-l1">
								<div class="ja-col  column">
									<div class="ja-module ja-box-br module_hilite" id="Mod48">
										<div class="ja-box-bl">
											<div class="ja-box-tr">
												<div class="ja-box-tl clearfix">
													<h3><span>آگهی‌های ویژه: <?php echo $mgname; ?></h3>
													<div class="jamod-content ja-box-ct clearfix">
														<?php
														$k=0;
														$result20  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."advertise WHERE star = 7 OR star = 6 OR star = 5 OR star = 4 OR star = 3 OR star = 2 OR star = 1 and status = 1 and hasimage = 1" );
														while($show_result20 = $db->sql_fetcharray($result20))
														{
															$k++;
															$idads[$k]      = $show_result20['id'];
														}
                                                        if($k >0)
                                                        {
                                                         shuffle($idads);
                                                            $len = count($idads);
                                                            if($len > 10) $len = 10;
                                                            for($n=1;$n<$len;$n++)
                                                            {
                                                                $result20      = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."advertise WHERE id = '$idads[$n]' " );
                                                                $show_result20 = $db->sql_fetcharray($result20);
                                                                $othersubject  = $show_result20['subject'];
                                                                $othername     = $show_result20['name'];
                                                                $othertel      = $show_result20['tel'];
                                                                $otherlink     = $show_result20['url'];
                                                                $otheradsid    = $show_result20['id'];
                                                                $otherstar1    = $show_result20['star'];
                                                                $otherstar     = "star_v_".$otherstar1;														
                                                                ?>															
                                                                <div>
                                                                    <a href="<?php echo URL; ?>ads/view/<?php echo $otheradsid; ?>/<?php echo space_rep($othersubject); ?>"><?php echo $othersubject; ?></a>
                                                                </div>
                                                                <div style="text-align: left;">
                                                                    <?php
                                                                    if($otherstar1 > 0)
                                                                    {
                                                                        ?>
                                                                        <img alt="stars" src="<?php echo URL; ?>template/default/image/<?php echo $otherstar; ?>.gif" width="70" height="9" />
                                                                        <?php
                                                                    }
                                                                    ?>
                                                                </div>
                                                                <div style="height: 100px;">
                                                                       <a href="<?php echo URL; ?>ads/view/<?php echo $otheradsid; ?>/<?php echo space_rep($othersubject); ?>"><img alt="" src="<?php echo URL; ?>images/ads/med/<?php echo $idads[$n]; ?>.jpg" align="right" border="0" /></a>
                                                                </div>		
                                                                <div>
                                                                    <?php echo $othername; ?><br/>تلفن: <span dir="ltr"><?php echo $othertel; ?></span>			    
                                                                </div>															
                                                                <div>
                                                                    <hr style="color:#FFDDBB" align="center">
                                                                </div>
                                                                <?php
                                                            }
                                                        }
														?>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>	
						<div id="ja-left" class="column sidebar" style="width:30%"></div>
					</div>
				</div>
			</div>
			<?php include "menu.php"; ?>
		</div>
	</div>
	<div id="ja-footer" class="wrap">
		<div class="main clearfix">
			<?php include "dnmenu.php"; ?>
			<div>
				<div align="center">
					<p><?php echo SITE_FOOTER; ?></p>
					<p align ="center"><?php include "copyright.php"; ?></p>
				</div>
			</div>
		</div>
	</div>
</div>
</body>
</html>
