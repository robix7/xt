<?php
include "include/db.php";
$msg = '';$msgmob = '';$msgmob1 = '';$msg1= '';$log = '';$i90= '';$msg2='';$name5='';$email1='';


$siteEmail    = Setting::GetSetting(12);
$siteAddress  = Setting::GetSetting(11);
$siteName     = Setting::GetSetting(5);
$registerMode = Setting::GetSetting(16);
$gift         = Setting::GetSetting(20);

$maxrq = my_max(TABLE_PREFIX.'rq','row',-1,-1,-1,-1,-1,-1,-1,-1);
$rnd = rand(1,$maxrq);

$result40      = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."rq WHERE row = '$rnd'" );
$show_result40 = $db->sql_fetcharray($result40);
$question = $show_result40['question'];

if(isset($_POST['send']))
{
    $name    = $_POST["name"];
	$rnd1    = $_POST["rnd"];
	$answer  = $_POST["answer"];
    $email   = $_POST["email"];      
	$pass    = md5($_POST["pass"]);
	$pass1   = $_POST["pass"];
	$re_pass = md5($_POST["repass"]);
	
	$data  = get_email($email);

    if(!filter_var($email,FILTER_VALIDATE_EMAIL) OR $data == 2)
	{
		$name5 = $name;$email1 = $email;
		$msg = "<font color=red>فرمت ایمیل درست نیست</font>";
	}
	else
	{
		
		$result40      = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."rq WHERE row = '$rnd1'" );
		$show_result40 = $db->sql_fetcharray($result40);
		$answer1        = $show_result40['answer'];
		
		$result10  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."user WHERE email = '$email' " );
		$result10_show = mysql_num_rows($result10);
	
		if($name == "")
		{
			$name5 = $name;$email1 = $email;
			$msg = "<font color=red>نام را وارد كنيد</font>";
		}
		elseif($result10_show > 0)
		{
			$name5 = $name;$email1 = $email;
			$msg = "<font color=red>این ایمیل قبلا ثبت نام نموده است</font>";
		} 
		elseif($pass1 == "")
		{
			$name5 = $name;$email1 = $email;
			$msg = "<font color=red>رمز عبور را وارد كنيد</font>";
		}
		elseif($pass != $re_pass)
		{
			$name5 = $name;$email1 = $email;
			$msg = "<font color=red>رمز عبور با تکرار رمز عبور یکسان نیست</font>";
		}
		elseif($answer != $answer1)
		{
			$name5 = $name;$email1 = $email;
			$msg = "<font color=red>پاسخ سوال نادرست است</font>";
		}
		else
		{
			$code = time();
			$sql = "INSERT INTO ".TABLE_PREFIX."user(id, name, email, password, active , code, login) VALUES (NULL, '$name', '$email', '$pass', '0', '$code', '0');";
			if($db->sql_query($sql))
			{

				$result30  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."user WHERE email = '$email'" );
				$show_result30=$db->sql_fetcharray($result30);
				$id = $show_result30['id'];
				
				$date     = time();
				$fishdate = s_to_j(time());
				
				$comment  = 'اعتبار هدیه اولیه';
				if($gift > 0)
				{
					echo "111";
					$sql = "INSERT INTO ".TABLE_PREFIX."fish (`id` ,`aid` ,`uid`,`fdate` ,`date` ,`fnumber` , `amount` ,`sender` ,`comment` ,`status`)
										 VALUES (NULL , '0', '$id', '$fishdate', '$date', '0', '$gift', '-', '$comment', '1')";
					$db->sql_query($sql);
					
				}
					
				
				$to=$email;
				$to1=$siteEmail;
				$siteAddress = URL;
				$url=$siteAddress;
				//موضوع ایمیل فعال سازی
				$subject="فعال سازی ثبت نام";
				$subject1="ثبت نام جدبد";
		 
				// ایمیل سایت ما
				$header="from:  $siteName  <$siteEmail>";
				$header1="from: $siteName <$siteEmail>";
				
				$active = $code;
				//متن ایمیل
				$message="
				لینک فعال سازی
				برای فعال سازی ثبت نام روی لینک زیر کلیک کنید
				$siteAddress"."register/confirmation/$code";
				
				$message1 = "یک فرد جدید عضو شده است";
				
				
				//ارسال ایمیل
				if($registerMode == 1) $sentmail = mail($to,$subject,$message,$header);
				$sentmail1 = mail($to1,$subject1,$message1,$header1);
				
				if($registerMode == 0)$msg = "<p style='font-size:16px; color:green;'>ثبت نام با موفقیت انجام شد. همکنون می توانید وارد حساب کاربری شوید.</p>";
				if($registerMode == 1)$msg = "<p style='font-size:16px; color:green;'>ثبت نام با موفقیت انجام و ایمیل فعال سازی به آدرس شما ارسال شد.</p>";
			}
			else
			{
				$msg = "<p style='font-size:16px; color:green;'>ایراد در ثبت کاربر</p>";
			}	
		}
	}
}
if(isset($_POST['forget']))
{
    $email        = $_POST["email"];      
	$cnt_query = $db->sql_query("SELECT COUNT(id) FROM ".TABLE_PREFIX."user WHERE email = '$email' ");
	$cnt_a     = mysql_fetch_row($cnt_query);
	$cnt       = $cnt_a[0];
	
	if($cnt == 1)
	{
		$result30  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."user WHERE email = '$email'" );
		$show_result30=$db->sql_fetcharray($result30);
		$id = $show_result30['id'];
		
		
		$time  = time();
		$len   = strlen($time);
		$pass  = substr($time,$len-4,4);
		$passm = md5($pass);
		$db->sql_query("UPDATE ".TABLE_PREFIX."user SET `password` = '$passm' WHERE `id` = '$id' ");	
		
		$to      = $email;
		$url     = $siteAddress;
		$subject = "رمز عبور جدید";
		$header  = "from:  $siteName  <$siteEmail>";
		$message = "
		رمز عبورجدید شما:
		$pass
		";
		$sentmail = mail($to,$subject,$message,$header);
		if($sentmail)
		{
			$msg2 = "<font color=green>رمز عبور جدید به آدرس شما ارسال شد</font>"; 
		}
		else
		{
			$msg2 = "<font color=red>ایراد در ارسال رمز عبور لحضاتی بعد مجددا تلاش نمایید</font>";     
		}
	}
	else
	{
		$msg2 = "<font color=red>چنین ایملی وجود ندارد</font>";
	}
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fa-ir" lang="fa-ir">
<head>
	<meta name="Template" content="" />
	<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
	<meta name="robots" content="index, follow" />
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	<title><?php echo SITE_NAME; ?></title>

	<link   href="<?php echo URL; ?>template/default/css/template.css" rel="stylesheet"      type="text/css" />
	<link   href="<?php echo URL; ?>template/default/css/menu.css" rel="stylesheet"      type="text/css" />

</head>
<body id="bd" class="fs3 FF">
<div id="ja-wrapper">
	<a name="Top" id="Top"></a>
	<div class="wrap">
		<div class="main">
			<div class="inner clearfix">
				<?php include "topmenu.php" ?>
			</div>
		</div>
	</div>
	<div id="ja-header" class="wrap">
		<div class="main">
			<div class="inner clearfix">
				<div class="logo-text">
					<?php include "logo.php" ?>
				</div>	
				<div id="ja-search">
					<?php include "searchbox.php"; ?>
				</div>
			</div>
		</div>
	</div>
	<div id="ja-mainnav" class="wrap">
		<div >
			<?php include "topgroup.php"; ?>
		</div>
	</div>
	<ul class="no-display">
		<li><a href="" title=""></a></li>
	</ul>
	<div id="ja-container" class="wrap ja-l1r1">
		<div class="main clearfix">
			<div id="ja-mainbody" style="width:80%">
				<div class="ja-box1">
					<div class="ja-box2">
						<div id="ja-main" style="width:100%">
							<div class="inner ja-box-br">
								<div class="ja-box-bl">
									<div class="ja-box-tr">
										<div class="ja-box-tl clearfix">
											<div id="ja-breadcrums">
												<div class="inner clearfix">
													<strong></strong> <span class="breadcrumbs pathway">ثبت نام</span>
												</div>
											</div>
											<div id="ja-contentwrap" class="">
												<div id="ja-content" class="column" style="width:100%">
													<div id="ja-current-content" class="column" style="width:100%">
														<div class="ja-content-main clearfix">
															<div class="main-deal-bottom pie">
																<table class="adsh" cellpadding="0" cellspacing="0" width="100%">
																	<tbody>
																		<tr>
																			<td class="ghd" align="center"><font color="red" >ثبت نام عضو جدید از طریق ایمیل<font></td>
																		</tr>
																	   <tr>
																			<td class="nLines">
																				<form action="" method="post">						
																					<table class="nLines" cellspacing="0" width="100%">
																						<tbody>
																							<tr>
																								<td style="width:40%"><br/>نام و نام خانوادگی:</td>
																								<td>
																									<br/><input name="name" id="name" class="inp1" type="text" value="<?php echo $name5; ?>" />
																								</td>
																							<tr>
																								<td><br/>آدرس ایمیل:</td>
																								<td>
																										<br/><input name="email" id="email" class="inp1" style="font-family:Tahoma;" type="text" value="<?php echo $email1; ?>" />
																								</td>
																							</tr>
																							<tr>
																								<td><br/>رمز عبور (بین 6 تا 20 حرف):</td>
																								<td>
																									<br/><input name="pass" id="pass" class="inp1" type="password" />
																								</td>
																							</tr>
																							<tr>
																								<td><br/>ورود مجدد رمز عبور:</td>
																								<td>
																									<br/><input name="repass" id="repass" class="inp1" type="password" />
																								</td>
																							</tr>
																							<tr>
																								<td><br/>سوال تصادفی:  <strong><?php echo $question; ?></strong></td>
																								<td>
																									<br/><input name="answer" id="answer" class="inp1" type="text" />
																								</td>
																							</tr>
																							<tr>
																								<td colspan="2" align="center">
																									<br/>
																									<input name="rnd" id="rnd" value="<?php echo $rnd; ?>" type="hidden" />
																									<input name="send" id="send" value="ثبت نام" class=	"button" type="submit" />
																								</td>
																							</tr>
																							<tr>
																								<td colspan="2" align="center"><?php echo $msg; ?></td>
																							</tr>
																							<tr>
																								<td colspan="2">
																									اگر به هر دلیلی ایمیل فعال سازی را دریافت نکرده اید<a href="activation"><strong>اینجا</strong></a> را کلیک نمایید. توجه نمایید ابتدا پوشه SPAM یا BULK ایمیل خود را چک نمایید
																								</td>
																							</tr>
																						</tbody>
																					</table>
																				</form>
																			</td>
																		</tr>
																	</tbody>
																</table> 	 			
															</div>
															<div class="main-deal-bottom pie">
																<form action="" method="post">	
																	<table class="adsh" cellpadding="0" cellspacing="0" width="100%">
																		<tbody>
																			<tr>
																				<hr>
																			</tr>
																			<tr>
																				<td class="ghd"  align="center"><font color="red"> رمز عبور خود  را فراموش کرده‌اید؟(از طریق ایمیل)</font></td>
																			</tr>
																			<tr>
																				<td class="nLines">
																					<table border="0" cellpadding="0" cellspacing="0" width="100%">
																						<tbody>
																							<tr>
																								<td width="100%">
																									اگر قبلا ثبت نام کرده اید و اکنون رمز عبور را فراموش کرده اید،آدرس ایمیل خود را وارد کنید، تا لینک تغییر رمز برایتان ارسال شود.
																								</td>
																							</tr>
																							<tr>
																								<td dir="ltr" style="padding: 0px 0px 0px 0px;" align="center" width="100%">
																									<form action="" method="post">	
																										<br/>
																										Email :
																										<input name="email" id="email" style="border: 1px solid #A6A6A6; font-family:Tahoma; font-size:12px; color:#414141; float:none; width:220px; height:22px; background-color:#D3D3D3; padding-right: 5px; padding-left: 5px;" tabindex="10" type="text" />
																										<br/><br/>
																										<input name="forget" id="forget" value="ارسال" class="button" type="submit" />
																										</center>
																									</form>
																								</td>
																							</tr>
																							<tr>
																								<td align="center">
																									<?php echo $msg2; ?>
																								</td>
																							</tr>
																							<tr><td height="4"></td></tr>
																						</tbody>
																					</table>
																				</td>
																			</tr>
																		</tbody>
																	</table>
																</form>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php include "menu.php"; ?>
		</div>
	</div>
	<div id="ja-footer" class="wrap">
		<div class="main clearfix">
			<?php include "dnmenu.php"; ?>
			<div>
				<div align="center">
					<p><?php echo SITE_FOOTER; ?></p>
					<p align ="center"><?php include "copyright.php"; ?></p>
				</div>
			</div>
		</div>
	</div>
</div>
</body></html>