<?php
include "include/db.php";
$msg = '';$msgmob = '';$msgmob1 = '';$msg1= '';$log = '';$i90= '';$current='';$pageid='';

if(isset($_POST['send']))
{
	$siteAddress = Setting::GetSetting(11);
	$siteEmail   = Setting::GetSetting(12);
	$siteName    = Setting::GetSetting(5);
	
	$email         = $_POST["email"];
	$data  = get_email($email);
	
	if(!filter_var($email,FILTER_VALIDATE_EMAIL) OR $data == 2)
	{
		$msg = "<strong><font color=red>ایمیل را صحیح وارد نمایید</font></strong>";
	}
	else
	{
		$result10      = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."user WHERE email = '$email' " );
		$result10_show = mysql_num_rows($result10);
		if( $result10_show > 0 )
		{				
			$result      = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."user WHERE email = '$email'");
			$show_result = $db->sql_fetcharray($result);
			$active = $show_result['active'];
			$code = $show_result['code'];
		
			if($active == 1)
			{
				$msg = "<strong><font color=green>نام کاربری شما فعال است. در صورت مشکل در ورود به سایت فرم تماس با ما را تکمیل نمایید</font></strong>"; 
			}
			else
			{
				$to  = $email;
				$to1 = $siteEmail;
				
				$url = $siteAddress;
				$subject="ارسال مجدد ایمیل فعال سازی";
				$header="from: $siteName <$siteEmail>";
				$message="
				لینک فعال سازی  <br/>
				برای فعال سازی ثبت نام روی لینک زیر کلیک کنید <br/>
				$siteAddress/register/confirmation/$code
				";
				$sentmail = mail($to,$subject,$message,$header);
				if($sentmail)
				{
					$msg = "<strong><font color=green>ایمیل فعال سازی ارسال شد</font><strong>"; 
				}
				else
				{
					$msg = "<strong><font color=red>مشکل در ارسال ایمیل. لحظاتی دیگر تلاش نمایید</font></strong>";     
				}
			}
		}
		else
		{
			$msg = "<strong><font color=red>چنین ایمیلی در سایت ثبت نشده است.</font></strong>";
		}
	}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fa-ir" lang="fa-ir">
<head>
	<meta name="Template" content="" />
	<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
	<meta name="robots" content="index, follow" />
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	<title><?php echo SITE_NAME; ?></title>

    <link   href="<?php echo URL; ?>template/default/css/template.css" rel="stylesheet"      type="text/css" />
    <link   href="<?php echo URL; ?>template/default/css/menu.css"     rel="stylesheet"      type="text/css" />

</head>
<body id="bd" class="fs3 FF">
<div id="ja-wrapper">
	<a name="Top" id="Top"></a>
		<div class="wrap">
		<div class="main">
			<div class="inner clearfix">
				<?php include "topmenu.php" ?>
			</div>
		</div>
	</div>
	<div id="ja-header" class="wrap">
		<div class="main">
			<div class="inner clearfix">
				<div class="logo-text">
					<?php include "logo.php" ?>
				</div>
				<div id="ja-search">
					<?php include "searchbox.php"; ?>
				</div>
			</div>
		</div>
	</div>
	<div id="ja-mainnav" class="wrap">
		<div >
			<?php include "topgroup.php"; ?>
		</div>
	</div>
	<ul class="no-display">
		<li><a href="" title=""></a></li>
	</ul>
	<div id="ja-container" class="wrap ja-l1r1">
		<div class="main clearfix">
			<div id="ja-mainbody" style="width:80%">
				<div class="ja-box1">
					<div class="ja-box2">
						<div id="ja-main" style="width:100%">
							<div class="inner ja-box-br">
								<div class="ja-box-bl">
									<div class="ja-box-tr">
										<div class="ja-box-tl clearfix">
											<div id="ja-breadcrums">
												<div class="inner clearfix">
													<strong></strong> <span class="breadcrumbs pathway">ارسال ایمیل فعال سازی</span>
												</div>
											</div>
											<div id="ja-contentwrap" class="">
												<div id="ja-content" class="column" style="width:100%">
													<div id="ja-current-content" class="column" style="width:100%">
														<div class="ja-content-main clearfix">
															<div class="main-deal-bottom pie">
																<table class="adsh" cellpadding="0" cellspacing="0" width="100%">
																	<tbody>
																		<tr>
																			<td class="ghd" align="center"><font color="red" >ارسال مجدد ایمیل فعال سازی<font></td>
																		</tr>
																	   <tr>
																			<td class="nLines">
																				<form action="" method="post">						
																					<table class="nLines" cellspacing="0" width="100%">
																						<tbody>
																							<tr>
																								<td colspan="2"><font color="red"><b></b></font></td>
																							</tr>
																							<tr>
																								<td>آدرس ایمیل:</td>
																								<td>
																									<div style="text-align:center;margin-top:8px;"> 
																										<input name="email" id="email" class="inp1" type="text" />
																									</div>
																								</td>
																							</tr>
																							<tr>
																								<td></td>
																								<td>
																									<div style="text-align:center;margin-top:8px;"> 
																										<input name="send" id="send" value="ارسال ایمیل فعال سازی" type="submit" class="button" />
																									</div>
																								</td>
																							</tr>
																							<tr>
																								<td colspan="2"><?php echo $msg; ?></td>
																							</tr>
																						</tbody>
																					</table>
																				</form>
																			</td>
																		</tr>
																	</tbody>
																</table> 	 			
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php include "menu.php"; ?>
		</div>
	</div>
	<div id="ja-footer" class="wrap">
		<div class="main clearfix">
			<?php include "dnmenu.php"; ?>
			<div>
				<div align="center">
					<p><?php echo SITE_FOOTER; ?></p>
					<p align ="center"><?php include "copyright.php"; ?></p>
				</div>
			</div>
		</div>
	</div>
</div>

</body></html>