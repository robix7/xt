<?php
include "include/db.php";
if(isset($_SESSION['SUB_ADMIN_ID'])){
if(isset($_GET['url']))
{
    $url = $_GET['url'];
    $url = trim($url,'/');
    $url = explode('/', $url);
    if(count($url)>3) $mid = $url[3];
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fa-ir" lang="fa-ir">
<head>
<meta name="Template" content="">
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="robots" content="index, follow">
<meta name="keywords" content="">
<meta name="description" content="">
<title><?php echo SITE_NAME; ?></title>

<link href="<?php echo URL;?>template/default/css/template.css" rel="stylesheet" type="text/css">


<script>
function conf()
{
	if(confirm("آیا برای حذف این فیش اطمینان دارید؟"))
	{
	return true;
	}
	else
	{
	return false;
	}
}
</script>

</head>
<body id="bd" class="fs3 FF">
<div id="ja-wrapper">
	<a name="Top" id="Top"></a>
	<div id="ja-container" class="wrap ja-l1r1">
		<div class="main clearfix">
			<div id="ja-mainbody" style="width:80%">
				<div class="ja-box1">
					<div class="ja-box2">
						<div id="ja-main" style="width:100%">
							<div class="inner ja-box-br">
								<div class="ja-box-bl">
									<div class="ja-box-tr">
										<div class="ja-box-tl clearfix">
											<div id="ja-breadcrums">
												<div class="inner clearfix">
													<span class="breadcrumbs pathway">فیش های ثبت شده</span>
												</div>
											</div>
											<div id="ja-contentwrap" class="">
												<div id="ja-content" class="column" style="width:100%">
													<div id="ja-current-content" class="column" style="width:100%">
														<div class="ja-content-main clearfix">
															<?php
                                                            if($this->editMode == 1)
                                                            {
                                                                ?>
                                                                <form name="newad" method="post" enctype="multipart/form-data" action="">
                                                                    <table>
                                                                        <tbody>
                                                                            <tr>
                                                                                <td colspan="4">
                                                                                    مبلغ فیش را به ریال وارد نمایید
                                                                                </td>

                                                                            </tr>
                                                                            <tr></tr>
                                                                            <tr>
                                                                                <td>حساب</td>
                                                                                <td>
                                                                                     <select name="account" id="account" style="color:#414141;background-color:LightGrey;font-family:Tahoma;font-size:12px;height:22px;width:175px;">
                                                                                        <?php  

                                                                                            $result6  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."accounts ");
                                                                                            while($show_result6 = $db->sql_fetcharray($result6))
                                                                                            {
                                                                                                $aname   = $show_result6['accountname'];
                                                                                                $anumber = $show_result6['accountnumber'];
                                                                                                $aid     = $show_result6['id'];

                                                                                                if($aid == $this->aid) $s = "selected";
                                                                                                echo $t = "<option value='$aid' $s>$aname--&gt;$anumber</option>";
                                                                                                $s="";
                                                                                            }
                                                                                        ?>
                                                                                    </select>	
                                                                                </td>
                                                                                <td></td>
                                                                                <td></td>
                                                                            <tr>
                                                                            <tr>
                                                                                <td >شماره رسید</td>
                                                                                <td>
                                                                                    <input name="resid" id="resid" value="<?php echo $this->resid; ?>" style="border: 1px solid #A6A6A6; font-family:Tahoma; font-size:12px; color:#414141; float:none; width:175px; height:22px; background-color:#D3D3D3; padding-right: 5px; padding-left: 5px;" tabindex="10" type="text">
                                                                                </td>
                                                                                <td></td>
                                                                                <td></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td >مبلغ</td>
                                                                                <td>
                                                                                    <input name="amount" id="amount" value="<?php echo $this->amount; ?>" style="border: 1px solid #A6A6A6; font-family:Tahoma; font-size:12px; color:#414141; float:none; width:175px; height:22px; background-color:#D3D3D3; padding-right: 5px; padding-left: 5px;" tabindex="10" type="text">
                                                                                </td>
                                                                                <td></td>
                                                                                <td></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <?php
                                                                                    $ti      = date('Y-m-d',time());
                                                                                    $tij     = g_to_j($ti);
                                                                                ?>
                                                                                <td >تاریخ</td>
                                                                                <td>
                                                                                    <input name="date" id="date" value="<?php echo $this->fdate; ?>" style="border: 1px solid #A6A6A6; font-family:Tahoma; font-size:12px; color:#414141; float:none; width:175px; height:22px; background-color:#D3D3D3; padding-right: 5px; padding-left: 5px;" tabindex="10" type="text">
                                                                                </td>
                                                                                <td></td>
                                                                                <td></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td >نام پرداخت کننده</td>
                                                                                <td>
                                                                                    <input name="sender" id="sender" value="<?php echo $this->sender; ?>" style="border: 1px solid #A6A6A6; font-family:Tahoma; font-size:12px; color:#414141; float:none; width:175px; height:22px; background-color:#D3D3D3; padding-right: 5px; padding-left: 5px;" tabindex="10" type="text">
                                                                                </td>
                                                                                <td></td>
                                                                                <td></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td>توضیحات</td>
                                                                                <td>
                                                                                    <textarea name="comment" id="comment" rows="10" cols="51" style="color:#414141;background-color:LightGrey;font-family:Tahoma;font-size:12px;"><?php echo $this->comment; ?></textarea>
                                                                                </td>
                                                                                <td></td>
                                                                                <td></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td colspan="4" align="center" width="449" height="26">
                                                                                    <br>
                                                                                    <input value="<?php echo $mid; ?>" name="id" id="id" type="hidden" />
                                                                                    <input class="inputbox" dir="rtl" value="ویرایش" name="regfish" id="regfish" style="width: 100px;" type="submit" />  
                                                                                    <input class="inputbox" dir="rtl" value="انصراف" name="canfish" id="canfish" style="width: 100px;" type="button" onclick=window.location='<?php echo URL; ?>admin/fish' /> 
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td colspan="4" align="center" width="449" height="26">
                                                                                    <?php
                                                                                        echo $this->msg;
                                                                                    ?>

                                                                                </td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>	
                                                                </form>
                                                                <?php
                                                            }
																$cnt_query = $db->sql_query("SELECT COUNT(`id`) FROM ".TABLE_PREFIX."fish ");
																$cnt_a     = mysql_fetch_row($cnt_query);
																$cnt       = $cnt_a[0];
																$r=0;
																$ipp = 3;							
																$pageconf = array('all'=>$cnt,'range'=>$ipp,'inpage'=>$this->page,'limit'=>5 ,'url'=>URL.'admin/fish/');

																$pagenumber = new pagination($pageconf);
																echo $pagenumber->pagenumber();

															?>
															<table id="table1" class="sortable" style="font: 11px Tahoma; background: #fff; color: #091f30; width: 100%" border="0" cellpadding="0" cellspacing="0">
																<thead>
																	<tr style="height:5px;vertical-align:middle">
																		<th class="tabl">
																			ردیف
																		</th>
																		<th class="tabl">
																			نام بانک
																		</th>
																		<th class="tabl">
																			تاریخ ثبت
																		</th>
																		<th class="tabl">
																			شماره رسید
																		</th>
																		<th  class="tabl">
																			مبلغ
																		</th>
																		<th class="tabl">
																		   تاریخ واریز
																		</th>
																		 <th class="tabl">
																			نام پرداخت کننده
																		</th>
																		<th class="tabl">
																			توضیحات
																		</th>
																		<th class="tabl">
																			وضعیت
																		</th>
																		<th class="tabl">
																			عملیات
																		</th>

																	</tr>
																</thead>
																<tbody>
																	<?php
																	$result  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."fish ORDER BY `date` DESC" );
																	while($show_result=$db->sql_fetcharray($result))
																	{
																		$r++;
																		if($r > $this->page*$ipp) break;
																		if($r <= $this->page*$ipp and $r >= $this->page*$ipp-$ipp+1)
																		{
																			$id      = $show_result['id'];
																			$aid     = $show_result['aid'];
																			$uid     = $show_result['uid'];
																			$fdate   = $show_result['fdate'];
																			$date    = $show_result['date'];
																			$fnumber = $show_result['fnumber']; 
																			$amount  = $show_result['amount'];   
																			$sender  = $show_result['sender']; 
																			$comment = $show_result['comment']; 
																			$status   = $show_result['status']; 
																			$tij     = s_to_j($date);
																			
																			if($comment == NULL) $comment = "-";
																			if($sender == NULL OR $sender == 0)  $sender = "-";
																			if($fnumber == NULL OR $fnumber == 0)  $fnumber = "-";
																			
																			$result1 = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."accounts WHERE id = '$aid'");
																			$show_result1 = $db->sql_fetcharray($result1);
																			$aname = $show_result1['accountname'];
																			$anumber = $show_result1['accountnumber'];							
																			
																			$result1 = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."user WHERE id = '$uid'");
																			$show_result1 = $db->sql_fetcharray($result1);
																			$email = $show_result1['email'];	
																			
																			if($status == 0) $cs = "منتظر تایید";
																			if($status == 1) $cs = "تایید شده";
																			
																			$col = "#FFFFFF";
																			if($status == 0) 
																			{
																				$col = "#CC9";
																			}
																			?>
																			<tr style="background-color:<?php echo $col; ?>">
																				<td rowspan="2"><?php echo $r; ?></td>
																				<td colspan="9">
																					<a href="adslist.php?cmd=user&id=<?php echo $uid; ?>" target="_blank" title="نمایش آگهی های این کاربر" style="font-family:Tahoma;"><?php echo $email; ?></a>
																				</td>
																			</tr>
																			<tr style="background-color:<?php echo $col; ?>">
																				<td><?php echo $aname." - ".$anumber; ?></td>
																				<td><?php echo $tij; ?></td>
																				<td><?php echo $fnumber; ?></td>
																				<td><?php echo sefr($amount); ?></td>
																				<td><?php echo $fdate; ?></td>
																				<td><?php echo $sender; ?><br></td>
																				<td><?php echo $comment; ?></td>
																				<td><?php echo $cs; ?></td>
																				<td>							
																					<table>
																						<tbody>
																							<tr>
																								<td>
																									<a href="<?php echo URL; ?>admin/fish/edit/<?php echo $id; ?>">
																										<img src="<?php echo URL; ?>template/default/image/edit.gif" border="0">
																									</a>
																								</td>
																								<td>
																									<a href="<?php echo URL; ?>admin/fish/delete/<?php echo $id; ?>">
																										<img src="<?php echo URL; ?>template/default/image/delete.gif" border="0"  onclick="return conf()">
																									</a>
																								</td>
																								<td>
                                                                                                    <a href="<?php echo URL; ?>admin/fish/confirm/<?php echo $id; ?>">
                                                                                                        <img src="<?php echo URL; ?>template/default/image/refresh.gif" border="0">
                                                                                                    </a>
																								</td>
																							</tr>
																						</tbody>
																					</table>
																				</td>
																			</tr>
																			<?php
																		}
																	}
																	?>
																</tbody>
															</table>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php include "adminmenu.php"; ?>
		</div>
	</div>
	<div id="ja-footer" class="wrap">
		<div class="main clearfix">
			<div class="ja-footnav clearfix">
				<ul class="ja-links">
					<li class="top">
						<a href="#Top" title="Back to Top">بالا</a>
					</li>
				</ul>
			</div>

			<div>
				<div align="center">
					<p><?php echo SITE_FOOTER; ?></p>
					﻿<p align ="center"><?php include "copyright.php"; ?></p>
				</div>
			</div>
		</div>
	</div>
</div>
</body></html>
<?php
}
else
{
	header("Location: index.php");
}
?>
