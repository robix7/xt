<?php
require "include/db.php";
if(isset($_SESSION['SUB_ADMIN_ID'])){

$msg = '';

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fa-ir" lang="fa-ir"><head>
<meta name="Template" content="">
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="robots" content="index, follow">
<meta name="keywords" content="">
<meta name="description" content="">
<title><?php echo SITE_NAME; ?></title>
  
  
<link href="<?php echo URL;?>template/default/css/template.css" rel="stylesheet" type="text/css">

</head>
<body id="bd" class="fs3 FF">
<div id="ja-wrapper">
	<a name="Top" id="Top"></a>
	<div id="ja-container" class="wrap ja-l1r1">
		<div class="main clearfix">
			<div id="ja-mainbody" style="width:80%">
				<div class="ja-box1">
					<div class="ja-box2">
						<div id="ja-main" style="width:100%">
							<div class="inner ja-box-br">
								<div class="ja-box-bl">
									<div class="ja-box-tr">
										<div class="ja-box-tl clearfix">
											<div id="ja-breadcrums">
												<div class="inner clearfix">
													<strong></strong> <span class="breadcrumbs pathway">بازدید کننده ها</span>
												</div>
											</div>
											<div id="ja-contentwrap" class="">
												<div id="ja-content" class="column" style="width:100%">
													<div id="ja-current-content" class="column" style="width:100%">
														<div class="ja-content-main clearfix">
														<?php
															$cnt_query = $db->sql_query("SELECT COUNT(id) FROM ".TABLE_PREFIX."visit WHERE kind = 2 ORDER BY id DESC ");
															$cnt_a     = mysql_fetch_row($cnt_query);
															$cnt       = $cnt_a[0];
															$r=0;
															$getip = 1;
															if(isset($_GET['ip'])) $getip = $_GET['ip'];
															
															$teh = 9000;
															if(isset($_GET['page']))
															{
																$page = $_GET['page']; 
															}
															else
															{
																$page = 1;
															}
															$ipp = 50;							
															$pageconf = array(
															'all'=>$cnt ,	 // select count(*) from post where 
															'range'=>$ipp , 	// select * from post limit (inpage-1)*range,range
															'inpage'=>$page,	// current page. example $_GET[]
															'limit'=>5 ,	// use number of li for minimize
															'url'=>'visitor.php?page=' // url of page. the number showed in end of url
															);

															$pagenumber = new pagination($pageconf);
															echo $pagenumber->pagenumber();
															
															?>
															<table id="table1" class="sortable" style="font: 11px Tahoma; background: #fff; color: #091f30; width: 100%" border="0" cellpadding="0" cellspacing="0">
																<thead>
																	<tr style="height:5px;vertical-align:middle">
																		<th class="tabl">
																			ردیف
																		</th>
																		<th class="tabl">
																			زمان
																		</th>
																		<th class="tabl">
																			IP
																		</th>
																		<th class="tabl">
																			صفحه
																		</th>	
																		<th class="tabl">
																			لینک دهنده
																		</th>											
																	</tr>
														<?php
															if($getip == 1)
															{
																$result  = $db->sql_query(" SELECT * FROM ".TABLE_PREFIX."visit WHERE kind = 2 ORDER BY id DESC ");
															}
															else
															{
																$result  = $db->sql_query(" SELECT * FROM ".TABLE_PREFIX."visit WHERE kind = 2 AND ip = '$getip' ORDER BY id DESC ");
															}
															while($row=$db->sql_fetcharray($result))
															{
																$r++;
																if($r > $page*$ipp) break;
																if($r <= $page*$ipp and $r >= $page*$ipp-$ipp+1)
																{
																	$time = $row["time"];
																	$ip   = $row["ip"];
																	$pid  = $row["productid"];
																	$ref  = $row["ref"];	
																	$page1 = "صفحه اصلی";
																	$jdate  = s_to_j($time);
																	
																	
																	?>
																	<tr>
																		 <td align="center">
																			<?php echo $r; ?>
																		</td>
																		 <td align="center">
																			<?php echo $jdate." - ".date('H:i:s',$time+9000); ?>
																		</td>
																		<td align="center">
																			 <a href="?ip=<?php echo $ip; ?>"><?php echo $ip; ?> </a>
																		</td>
																		 <td align="center">
																			<?php echo $page1; ?>
																		</td>
																		<td align="left">
																			 <a href="<?php echo urldecode($ref); ?>" target="_blank" style="font-family:Tahoma;"><?php echo rawurldecode($ref); ?> </a>
																		</td>											
																	</tr>
																	<?php
																}
															}
															?>
														</table>
														<?php

														echo $pagenumber->pagenumber();
														
														?>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php include "adminmenu.php"; ?>
		</div>
	</div>
	<div id="ja-footer" class="wrap">
		<div class="main clearfix">
			<div class="ja-footnav clearfix">
				<ul class="ja-links">
					<li class="top">
						<a href="#Top" title="Back to Top">بالا</a>
					</li>
				</ul>
			</div>
			<div>
				<div align="center">
					<p><?php echo SITE_FOOTER; ?></p>
					<p align ="center"><?php include "copyright.php"; ?></p>
				</div>
			</div>
		</div>
	</div>
</div>
</body></html>
<?php
}
else
{
	header("Location: index.php");
}
?>