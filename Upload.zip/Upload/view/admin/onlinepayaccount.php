<?php
require "include/db.php";
if(isset($_SESSION['SUB_ADMIN_ID'])) {
if(isset($_GET['url']))
{
    $url = $_GET['url'];
    $url = trim($url,'/');
    $url = explode('/', $url);
    if(count($url)>3) $mid = $url[3];
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fa-ir" lang="fa-ir"><head>
<meta name="Template" content="">
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="robots" content="index, follow">
<meta name="keywords" content="">
<meta name="description" content="">
<title><?php echo SITE_NAME; ?></title>
  
<link href="<?php echo URL;?>template/default/css/template.css" rel="stylesheet" type="text/css">


<script>
	function conf()
	{
		if(confirm("آیا می خواهید حساب بانکی را حذف نمایید؟"))
		{
            return true;
		}
		else
		{
            return false;
		}
	}
    function confirm(bankid,parameter1,parameter2)
	{
		if(bankid == 0 || parameter1 == '')
		{
			alert("انتخاب درگاه پرداخت و پارامتر اول الزامی است. پارامتر دوم در برخی از درگاه ها الزامی می باشد.");
			return false;
		}
		else
		{
			if(confirm("آیا برای ثبت این درگاه مطمئن هستید؟"))
			{
                return true;
			}
            else
			{
                return false;
			}
		}
	}
</script>

</head>
<body id="bd" class="fs3 FF">
<div id="ja-wrapper">
	<a name="Top" id="Top"></a>
	<div id="ja-container" class="wrap ja-l1r1">
		<div class="main clearfix">
			<div id="ja-mainbody" style="width:80%">
				<div class="ja-box1">
					<div class="ja-box2">
						<div id="ja-main" style="width:100%">
							<div class="inner ja-box-br">
								<div class="ja-box-bl">
									<div class="ja-box-tr">
										<div class="ja-box-tl clearfix">
											<div id="ja-breadcrums">
												<div class="inner clearfix">
													<strong></strong> <span class="breadcrumbs pathway">افزودن و ویرایش روش های پرداخت آنلاین</span>
												</div>
											</div>
											<div id="ja-contentwrap" class="">
												<div id="ja-content" class="column" style="width:100%">
													<div id="ja-current-content" class="column" style="width:100%">
														<div class="ja-content-main clearfix">
															<form name="newad" method="post" enctype="multipart/form-data" action="<?php echo URL;?>admin/onlinepayaccount">
																<div>
																	<div style="float:right; text-align:right; width:20%;height:30px;">
																		نام بانک
																	</div>
																	<div style="float:right; text-align:right; width:30%;height:30px;">
																		<select name="bankid" id="bankid" class="inp2">
																			<option value='0'>-</option>
                                                                            <?php  
																			$result  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."onlinebank ");
																			while($show_result = $db->sql_fetcharray($result))
																			{
																				$id        = $show_result['id'];
																				$name      = $show_result['name'];
																				$nameFarsi = $show_result['comment'];
																				if($id == $this->bankid) $s="selected";
																				echo "<option value='$id' $s>$nameFarsi</option>";
																				$s='';
																			}
																			?>
																		</select>
																	</div>
																	<div style="float:right; text-align:right; width:50%;height:30px;">
																	
																	</div>
																</div>
																<div>
																	<div style="float:right; text-align:right; width:20%;height:30px;">
																		پارامتر اول
																	</div>
																	<div style="float:right; text-align:right; width:30%;height:30px;">
																		<input name="parameter1" id="parameter1" value="<?php echo $this->parameter1; ?>" class="inp1" type="text">
																	</div>
																	<div style="float:right; text-align:right; width:50%;height:30px;">
																	
																	</div>
																</div>
																<div>
																	<div style="float:right; text-align:right; width:20%;height:30px;">
																		پارامتر دوم
																	</div>
																	<div style="float:right; text-align:right; width:30%;height:30px;">
																		<input name="parameter2" id="parameter2" value="<?php echo $this->parameter2; ?>" class="inp1" type="text">
																	</div>
																	<div style="float:right; text-align:right; width:50%;height:30px;">
																	
																	</div>
																</div>
																<div>
																	<div style="float:right; text-align:right; width:20%;height:30px;">
																		وضعیت
																	</div>
																	<div style="float:right; text-align:right; width:30%;height:30px;">
																		<select name="accountstatus" id="accontstatus" value="<?php echo $accountstatus; ?>" class="inp2">
																			<option selected="selected" value="0">غیرفعال</option>
																			<option value="1">فعال</option>
																		</select>
																	</div>
																	<div style="float:right; text-align:right; width:50%;height:30px;">
																	
																	</div>
																</div>
																<div>
																	<div style="float:right; text-align:right; width:20%;height:30px;">
                                                                        <input name="id" id="id" value="<?php echo $id; ?>" type="hidden">
																	</div>
																	<div style="float:right; text-align:right; width:30%;height:30px;">
																		<?php
																			if($this->editMode == 1)
																			{
																				?>
																				<input class="inputbox" dir="rtl" value="  ویرایش  " name="editonlinemethod" id="editonlinemethod" style="width: 100px;" type="submit" onclick="return confirm(bankid.value,parameter1.value,parameter2.value);" />  
                                                                                <input value="<?php echo $mid; ?>" name="id" id="id" style="width:100px;" type="hidden" />  
																				<?php
																			}
																			else
																			{
																				?>
																				<input class="inputbox" dir="rtl" value="  افزودن  " name="addonlinemethod" id="addonlinemethod" style="width: 100px;" type="submit" onclick="return confirm(bankid.value,parameter1.value,parameter2.value);">
																				<?php
																			}
																			?>
																		<input class="inputbox" dir="rtl" value="  انصراف  " name="canads" id="canads" style="width: 100px;" type="button" onclick=window.location='<?php echo URL; ?>admin/admin' />
																	</div>
																	<div style="float:right; text-align:right; width:50%;height:30px;">
																		
																	</div>
																</div>
                                                                <div>
																	<div style="float:right; text-align:right; width:20%;height:30px;">
																	</div>
																	<div style="float:right; text-align:right; width:30%;height:30px;">
																	<?php echo $this->msg; ?>
                                                                    </div>
																	<div style="float:right; text-align:right; width:50%;height:30px;">	
																	</div>
																</div>
															</form>
															<table id="table1" class="sortable" style="font: 11px Tahoma; background: #fff; color: #091f30; width: 100%" border="0" cellpadding="0" cellspacing="0">
																<thead>
																	<tr style="height:5px;vertical-align:middle">
																		<th class="tabl">
																			ردیف
																		</th>
																		<th class="tabl">
																			درگاه پرداخت
																		</th>
																		<th class="tabl">
																			پارامتر اول
																		</th>
																		<th class="tabl">
																			پارامتر دوم
																		</th>
																		<th class="tabl">
																			وضعیت
																		</th>
																		<th class="tabl">
																			عملیات
																		</th>
																	</tr>
																</thead>
																<tbody>
																	<?php
																	$i=0;
																	$result  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."onlinemethod" );
																	while($show_result = $db->sql_fetcharray($result))
																	{
																		$i++;
																		$id            = $show_result['id'];
																		$bankid        = $show_result['bankid'];
																		$parameter1    = $show_result['parameter1'];
																		$parameter2    = $show_result['parameter2'];
																		$accountstatus = $show_result['accountstatus'];
																		
																		$result1      = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."onlinebank WHERE id = '$bankid'" );
																		$show_result1 = $db->sql_fetcharray($result1);
																		$bankname     = $show_result1['comment'];
																		
																		if($accountstatus == 0) 
																		{
																			$col = "#CC9";
																			$st = "غیر فعال";
																		}
																		else
																		{
																			$col = "#FFFFFF";
																			$st = "فعال";
																		}
																		
																		?>
																		<tr style="background-color:<?php echo $col; ?>">
																			<td style="text-align: center;"><?php echo $i; ?></td>
																			<td style="text-align: center;"><?php echo $bankname; ?></td>
																			<td style="text-align: center;"><?php echo $parameter1; ?></td>
																			<td style="text-align: center;"><?php echo $parameter2; ?></td>
																			<td style="text-align: center;"><?php echo $st; ?></td>
																			<td style="text-align: center;">							
																				<table>
																					<tbody>
																						<tr>
																							<td>
																								<a href="<?php echo URL; ?>admin/onlinepayaccount/edit/<?php echo $id; ?>">
																									<img src="<?php echo URL;?>template/default/image/edit.gif" border="0">
																								</a>
																							</td>
																							<td>
																								<a href="<?php echo URL; ?>admin/onlinepayaccount/delete/<?php echo $id; ?>" onclick="return conf()">
																									<img src="<?php echo URL;?>template/default/image/delete.gif" title="حذف حساب" />
																								</a>
																							</td>
																						</tr>
																					</tbody>
																				</table>
																			</td>
																		</tr>
																		<?php
																	}
																	?>
																</tbody>
															</table>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php include "adminmenu.php"; ?>

		</div>
	</div>
	<div id="ja-footer" class="wrap">
		<div class="main clearfix">
			<div class="ja-footnav clearfix">
				<ul class="ja-links">
					<li class="top">
						<a href="#Top" title="Back to Top">بالا</a>
					</li>
				</ul>
			</div>

			<div>
				<div align="center">
					<p><?php echo SITE_FOOTER; ?></p>
					﻿<p align ="center"><?php include "copyright.php"; ?></p>
				</div>
			</div>
		</div>
	</div>
</div>
</body></html>
<?php
}
else
{
	header("Location: index.php");
}
?>
