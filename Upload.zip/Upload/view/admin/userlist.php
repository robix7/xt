<?php
require "include/db.php";
if(isset($_SESSION['SUB_ADMIN_ID'])){
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fa-ir" lang="fa-ir"><head>
<meta name="Template" content="">
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="robots" content="index, follow">
<meta name="keywords" content="">
<meta name="description" content="">
<title><?php echo SITE_NAME; ?></title>
 
 
<link href="<?php echo URL; ?>template/default/css/template.css" rel="stylesheet" type="text/css">

<script>
	function conf()
	{
		if(confirm(" آیا ميخواهيد اين کاربر را حذف نماييد؟ با این عمل کلیه آگهی ها  و حساب کاربری حذف خواهند شد."))
		{
		return true;
		}
		else
		{
		return false;
		}
	}
</script>
</head>

<body id="bd" class="fs3 FF">
<div id="ja-wrapper">
	<a name="Top" id="Top"></a>
	<div id="ja-container" class="wrap ja-l1r1">
		<div class="main clearfix">
			<div id="ja-mainbody" style="width:80%">
				<div class="ja-box1">
					<div class="ja-box2">
						<div id="ja-main" style="width:100%">
							<div class="inner ja-box-br">
								<div class="ja-box-bl">
									<div class="ja-box-tr">
										<div class="ja-box-tl clearfix">
											<div id="ja-breadcrums">
												<div class="inner clearfix">
													<strong></strong> <span class="breadcrumbs pathway">لیست کاربران</span>
												</div>
											</div>
											<div id="ja-contentwrap" class="">
												<div id="ja-content" class="column" style="width:100%">
													<div id="ja-current-content" class="column" style="width:100%">
														<div class="ja-content-main clearfix">
															<?php
                                                                echo $this->msg;
																$cnt_query = $db->sql_query("SELECT COUNT(`id`) FROM ".TABLE_PREFIX."user ");
																$cnt_a     = mysql_fetch_row($cnt_query);
																$cnt       = $cnt_a[0];
																$r=0;
																$ipp = 3;							
																$pageconf = array('all'=>$cnt,'range'=>$ipp,'inpage'=>$this->page,'limit'=>5,'url'=>URL.'admin/userlist/sort/'.$this->sort.'/page/');

																$pagenumber = new pagination($pageconf);
																echo $pagenumber->pagenumber();

															?>
															<table id="table1" class="sortable" style="font: 11px Tahoma; background: #fff; color: #091f30; width: 100%" border="0" cellpadding="0" cellspacing="0">
																<thead>
																	<tr style="height:5px;vertical-align:middle">
																		<th class="tabl">
																			ردیف
																		</th>
																		<th class="tabl">
																			تاریخ عضویت		
																			<a href="<?php echo URL; ?>admin/userlist/sort/<?php echo $this->s1 ?>"><img src="<?php echo URL; ?>template/default/image/sort.png" title="مرتب سازی" /></a>
																		</th>
																		<th class="tabl">
																			شماره عضویت
																		</th>
																		<th class="tabl">
																			نام
																			<a href="<?php echo URL; ?>admin/userlist/sort/<?php echo $this->s2 ?>"><img src="<?php echo URL; ?>template/default/image/sort.png" title="مرتب سازی" /></a>
																		</th>
																		<th  class="tabl">
																			ایمیل
																			<a href="<?php echo URL; ?>admin/userlist/sort/<?php echo $this->s3 ?>"><img src="<?php echo URL; ?>template/default/image/sort.png" title="مرتب سازی" /></a>
																		</th>
																		<th class="tabl">
																		   وضعیت ایمیل
																		   <a href="<?php echo URL; ?>admin/userlist/sort/<?php echo $this->s4 ?>"><img src="<?php echo URL; ?>template/default/image/sort.png" title="مرتب سازی" /></a>
																		</th>
																		<th class="tabl">
																			تعداد آگهی
																		</th>
																		<th class="tabl">
																		   آخرین ورود
																		   <a href="<?php echo URL; ?>admin/userlist/sort/<?php echo $this->s5 ?>"><img src="<?php echo URL; ?>template/default/image/sort.png" title="مرتب سازی" /></a>
																		</th>
																		<th class="tabl">
																		   عملیات
																		</th>
																	</tr>
																</thead>
																<tbody>
																	<?php
																	$result  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."user ORDER BY `id` DESC" );
																	if($this->sort == 1)  $result  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."user ORDER BY `code` DESC" );
																	if($this->sort == 2)  $result  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."user ORDER BY `code` ASC" );
																	if($this->sort == 3)  $result  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."user ORDER BY `name` DESC" );
																	if($this->sort == 4)  $result  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."user ORDER BY `name` ASC" );
																	if($this->sort == 5)  $result  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."user ORDER BY `email` DESC" );
																	if($this->sort == 6)  $result  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."user ORDER BY `email` ASC" );
																	if($this->sort == 7)  $result  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."user ORDER BY `active` DESC" );
																	if($this->sort == 8)  $result  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."user ORDER BY `active` ASC" );
																	if($this->sort == 9)  $result  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."user ORDER BY `login` DESC" );
																	if($this->sort == 10) $result  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."user ORDER BY `login` ASC" );
																	while($show_result=$db->sql_fetcharray($result))
																	{
																		$r++;
																		if($r > $this->page*$ipp) break;
																		if($r <= $this->page*$ipp and $r >= $this->page*$ipp-$ipp+1)
																		{
																			$id      = $show_result['id'];
																			$name    = $show_result['name'];
																			$email   = $show_result['email'];
																			$active  = $show_result['active']; 
																			$code    = $show_result['code'];   
																			$login   = $show_result['login'];  
																			$ti      = date('Y-m-d',$code);
																			$tij     = g_to_j($ti);
																			
																			if(get_lang($name)== 1) $lang = "Tahoma";
																			if(get_lang($name)== 2) $lang = NULL;
																			
																			if($active == 1) $emailstatus = "<font color=green>تایید شده</font>";
																			if($active == 0) $emailstatus = "<font color=red>تایید نشده</font>";
																			
																			$cnt       = my_count(TABLE_PREFIX.'advertise','id','uid',$id,-1,-1,-1,-1,-1,-1,-1,-1);
																			
																			if($login > 0 )
																			{
																				$lastLogin = s_to_j($login);
																			}
																			else
																			{
																				$lastLogin = "";
																			}
																			$col = "#FFFFFF";
																			if($active == 0) 
																			{
																				$col = "#CC9";
																			}
																			if($active == 2) 
																			{
																				$col = "#AA9";
																			}
																			if($active == 2) 
																			{
																				$cn = "حذف شده";
																			}

																			?>
																			<tr style="background-color:<?php echo $col; ?>">
																				<td style="text-align: center;"><?php echo $r; ?></td>
																				<td style="text-align: center;"><?php echo $tij; ?></td>
																				<td style="text-align: center;"><?php echo $id; ?></td>
																				<td style="text-align: center;font-family:<?php echo $lang; ?>;"><?php echo $name; ?></td>
																				<td style="text-align: center;"><a href="adslist.php?cmd=user&id=<?php echo $id; ?>" target="_blank" title="نمایش آگهی های این کاربر" style="font-family:Tahoma;"><?php echo $email; ?></a></td>
																				<td style="text-align: center;"><?php echo $emailstatus; ?></td>
																				<td style="text-align: center;" ><?php echo $cnt; ?></td>
																				<td style="text-align: center;"><?php echo $lastLogin; ?></td>
																				<td style="text-align: center;">
																					<?php
																					if($active != 2)
																					{
																						?>
																						<table>
																							<tbody>
																								<tr>
																									<td>
																										<a href="<?php echo URL; ?>admin/userlist/delete/<?php echo $id; ?>" onclick="return conf()">
																											<img src="<?php echo URL; ?>template/default/image/delete.gif" title="حذف کاربر" />
																										</a>
																									</td>
																								</tr>
																							</tbody>
																						</table>
																						<?php
																					}
																					?>
																				</td>
																			</tr>
																			<?php
																		}
																	}
																	?>
																</tbody>
															</table>	
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php include "adminmenu.php"; ?>
		</div>
	</div>
	<div id="ja-footer" class="wrap">
		<div class="main clearfix">
			<div class="ja-footnav clearfix">
				<ul class="ja-links">
					<li class="top">
						<a href="#Top" title="Back to Top">بالا</a>
					</li>
				</ul>
			</div>

			<div>
				<div align="center">
					<p><?php echo SITE_FOOTER; ?></p>
					﻿<p align ="center"><?php include "copyright.php"; ?></p>
				</div>
			</div>
		</div>
	</div>
</div>
</body></html>
<?php
}
else
{
	header("Location: index.php");
}
?>
