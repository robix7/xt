<?php
require "include/db.php";
if(isset($_SESSION['SUB_ADMIN_ID'])) {
$c='';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fa-ir" lang="fa-ir"><head>
<meta name="Template" content="">
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="robots" content="index, follow">
<meta name="keywords" content="">
<meta name="description" content="">
<title><?php echo SITE_NAME; ?></title>
  
<link href="<?php echo URL;?>template/default/css/template.css" rel="stylesheet" type="text/css">

</style>
<script>
	function conf()
	{
		if(confirm("آبا برای حذف این حساب مطمئن هستید؟"))
		{
            return true;
		}
		else
		{
            return false;
		}
	}
    function confirm(accountname,accountnumber,accountholder)
	{
        if(accountname == '' || accountnumber == '' || accountholder == '')
		{
			alert("نام بانک، شماره حساب و نام صاحب حساب الزامی می باشد.");
			return false;
		}
		else
		{
			if(confirm("آیا برای ثبت این آگهی مطمئن هستید؟"))
			{
                return true;
			}
			else
			{
                return false;
			}
		}
	}
</script>
</head>
<body id="bd" class="fs3 FF">
<div id="ja-wrapper">
<a name="Top" id="Top"></a>
	<div id="ja-container" class="wrap ja-l1r1">
		<div class="main clearfix">
			<div id="ja-mainbody" style="width:80%">
				<div class="ja-box1">
					<div class="ja-box2">
						<div id="ja-main" style="width:100%">
							<div class="inner ja-box-br">
								<div class="ja-box-bl">
									<div class="ja-box-tr">
										<div class="ja-box-tl clearfix">
											<div id="ja-breadcrums">
												<div class="inner clearfix">
													<strong></strong> <span class="breadcrumbs pathway">افزودن و ویرایش حساب های بانکی</span>
												</div>
											</div>
											<div id="ja-contentwrap" class="">
												<div id="ja-content" class="column" style="width:100%">
													<div id="ja-current-content" class="column" style="width:100%">
														<div class="ja-content-main clearfix">				
															<form name="newad" method="post" enctype="multipart/form-data" action="">
																<div>
																	<div style="float:right; text-align:right; width:20%;height:30px;">
																		نام بانک
																	</div>
																	<div style="float:right; text-align:right; width:30%;height:30px;">
																		<input name="accountname" id="accountname" class="inp1" type="text">
																	</div>
																	<div style="float:right; text-align:right; width:50%;height:30px;">
																	
																	</div>
																</div>
																<div>
																	<div style="float:right; text-align:right; width:20%;height:30px;">
																		شماره حساب
																	</div>
																	<div style="float:right; text-align:right; width:30%;height:30px;">
																		<input name="accountnumber" id="accountnumber" class="inp1" type="text">
																	</div>
																	<div style="float:right; text-align:right; width:50%;height:30px;">
																	
																	</div>
																</div>
																<div>
																	<div style="float:right; text-align:right; width:20%;height:30px;">
																		شماره کارت
																	</div>
																	<div style="float:right; text-align:right; width:30%;height:30px;">
																		<input name="accountatm" id="accountatm" class="inp1" type="text">
																	</div>
																	<div style="float:right; text-align:right; width:50%;height:30px;">
																	
																	</div>
																</div>
																<div>
																	<div style="float:right; text-align:right; width:20%;height:30px;">
																		شماره شبا
																	</div>
																	<div style="float:right; text-align:right; width:30%;height:30px;">
																		<input name="accountsheba" id="accountsheba" class="inp1" type="text">
																	</div>
																	<div style="float:right; text-align:right; width:50%;height:30px;">
																	
																	</div>
																</div>
																<div>
																	<div style="float:right; text-align:right; width:20%;height:30px;">
																		نام صاحب حساب
																	</div>
																	<div style="float:right; text-align:right; width:30%;height:30px;">
																		<input name="accountholder" id="accountholder" class="inp1" type="text">
																	</div>
																	<div style="float:right; text-align:right; width:50%;height:30px;">
																	
																	</div>
																</div>
																<div>
																	<div style="float:right; text-align:right; width:20%;height:30px;">

																	</div>
																	<div style="float:right; text-align:right; width:30%;height:30px;">
																		<input class="inputbox" dir="rtl" value="  افزودن  " name="sendaccount" id="sendaccount" style="width: 100px;" type="submit" onclick="return confirm(accountname.value,accountnumber.value,accountholder.value);">
																		<input class="inputbox" dir="rtl" value="  انصراف  " name="canads" id="canads" style="width: 100px;" type="button" onclick=window.location='<?php echo URL; ?>admin/admin'>&nbsp; 
																	</div>
																	<div style="float:right; text-align:right; width:50%;height:30px;">
																		
																	</div>
																</div>	
															</form>
															<?php echo $this->msg; ?>
                                                            <?php
																
																$cnt_query = $db->sql_query("SELECT COUNT(`id`) FROM ".TABLE_PREFIX."accounts ");
																$cnt_a     = mysql_fetch_row($cnt_query);
																$cnt       = $cnt_a[0];
																$r=0;
																$ipp = 3;							
																$pageconf = array('all'=>$cnt,'range'=>$ipp,'inpage'=>$this->page,'limit'=>5,'url'=>URL.'admin/account/page/');
																$pagenumber = new pagination($pageconf);
																echo $pagenumber->pagenumber();

														?>
															<table id="table1" class="sortable" style="font: 11px Tahoma; background: #fff; color: #091f30; width: 100%" border="0" cellpadding="0" cellspacing="0">
																<thead>
																	<tr style="height:5px;vertical-align:middle">
																		<th class="tabl">
																			ردیف
																		</th>
																		<th class="tabl">
																			نام بانک
																		</th>
																		<th class="tabl">
																			شماره حساب
																		</th>
																		<th class="tabl">
																			شماره کارت
																		</th>
																		<th class="tabl">
																			شماره شبا
																		</th>
																		<th class="tabl">
																			صاحب حساب
																		</th>
																		<th class="tabl">
																			وضعیت
																		</th>
																	</tr>
																</thead>
																<tbody>
																	<?php
																	$result  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."accounts" );
																	while($show_result=$db->sql_fetcharray($result))
																	{
																		$r++;
                                                                        if($r > $this->page*$ipp) break;
                                                                        if($r <= $this->page*$ipp and $r >= $this->page*$ipp-$ipp+1)
                                                                        {
                                                                            $id            = $show_result['id'];
                                                                            $accountname   = $show_result['accountname'];
                                                                            $accountnumber = $show_result['accountnumber'];
                                                                            $accountatm    = $show_result['accountatm'];
                                                                            $accountsheba  = $show_result['accountsheba'];
                                                                            $accountholder = $show_result['accountholder'];
                                                                            $col = "#FFFFFF";
                                                                            $c++
                                                                            ?>
                                                                            <tr style="background-color:<?php echo $col; ?>">
                                                                                <td style="text-align: center;"><?php echo $c++; ?></td>
                                                                                <td style="text-align: center;"><?php echo $accountname; ?></td>
                                                                                <td style="text-align: center;"><?php echo $accountnumber; ?></td>
                                                                                <td style="text-align: center;"><?php echo $accountatm; ?></td>
                                                                                <td style="text-align: center;"><?php echo $accountsheba; ?></td>
                                                                                <td style="text-align: center;"><?php echo $accountholder; ?></td>
                                                                                <td style="text-align: center;">							
                                                                                    <table>
                                                                                        <tbody>
                                                                                            <tr>
                                                                                                <td>
                                                                                                    <a href="<?php echo URL; ?>admin/account/del/<?php echo $id; ?>" onclick="return conf()">
                                                                                                        <img src="<?php echo URL; ?>template/default/image/delete.gif" title="حذف حساب">
                                                                                                    </a>
                                                                                                </td>
                                                                                            </tr>
                                                                                        </tbody>
                                                                                    </table>
                                                                                </td>
                                                                            </tr>
                                                                            <?php
                                                                        }
																	}
																	?>
																</tbody>
															</table>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php include "adminmenu.php"; ?>
		</div>
	</div>
	<div id="ja-footer" class="wrap">
		<div class="main clearfix">
			<div class="ja-footnav clearfix">
				<ul class="ja-links">
					<li class="top">
						<a href="#Top" title="Back to Top">بالا</a>
					</li>
				</ul>
			</div>
			<div>
				<div align="center">
					<p><?php echo SITE_FOOTER; ?></p>
					﻿<p align ="center"><?php include "copyright.php"; ?></p>
				</div>
			</div>
		</div>
	</div>
</div>
</body></html>
<?php
}
else
{
	header("Location: index.php");	
}
?>
