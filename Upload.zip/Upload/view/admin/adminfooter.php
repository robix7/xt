<?php
require "include/db.php";
$msg='';
if(isset($_SESSION['SUB_ADMIN_ID'])) {



?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fa-ir" lang="fa-ir"><head>
<meta name="Template" content="">
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="robots" content="index, follow">
<meta name="keywords" content="">
<meta name="description" content="">
<title><?php echo SITE_NAME; ?></title>
  
<link href="<?php echo URL;?>template/default/css/template.css" rel="stylesheet" type="text/css">


</head>
<body id="bd" class="fs3 FF">
<div id="ja-wrapper">
<a name="Top" id="Top"></a>
	<div id="ja-container" class="wrap ja-l1r1">
		<div class="main clearfix">
			<div id="ja-mainbody" style="width:80%">
				<div class="ja-box1">
					<div class="ja-box2">
						<div id="ja-main" style="width:100%">
							<div class="inner ja-box-br">
								<div class="ja-box-bl">
									<div class="ja-box-tr">
										<div class="ja-box-tl clearfix">
											<div id="ja-breadcrums">
												<div class="inner clearfix">
													<strong></strong> <span class="breadcrumbs pathway">ویراش پا صفحه</span>
												</div>
											</div>
											<div id="ja-contentwrap" class="">
												<div id="ja-content" class="column" style="width:100%">
													<div id="ja-current-content" class="column" style="width:100%">
														<div class="ja-content-main clearfix">
															<form name="newad" method="post" enctype="multipart/form-data" action="">
																<div>
																	<div style="float:right; text-align:right; width:20%;height:200px;">
																		متن
																	</div>
																	<div style="float:right; text-align:right; width:30%;height:200px;">
																		<textarea name="comment" id="comment" rows="8" cols="54" style="color:#414141;background-color:LightGrey;font-size:12px;"><?php echo $this->footer;?></textarea>
																	</div>
																	<div style="float:right; text-align:right; width:50%;height:200px;">
																	
																	</div>
																</div>
																<div>
																	<div style="float:right; text-align:right; width:20%;height:30px;">

																	</div>
																	<div style="float:right; text-align:right; width:30%;height:30px;">
																		<input class="inputbox" dir="rtl" value="  ویرایش  " name="editfooter" id="aditfooter" style="width: 100px;" type="submit">&nbsp;  
																		<input class="inputbox" dir="rtl" value="  انصراف  " name="cancelfooter" id="cancelfooter" style="width: 100px;" type="button" onclick=window.location='index.php'>&nbsp; 
																	</div>
																	<div style="float:right; text-align:right; width:50%;height:30px;">
																		
																	</div>
																</div>	
															</form>
															<?php echo $this->msg; ?>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php include "adminmenu.php"; ?>
		</div>
	</div>
	<div id="ja-footer" class="wrap">
		<div class="main clearfix">
			<div class="ja-footnav clearfix">
				<ul class="ja-links">
					<li class="top">
						<a href="#Top" title="Back to Top">بالا</a>
					</li>
				</ul>
			</div>
			<div>
				<div align="center">
					<p><?php echo SITE_FOOTER; ?></p>
					﻿<p align ="center"><?php include "copyright.php"; ?></p>
				</div>
			</div>
		</div>
	</div>
</div>
</body></html>
<?php
}
else
{
	header("Location: index.php");
}
?>
