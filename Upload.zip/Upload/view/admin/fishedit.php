<?php
require "include/db.php";
if(isset($_SESSION['SUB_ADMIN_ID'])){
$msg = '';$msg1 = '';$msg10 = '';$msg11 = '';$msg12 = '';$msg13 = '';$name = '';$empty = '';$hasimage = 0;$k10='';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fa-ir" lang="fa-ir"><head>
<meta name="Template" content="">
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="robots" content="index, follow">
<meta name="keywords" content="">
<meta name="description" content="">
<title><?php echo SITE_NAME; ?></title>
  
  
<link href="<?php echo URL;?>template/default/css/template.css" rel="stylesheet" type="text/css">


</head>
<body id="bd" class="fs3 FF">
<div id="ja-wrapper">
	<a name="Top" id="Top"></a>
	<div id="ja-container" class="wrap ja-l1r1">
		<div class="main clearfix">
			<div id="ja-mainbody" style="width:80%">
				<div class="ja-box1">
					<div class="ja-box2">
						<div id="ja-main" style="width:100%">
							<div class="inner ja-box-br">
								<div class="ja-box-bl">
									<div class="ja-box-tr">
										<div class="ja-box-tl clearfix">
											<div id="ja-breadcrums">
												<div class="inner clearfix">
													<strong></strong> <span class="breadcrumbs pathway">آکهی های ویژه</span>
												</div>
											</div>
											<div id="ja-contentwrap" class="">
												<div id="ja-content" class="column" style="width:100%">
													<div id="ja-current-content" class="column" style="width:100%">
														<div class="ja-content-main clearfix">			   
															<form name="newad" method="post" enctype="multipart/form-data" action="">
																<table>
																	<tbody>
																		<tr>
																			<td colspan="4">
																				مبلغ فیش را به ریال وارد نمایید
																			</td>

																		</tr>
																		<tr></tr>
																		<tr>
																			<td>حساب</td>
																			<td>
																				 <select name="account" id="account" style="color:#414141;background-color:LightGrey;font-family:Tahoma;font-size:12px;height:22px;width:175px;">
																					<?php  

																						$result6  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."accounts ");
																						while($show_result6 = $db->sql_fetcharray($result6))
																						{
																							$aname   = $show_result6['accountname'];
																							$anumber = $show_result6['accountnumber'];
																							$aid     = $show_result6['id'];
																							
																							if($aid == $aid1) $s = "selected";
																							echo $t = "<option value='$aid' $s>$aname--&gt;$anumber</option>";
																							$s="";
																						}
																					?>
																				</select>	
																			</td>
																			<td></td>
																			<td></td>
																		<tr>
																		<tr>
																			<td >شماره رسید</td>
																			<td>
																				<input name="resid" id="resid" value="<?php echo $this->resid; ?>" style="border: 1px solid #A6A6A6; font-family:Tahoma; font-size:12px; color:#414141; float:none; width:175px; height:22px; background-color:#D3D3D3; padding-right: 5px; padding-left: 5px;" tabindex="10" type="text">
																			</td>
																			<td></td>
																			<td></td>
																		</tr>
																		<tr>
																			<td >مبلغ</td>
																			<td>
																				<input name="amount" id="amount" value="<?php echo $this->amount; ?>" style="border: 1px solid #A6A6A6; font-family:Tahoma; font-size:12px; color:#414141; float:none; width:175px; height:22px; background-color:#D3D3D3; padding-right: 5px; padding-left: 5px;" tabindex="10" type="text">
																			</td>
																			<td></td>
																			<td></td>
																		</tr>
																		<tr>
																			<?php
																				$ti      = date('Y-m-d',time());
																				$tij     = g_to_j($ti);
																			?>
																			<td >تاریخ</td>
																			<td>
																				<input name="date" id="date" value="<?php echo $this->fdate; ?>" style="border: 1px solid #A6A6A6; font-family:Tahoma; font-size:12px; color:#414141; float:none; width:175px; height:22px; background-color:#D3D3D3; padding-right: 5px; padding-left: 5px;" tabindex="10" type="text">
																			</td>
																			<td></td>
																			<td></td>
																		</tr>
																		<tr>
																			<td >نام پرداخت کننده</td>
																			<td>
																				<input name="sender" id="sender" value="<?php echo $this->sender; ?>" style="border: 1px solid #A6A6A6; font-family:Tahoma; font-size:12px; color:#414141; float:none; width:175px; height:22px; background-color:#D3D3D3; padding-right: 5px; padding-left: 5px;" tabindex="10" type="text">
																			</td>
																			<td></td>
																			<td></td>
																		</tr>
																		<tr>
																			<td>توضیحات</td>
																			<td>
																				<textarea name="comment" id="comment" rows="10" cols="51" style="color:#414141;background-color:LightGrey;font-family:Tahoma;font-size:12px;"><?php echo $this->comment; ?></textarea>
																			</td>
																			<td></td>
																			<td></td>
																		</tr>
																		<tr>
																			<td colspan="4" align="center" width="449" height="26">
																				<br>
																				<input class="inputbox" dir="rtl" value="ویرایش" name="regfish" id="regfish" style="width: 100px;" type="submit">&nbsp;  
																				<input class="inputbox" dir="rtl" value="انصراف" name="canfish" id="canfish" style="width: 100px;" type="button" onclick=window.location='fish.php'>&nbsp;  
																			</td>
																		</tr>
																		<tr>
																			<td colspan="4" align="center" width="449" height="26">
																				<?php
																					echo $this->msg;
																				?>
																				
																			</td>
																		</tr>
																	</tbody>
																</table>	
															</form>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php include "adminmenu.php"; ?>
		</div>
	</div>
	<div id="ja-footer" class="wrap">
		<div class="main clearfix">
			<div class="ja-footnav clearfix">
				<ul class="ja-links">
					<li class="top">
						<a href="#Top" title="Back to Top">بالا</a>
					</li>
				</ul>
			</div>
			<div>
				<div align="center">
					<p><?php echo SITE_FOOTER; ?></p>
					﻿<p align ="center"><?php include "copyright.php"; ?></p>
				</div>
			</div>
		</div>
	</div>
</div>
</body></html>
<?php
}
else
{
	header("Location: index.php");	
}
?>