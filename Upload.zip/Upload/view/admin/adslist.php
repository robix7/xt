<?php
include "include/db.php";
include "include/galery/UberGallery.php";
$gallery = new UberGallery();
if(isset($_SESSION['SUB_ADMIN_ID'])) {
$msg = '';$msg1 = '';$name = '';$c='';$cs = '';$cn = '';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fa-ir" lang="fa-ir"><head>
<meta name="Template" content="">
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="robots" content="index, follow">
<meta name="keywords" content="">
<meta name="description" content="">
<title><?php echo SITE_NAME; ?></title>

  
    <link rel="stylesheet" type="text/css" href="<?php echo URL; ?>template/default/css/template.css">
    <link rel="stylesheet" type="text/css" href="<?php echo URL; ?>template/default/css/galery/style.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo URL; ?>template/default/css/galery/colorbox/<?php echo GALERY_THEMES; ?>/colorbox.css" />
    <script type="text/javascript" src="<?php echo URL; ?>template/default/css/galery/jquery-2.1.0.min.js"></script>
    <script type="text/javascript" src="<?php echo URL; ?>template/default/css/galery/colorbox/jquery.colorbox.js"></script>

<script type="text/javascript">
    $(document).ready(function(){
        $("a[rel='colorbox']").colorbox({maxWidth: "90%", maxHeight: "90%", opacity: ".5"});
    });
</script> 

<script type="text/javascript">
    $(document).ready(function() {
          $('input[type="checkbox"]').ezMark();
          $('input[type="radio"]').ezMark();
          $().piroBox_ext({
          piro_speed : 700,
              bg_alpha : 0.5,
              piro_scroll : true
          });

    });
    $(function(){
        $("#menu ul li:has(ul)").find("span:first").addClass("down");
        $("#menu ul li ul li:has(ul)").find("span:first").removeClass("down");
        $("#menu ul li ul li:has(ul)").find("a:first").addClass("fly");
    });
    $(function(){
      $('#errid').click();
    });
</script>

<script>
    function conf()
    {
        if(confirm("آیا برای حذف این آگهی مطمئن هستید؟"))
        {
        return true;
        }
        else
        {
        return false;
        }
    }
    function conf1()
    {
        if(confirm("آیا برای حذف این عکس مطمئن هستید؟"))
        {
        return true;
        }
        else
        {
        return false;
        }
    }
</script>
</head>

<body id="bd" class="fs3 FF">

<div id="ja-wrapper">
	<a name="Top" id="Top"></a>
	<div id="ja-container" class="wrap ja-l1r1">
		<div class="main clearfix">
			<div id="ja-mainbody" style="width:80%">
				<div class="ja-box1">
					<div class="ja-box2">
						<div id="ja-main" style="width:100%">
							<div class="inner ja-box-br">
								<div class="ja-box-bl">
									<div class="ja-box-tr">
										<div class="ja-box-tl clearfix">
											<div id="ja-breadcrums">
												<div class="inner clearfix">
													<?php
													if($this->userMode == 1)
													{
														?>
														<strong></strong><span class="breadcrumbs pathway">لیست آگهی های <?php echo $this->email; ?></span>
														<?php
													}
													else
													{
														?>
														<strong></strong><span class="breadcrumbs pathway">لیست آگهی ها</span>
														<?php
													}
													?>
												</div>
											</div>
											<div id="ja-contentwrap" class="">
												<div id="ja-content" class="column" style="width:100%">
													<div id="ja-current-content" class="column" style="width:100%">
														<div class="ja-content-main clearfix">
															<form action="" method="post">	
																<table>
																	<tr>
																		<td>
																			<input class="inputbox" dir="rtl" name="word" id="word" style="width:400px;" type="text">
																		</td>
																		<td>
																			<input class="inputbox" dir="rtl" value="جستجو" name="search" id="search" style="width: 100px;" type="submit">
																		</td>
																	</tr>
																</table>
															</form>
															<?php 
																if(isset($_SESSION['MSG'])) echo $_SESSION['MSG'];
																unset($_SESSION['MSG']);
																if($this->userMode == 1 )
																{
																	$cnt_query = $db->sql_query("SELECT COUNT(id) FROM ".TABLE_PREFIX."advertise  WHERE uid = $this->uid  ");
																	$cnt_a     = mysql_fetch_row($cnt_query);
																	$cnt       = $cnt_a[0];
																}
																elseif($this->searchMode == 1)
																{
																	$cnt_query = $db->sql_query("SELECT COUNT(id) FROM  ".TABLE_PREFIX."advertise WHERE subject LIKE '%$this->word%' OR comment LIKE '%$this->word%' ");
																	$cnt_a     = mysql_fetch_row($cnt_query);
																	$cnt       = $cnt_a[0];
																}
																else
																{
																	$cnt_query = $db->sql_query("SELECT COUNT(id) FROM  ".TABLE_PREFIX."advertise ");
																	$cnt_a     = mysql_fetch_row($cnt_query);
																	$cnt       = $cnt_a[0];
																}
																
																$r=0;
                                                                if($this->page == 0) $this->page = 1;
																$ipp = 10;
																if($this->userMode == 1 )
																{
																	$pageconf = array(
																	'all'=>$cnt ,
																	'range'=>$ipp ,
																	'inpage'=>$this->page,
																	'limit'=>5 ,
																	'url'=>URL.'admin/adslist/user/'.$this->uid.'/'
																	);
																}
																elseif($this->searchMode == 1)
																{
																	$pageconf = array(
																	'all'=>$cnt ,
																	'range'=>$ipp ,
																	'inpage'=>$this->page,
																	'limit'=>5 ,
																	'url'=>URL.'admin/adslist/search/'.$this->word.'/'
																	);	
																}
																else
																{
																	$pageconf = array(
																	'all'=>$cnt ,
																	'range'=>$ipp ,
																	'inpage'=>$this->page,
																	'limit'=>5 ,
																	'url'=>URL.'admin/adslist/'
																	);

																}

																$pagenumber = new pagination($pageconf);
																echo $pagenumber->pagenumber();
															?>	
															<table id="table1" class="sortable" style="font: 11px Tahoma; background: #fff; color: #091f30; width: 100%" border="0" cellpadding="0" cellspacing="0">
																<thead>
																	<tr style="height:5px;vertical-align:middle">
																		<th class="tabl">شماره</th>
																		<th class="tabl">تاریخ</th>
																		<th class="tabl">عنوان</th>
																		<th class="tabl">تصویر</th>
																		<th class="tabl">گروه</th>
																		<th class="tabl">نوع</th>
																		<th class="tabl">بازدید</th>
																		<th class="tabl">وضعیت</th>
																		<th class="tabl">ستاره</th>
																		<th class="tabl">هزینه آگهی</th>
																		<th class="tabl">تغییر</th>
																	</tr>
																</thead>
																<tbody>
																	<?php
																	if($this->userMode == 1)
																	{
																		$result  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."advertise WHERE uid = $this->uid ORDER BY `status`,`update` DESC" );
																	}
																	elseif($this->searchMode == 1)
																	{
																		$result  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."advertise WHERE subject LIKE '%$this->word%' OR comment LIKE '%$this->word%' ");
																	}
																	else
																	{
																		$result  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."advertise ORDER BY `status`,`update` DESC" );
																	}
																	while($show_result=$db->sql_fetcharray($result))
																	{
																		$r++;
																		if($r > $this->page*$ipp) break;
																		if($r <= $this->page*$ipp and $r >= $this->page*$ipp-$ipp+1)
																		{
																		
																			$uid     = $show_result['uid'];
																			$update  = $show_result['update'];
																			$subject = trim($show_result['subject']);
																			$comment = $show_result['comment'];
																			$id      = $show_result['id'];
																			$mgid    = $show_result['mgid']; 
																			$sgid    = $show_result['sgid'];   
																			$visit   = $show_result['visit']; 
																			$kind    = $show_result['kind']; 
																			$status  = $show_result['status']; 
																			$star    = $show_result['star']; 
																			$cost    = $show_result['cost'];
																			$keyword = $show_result['keyword'];
																			$hasimage = $show_result['hasimage'];
																			$ti      = date('Y-m-d',$update);
																			$tij     = g_to_j($ti);
																			
																			$email       = $show_result['email'];
																			$image       = $show_result['yahoo'];
																			
																																					
																			$result1 = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."adsmaingroup WHERE mgid = $mgid");
																			$show_result1 = $db->sql_fetcharray($result1);
																			$result2 = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."adssubgroup WHERE sgid = $sgid");
																			$show_result2 = $db->sql_fetcharray($result2);
																			
																			$mgname = $show_result1['mgname']; 
																			$sgname = $show_result2['sgname'];
																			
																			$result3      = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."user WHERE id = $uid");
																			$show_result3 = $db->sql_fetcharray($result3);
																			$email        = $show_result3['email'];
																			
																			
																			if($status == 0) $cs = "منتظر تایید";
																			if($status == 1) $cs = "فعال";
																			if($status == 2) $cs = "منقضی";
                                                                            if($kind == 1) {$cn = "رایگان متنی";}
                                                                            if($kind == 2) {$cn = "رایگان عکس دار";}
                                                                            if($kind == 3) {$cn = "ویژه متنی";}
                                                                            if($kind == 4) {$cn = "ویژه عکس دار";}
																			
																			$col = "#FFFFFF";
																			if($status == 0) 
																			{
																				$col = "#CC9";
																			}
																			$c++;
																			$gacnt = my_count(TABLE_PREFIX.'galery','id','adsid',$id,-1,-1,-1,-1,-1,-1);
																			$rowspan = 4;
																			if($gacnt > 0) $rowspan = 5;
																			?>
																			<tr style="background-color:<?php echo $col; ?>">
																				<td style="text-align:center;" rowspan="<?php echo $rowspan; ?>"><?php echo $id; ?></td>
																				<td style="text-align:center;"><?php echo $tij; ?></td>
																				<td style="text-align:right;"><a href="<?php echo URL; ?>/ads/view/<?php echo $id;?>/<?php echo $subject; ?>" target="_blank"><?php echo $subject; ?></a></td>
																				<?php
                                                                                    if($kind == 2 OR $kind == 4) 
                                                                                    {
                                                                                        ?>
                                                                                        <td style="text-align:center;"><img src="<?php echo URL; ?>images/ads/small/<?php echo $id; ?>.jpg" border="0"></td>
                                                                                        <?php
                                                                                    }
                                                                                    else
                                                                                    {
                                                                                        ?>
                                                                                        <td style="text-align:center;">ندارد</td>
                                                                                        <?php
                                                                                    }
																				?>
																				<td style="text-align:right;"><?php echo $mgname; ?><br><?php echo $sgname; ?></td>
																				<td style="text-align: center;"><?php echo $cn; ?></td>
																				<td style="text-align: center;"><?php echo $visit; ?></td>
																				<td style="text-align: center;"><?php echo $cs; ?></td>
																				<td style="text-align: center;"><?php echo $star; ?></td>
																				<td style="text-align: center;"><?php echo sefr($cost); ?></td>
																				<td style="text-align: center;">
																					<table>
																						<tbody>
																							<tr>
																								<td>
																									<a href="<?php echo URL; ?>admin/insertads/edit/<?php echo $id; ?>">
																										<img src="<?php echo URL; ?>template/default/image/edit.gif" title="ویرایش آگهی">
																									</a>
																								</td>
																								<td>
																									<a href="<?php echo URL; ?>admin/adsdelete/<?php echo $id; ?>" onclick="return conf()">
																										<img src="<?php echo URL; ?>template/default/image/delete.gif" title="حذف آگهی" />
																									</a>
																								</td>
																								<td>
																									<a href="<?php echo URL; ?>admin/adsrefresh/<?php echo $id; ?>">
																										<img src="<?php echo URL; ?>template/default/image/refresh.gif" title="تایید آگهی">
																									</a>	
																								</td>
																							</tr>
																						</tbody>
																					</table>
																				</td>
																				
																			</tr>
																			<tr>
																				<td style="background-color:<?php echo $col; ?>" colspan="1">
																				کاربر
																				</td>
																				<td style="background-color:<?php echo $col; ?>" colspan="10">
																					<a href="<?php echo URL; ?>admin/adslist/user/<?php echo $uid; ?>" target="_blank" title="نمایش آگهی های این کاربر" style="font-family:Tahoma;"><?php echo $email; ?></a>
																				</td>
																			</tr>
																			<tr>
																				<td style="background-color:<?php echo $col; ?>" colspan="1">
																				کلمات کلیدی
																				</td>
																				<td style="background-color:<?php echo $col; ?>" colspan="10">
																					<?php echo $keyword;?>
																				</td>
																			</tr>
																			<tr>
																				<td style="background-color:<?php echo $col; ?>" colspan="1">
																				متن آگهی
																				</td>
																				<td style="background-color:<?php echo $col; ?>" colspan="10">
																					<?php echo strip_tags($comment);?>
																				</td>
																			</tr>
																			<?php
																			$gcnt = my_count(TABLE_PREFIX.'galery','id','adsid',$id,-1,-1,-1,-1,-1,-1);
																			if($gcnt > 0)
																			{
																			?>
																			<tr>
																				<td style="background-color:<?php echo $col; ?>" colspan="1">
																				گالری عکس
																				</td>
																				<td style="background-color:<?php echo $col; ?>" colspan="10">
																					<div id="galleryListWrapper">
																						<ul id="galleryList" class="clearfix">
																							<?php
																							$result10  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."galery WHERE `adsid` = '$id' ORDER BY `date` DESC" );
																							while($show_result10=$db->sql_fetcharray($result10))
																							{
																								$name = $show_result10['name'];
																								$al  = $show_result10['alt'];
																								$gid  = $show_result10['id'];
																								
																								?>
																								<li>
																									<a href="<?php echo URL;?>images/galery/big/<?php echo $name; ?>" title="<?php echo $al; ?>" alt="<?php echo $al; ?>" rel="colorbox">
																										<img src="<?php echo URL;?>images/galery/med/<?php echo $name; ?>" alt="">
																									</a>
																									<br/>
																									<?php echo $al; ?>
																									<br/>
																									<div style="text-align:center;">
																										<a href="?cmd=gdel&id=<?php echo $gid; ?>" onclick="return conf1()">
																											<img src="<?php echo URL;?>template/default/image/delete.gif" title="حذف عکس" />
																										</a>
																									</div>
																								</li>
																								
																								<?php
																							}
																							?>
																						</ul>
																					</div>
																				</td>
																			</tr>
																			<?php
																			}
																			?>
																			<tr>
																				<td style="background-color:#c6d5e1" colspan="12">
																					
																				</td>
																			
																			</tr>
																			<?php
																		}
																	}
																	?>
																</tbody>
															</table>	
															<?php
																echo $pagenumber->pagenumber();
															?>		
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php include "adminmenu.php"; ?>
		</div>
	</div>
	<div id="ja-footer" class="wrap">
		<div class="main clearfix">
			<div class="ja-footnav clearfix">
				<ul class="ja-links">
					<li class="top">
						<a href="#Top" title="Back to Top">بالا</a>
					</li>
				</ul>
			</div>
			<div>
				<div align="center">
					<p><?php echo SITE_FOOTER; ?></p>
					<p align ="center"><?php include "copyright.php"; ?></p>
				</div>
			</div>
		</div>
	</div>
</div>
</body></html>
<?php
}
else
{
    header("Location: index.php");
}
?>