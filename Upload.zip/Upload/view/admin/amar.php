<?php
require "include/db.php";
if(isset($_SESSION['SUB_ADMIN_ID'])){

$msg = '';$msg1 = '';$msg10 = '';$msg11 = '';$msg12 = '';$msg13 = '';$name = '';$empty = '';$hasimage = 0;$r=0;$u='';
$sel01 = "";$sel02 = '';$sel03 = '';$sel04 = '';$sel05 = '';$sel06 = '';$sel07 = '';$sel08 = '';$sel09 = '';$sel10 = '';
$sel11 = '';$sel12 = '';$sel1392='';$sel1393='';$yid='';$ul='';$s='';

//$siteAddress  = Setting::GetSetting(11);
$siteAddress  = URL;

$jt2     = s_to_j(time());
$jt2     = explode("-",$jt2);
$nowy    = $jt2[0];
$nowm    = $jt2[1];

$mintime = my_min(TABLE_PREFIX.'visit','time',-1,-1,-1,-1,-1,-1,-1,-1,-1,-1);
$jt2     = s_to_j($mintime);
$jt2     = explode("-",$jt2);
if($jt2[0] < 1393)
{
	$beginy = 1393;
}
else
{
	$beginy  = $jt2[0];
}

$maxtime = my_max(TABLE_PREFIX.'visit','time',-1,-1,-1,-1,-1,-1,-1,-1,-1,-1);
$jt2     = s_to_j($maxtime);
$jt2     = explode("-",$jt2);

if($jt2[0] < 1393)
{
	$endy    = 1393;
}
else
{
	$endy    = $jt2[0];
}
if($nowm == 1)   $sel01 = "selected";
if($nowm == 2)   $sel02 = "selected";
if($nowm == 3)   $sel03 = "selected";
if($nowm == 4)   $sel04 = "selected";
if($nowm == 5)   $sel05 = "selected";
if($nowm == 6)   $sel06 = "selected";
if($nowm == 7)   $sel07 = "selected";
if($nowm == 8)   $sel08 = "selected";
if($nowm == 9)   $sel09 = "selected";
if($nowm == 10)  $sel10 = "selected";
if($nowm == 11)  $sel11 = "selected";
if($nowm == 12)  $sel12 = "selected";

if(isset($_POST['filter']))
{
    $sel01 = "";$sel02 = "";
    $sel03 = "";$sel04 = "";
    $sel05 = "";$sel06 = "";
    $sel07 = "";$sel08 = "";
    $sel09 = "";$sel10 = "";
    $sel11 = "";$sel12 = "";
    $sel1392 = "";
    $sel1393 = "";
    $fid = $_POST["month"];
    $yid = $_POST["year"];
    if($fid ==  1)  $sel01 = "selected";
    if($fid ==  2)  $sel02 = "selected";
    if($fid ==  3)  $sel03 = "selected";
    if($fid ==  4)  $sel04 = "selected";
    if($fid ==  5)  $sel05 = "selected";
    if($fid ==  6)  $sel06 = "selected";
    if($fid ==  7)  $sel07 = "selected";
    if($fid ==  8)  $sel08 = "selected";
    if($fid ==  9)  $sel09 = "selected";
    if($fid ==  10) $sel10 = "selected";
    if($fid ==  11) $sel11 = "selected";
    if($fid ==  12) $sel12 = "selected";
    
    $ul = 1;
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fa-ir" lang="fa-ir"><head>
<meta name="Template" content="">
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="robots" content="index, follow">
<meta name="keywords" content="">
<meta name="description" content="">
<title><?php echo SITE_NAME; ?></title>
  
<link href="<?php echo URL;?>template/default/css/template.css" rel="stylesheet" type="text/css">

</head>
<body id="bd" class="fs3 FF">
<div id="ja-wrapper">
	<a name="Top" id="Top"></a>
	<div id="ja-container" class="wrap ja-l1r1">
		<div class="main clearfix">
			<div id="ja-mainbody" style="width:80%">
				<div class="ja-box1">
					<div class="ja-box2">
						<div id="ja-main" style="width:100%">
							<div class="inner ja-box-br">
								<div class="ja-box-bl">
									<div class="ja-box-tr">
										<div class="ja-box-tl clearfix">
											<div id="ja-breadcrums">
												<div class="inner clearfix">
													<strong></strong> <span class="breadcrumbs pathway">آمار</span>
												</div>
											</div>
											<div id="ja-contentwrap" class="">
												<div id="ja-content" class="column" style="width:100%">
													<div id="ja-current-content" class="column" style="width:100%">
														<div class="ja-content-main clearfix">
															<form action='' method='post'>
																<select dir="rtl" name="month">
																	<option value='1'   <?php echo $sel01; ?>>فروردین</option>
																	<option value='2'   <?php echo $sel02; ?>>اردیبهشت</option>
																	<option value='3'   <?php echo $sel03; ?>>خرداد</option>
																	<option value='4'   <?php echo $sel04; ?>>تیر</option>
																	<option value='5'   <?php echo $sel05; ?>>مرداد</option>
																	<option value='6'   <?php echo $sel06; ?>>شهریور</option>
																	<option value='7'   <?php echo $sel07; ?>>مهر</option>
																	<option value='8'   <?php echo $sel08; ?>>آبان</option>
																	<option value='9'   <?php echo $sel09; ?>>آذر</option>
																	<option value='10'  <?php echo $sel10; ?>>دی</option>
																	<option value='11'  <?php echo $sel11; ?>>بهمن</option>
																	<option value='12'  <?php echo $sel12; ?>>اسفند</option>
																</select>
																<select dir="rtl" name="year">
																	<?php 
                                                                        for($i=$beginy; $i<=$endy; $i++)
                                                                        {
                                                                            if($ul == 1)
                                                                            {
                                                                                if($i == $yid)  $s = 'selected';     
                                                                            }
                                                                            else
                                                                            {
                                                                                if($i == $nowy) $s = 'selected';
                                                                            }
                                                                            ?>
                                                                            <option value='<?php echo $i; ?>' <?php echo $s; ?>><?php echo $i; ?></option>
                                                                            <?php
                                                                            $s='';  
                                                                        }
                                                                        ?>
																</select>
																<input class="inputbox" dir="rtl" value="فیلتر" name="filter" id="filter" style="width: 100px;" type="submit">
															</form>
														</div>
														<div class="ja-content-main clearfix">
															<table id="table1" class="sortable" style="font: 11px Tahoma; background: #fff; color: #091f30; width: 100%" border="0" cellpadding="0" cellspacing="0">
																<thead>
																	<tr style="height:5px;vertical-align:middle">
																		<th class="tabl">
																			ردیف
																		</th>
																		<th class="tabl">
																			سایت
																		</th>
																		<th class="tabl">
																			فروردین
																		</th>
																		<th class="tabl">
																			اردیبهشت
																		</th>
																		<th class="tabl">
																			خرداد
																		</th>
																		<th class="tabl">
																			تیر
																		</th>
																		<th class="tabl">
																			مرداد
																		</th>
																		<th class="tabl">
																			شهریور
																		</th>
																		<th class="tabl">
																			مهر
																		</th>
																		<th class="tabl">
																			آبان
																		</th>
																		<th class="tabl">
																			آذر
																		</th>
																		<th class="tabl">
																			دی
																		</th>
																		<th class="tabl">
																			بهمن
																		</th>
																		<th class="tabl">
																			اسفند
																		</th>

																	</tr>
																</thead>
																<tbody>
																
																	<?php							
																		
																		$result  = $db->sql_query(" SELECT * FROM ".TABLE_PREFIX."visit WHERE status = 0 ");
																		$mmm = 0;
																		while($show_result = $db->sql_fetcharray($result))
																		{
																			$mmm++;
																			$id   = $show_result['id'];
																			$ref  = $show_result['ref'];
																			$time = $show_result['time'];
																			$u++;
																			if($ref == -1 or $ref == NULL)
																			{
																				$domain = $siteAddress;
																			}
																			else
																			{
																				if(strstr($ref,'http://'))
                                                                                {
                                                                                    $website  = explode("/",$ref);
                                                                                    if(strstr($website[2],'.'))
                                                                                    {
                                                                                        $website2 = explode(".",$website[2]);
                                                                                        $co = count($website2);  
                                                                                    }
                                                                                    else
                                                                                    {
                                                                                        $co = 0;
                                                                                    }
                                                                                }
                                                                                else
                                                                                {
                                                                                    $co = 0;
                                                                                } 
                                                                                if($co > 1)
                                                                                {
																				    $domain_name = $website2[$co-2];
																				    $domain_kind = $website2[$co-1];
                                                                                    
                                                                                    $dom = substr($domain_kind,strlen($domain_kind)-1,1);
                                                                                    
                                                                                    if($dom >=1)
                                                                                    {
																				        $domain = '';   
                                                                                    }
                                                                                    else
                                                                                    {
                                                                                        $dname = $domain_name.".".$domain_kind;
                                                                                        
                                                                                        if($dname == "co.uk" OR $dname == "me.uk" OR $dname == "org.uk" OR $dname == "ac.ir" OR $dname == "co.ir" OR $dname == "gov.ir" OR $dname == "id.ir" OR $dname == "net.ir" OR $dname == "org.ir" OR $dname == "sch.ir" )
                                                                                        {
                                                                                            $domain_name = $website2[$co-3];
                                                                                            $domain_kind = $dname;
                                                                                        }                                            
                                                                                        $domain = $domain_name.".".$domain_kind;    
                                                                                    }
                                                                                }
                                                                                else
                                                                                {
                                                                                    $domain ='';   
                                                                                }
																			}
																			
																			
																			$jt = s_to_j($time);
																			$jt = explode("-",$jt);
																			$j_y = $jt[0];
																			$j_m = $jt[1];
																			$j_d = $jt[2];
																			
																			$cnt_query = $db->sql_query("SELECT COUNT(id) FROM ".TABLE_PREFIX."refsite WHERE website = '$domain' AND year = '$j_y' AND month = '$j_m' ");
																			$cnt_a     = mysql_fetch_row($cnt_query);
																			$cntdomain = $cnt_a[0];
																			
																			if($cntdomain > 0)
																			{
																				$rowdomain      = $db->sql_query(" SELECT * FROM ".TABLE_PREFIX."refsite WHERE website = '$domain' AND year = '$j_y' AND month = '$j_m' ");
																				$show_rowdomain = $db->sql_fetcharray($rowdomain);
																				$id_domain = $show_rowdomain['id'];
																				$visit     = $show_rowdomain['visit'] + 1;
																				
																				if($db->sql_query("UPDATE ".TABLE_PREFIX."refsite SET visit = $visit WHERE id = '$id_domain' "))
																				{
																					$db->sql_query("UPDATE ".TABLE_PREFIX."visit SET status = 1 WHERE id = $id ");
																				}
																			}
																			else
																			{
																				if(strlen($domain) > 5 )
																				{
																					if($db->sql_query("INSERT INTO ".TABLE_PREFIX."refsite VALUES (NULL, '$domain', '$j_y', '$j_m', '1')"))
																					{
																						$db->sql_query("UPDATE ".TABLE_PREFIX."visit SET status = 1 WHERE id = $id ");
																					}
																				}
                                                                                $db->sql_query("UPDATE ".TABLE_PREFIX."visit SET status = 1 WHERE id = $id "); 
																			}
																		}

																		    echo "Updated Records=".$mmm;
																			$r = 0;
																			$result  = $db->sql_query(" SELECT * FROM ".TABLE_PREFIX."refsite WHERE year = '$yid' ORDER BY website DESC");
																			while($row=$db->sql_fetcharray($result))
																			{                                        
																				
																				$domain1 = $row['website'];
																				if($domain1 == $dom)
																				{
																					$domain[$r] = $row['website'];
																					$dom = $row['website'];
																					
																					if($row['month']==1) $visit_1[$r]  = $row['visit'];
																					if($row['month']==2) $visit_2[$r]  = $row['visit'];
																					if($row['month']==3) $visit_3[$r]  = $row['visit'];
																					if($row['month']==4) $visit_4[$r]  = $row['visit'];
																					if($row['month']==5) $visit_5[$r]  = $row['visit'];
																					if($row['month']==6) $visit_6[$r]  = $row['visit'];
																					if($row['month']==7) $visit_7[$r]  = $row['visit'];
																					if($row['month']==8) $visit_8[$r]  = $row['visit'];
																					if($row['month']==9) $visit_9[$r]  = $row['visit'];
																					if($row['month']==10) $visit_10[$r]  = $row['visit'];
																					if($row['month']==11) $visit_11[$r]  = $row['visit'];
																					if($row['month']==12) $visit_12[$r]  = $row['visit'];
																				}
																				else
																				{
																					$r++;
																					$domain[$r] = $row['website'];
																					$dom = $row['website'];
																					if($row['month']==1) $visit_1[$r]  = $row['visit'];
																					if($row['month']==2) $visit_2[$r]  = $row['visit'];
																					if($row['month']==3) $visit_3[$r]  = $row['visit'];
																					if($row['month']==4) $visit_4[$r]  = $row['visit'];
																					if($row['month']==5) $visit_5[$r]  = $row['visit'];
																					if($row['month']==6) $visit_6[$r]  = $row['visit'];
																					if($row['month']==7) $visit_7[$r]  = $row['visit'];
																					if($row['month']==8) $visit_8[$r]  = $row['visit'];
																					if($row['month']==9) $visit_9[$r]  = $row['visit'];
																					if($row['month']==10) $visit_10[$r]  = $row['visit'];
																					if($row['month']==11) $visit_11[$r]  = $row['visit'];
																					if($row['month']==12) $visit_12[$r]  = $row['visit'];
																				}
																					
																			}
																			$gt1 = date('Y/m/d',time());
																			$gt1 = explode("/",$gt1);                                            
																			$jt1 = gregorian_to_jalali1 ($gt1[0], $gt1[1], $gt1[2]);
																			$jt1 = explode("-",$jt1);
																			$j1_y = $jt1[0];
																			$j1_m = $jt1[1];
																			$j1_d = $jt1[2];
																			if($ul != 1) $fid  = $j1_m;								
																			for($i2 = 1; $i2 <= $r ; $i2++)
																			{
																				$temp = $i2;
																				for($j2 = $i2+1; $j2 <= $r; $j2++)
																				{
																					if($fid == 1)  { if($visit_1[$temp]  < $visit_1[$j2])  $temp = $j2;}
																					if($fid == 2)  { if($visit_2[$temp]  < $visit_2[$j2])  $temp = $j2;}
																					if($fid == 3)  { if($visit_3[$temp]  < $visit_3[$j2])  $temp = $j2;}
																					if($fid == 4)  { if($visit_4[$temp]  < $visit_4[$j2])  $temp = $j2;}
																					if($fid == 5)  { if($visit_5[$temp]  < $visit_5[$j2])  $temp = $j2;}
																					if($fid == 6)  { if($visit_6[$temp]  < $visit_6[$j2])  $temp = $j2;}
																					if($fid == 7)  { if($visit_7[$temp]  < $visit_7[$j2])  $temp = $j2;}
																					if($fid == 8)  { if($visit_8[$temp]  < $visit_8[$j2])  $temp = $j2;}
																					if($fid == 9)  { if($visit_9[$temp]  < $visit_9[$j2])  $temp = $j2;}
																					if($fid == 10) { if($visit_10[$temp] < $visit_10[$j2]) $temp = $j2;}
																					if($fid == 11) { if($visit_11[$temp] < $visit_11[$j2]) $temp = $j2;}
																					if($fid == 12) { if($visit_12[$temp] < $visit_12[$j2]) $temp = $j2;}
																				}

																				$mytemp = $domain[$i2];
																				$domain[$i2] = $domain[$temp];
																				$domain[$temp] = $mytemp;
																				
																				$mytemp = $visit_1[$i2];
																				$visit_1[$i2] = $visit_1[$temp];
																				$visit_1[$temp] = $mytemp;
																				
																				$mytemp = $visit_2[$i2];
																				$visit_2[$i2] = $visit_2[$temp];
																				$visit_2[$temp] = $mytemp;
																				
																				$mytemp = $visit_3[$i2];
																				$visit_3[$i2] = $visit_3[$temp];
																				$visit_3[$temp] = $mytemp;
																				
																				$mytemp = $visit_4[$i2];
																				$visit_4[$i2] = $visit_4[$temp];
																				$visit_4[$temp] = $mytemp;
																				
																				$mytemp = $visit_5[$i2];
																				$visit_5[$i2] = $visit_5[$temp];
																				$visit_5[$temp] = $mytemp;
																				
																				$mytemp = $visit_6[$i2];
																				$visit_6[$i2] = $visit_6[$temp];
																				$visit_6[$temp] = $mytemp;
																				
																				$mytemp = $visit_7[$i2];
																				$visit_7[$i2] = $visit_7[$temp];
																				$visit_7[$temp] = $mytemp;
																				
																				$mytemp = $visit_8[$i2];
																				$visit_8[$i2] = $visit_8[$temp];
																				$visit_8[$temp] = $mytemp;
																				
																				$mytemp = $visit_9[$i2];
																				$visit_9[$i2] = $visit_9[$temp];
																				$visit_9[$temp] = $mytemp;
																				
																				$mytemp = $visit_10[$i2];
																				$visit_10[$i2] = $visit_10[$temp];
																				$visit_10[$temp] = $mytemp;
																				
																				$mytemp = $visit_11[$i2];
																				$visit_11[$i2] = $visit_11[$temp];
																				$visit_11[$temp] = $mytemp;
																				
																				$mytemp = $visit_12[$i2];
																				$visit_12[$i2] = $visit_12[$temp];
																				$visit_12[$temp] = $mytemp;
																			}
																			for($k = 1;$k<=$r;$k++)
																			{
																		?>
																			<tr>
																				 <td align="center">
																					<?php echo $k; ?>
																				</td>
																				 <td align="center">
																					<?php echo $domain[$k]; ?>
																				</td>
																				<td align="center">
																					<?php echo $visit_1[$k]; ?>
																				</td>
																				 <td align="center">
																					<?php echo $visit_2[$k]; ?>
																				</td>
																				<td align="center">
																					 <?php echo $visit_3[$k]; ?>
																				</td>
																				<td align="center">
																					 <?php echo $visit_4[$k]; ?>
																				</td>
																				<td align="center">
																					 <?php echo $visit_5[$k]; ?>
																				</td>
																				<td align="center">
																					 <?php echo $visit_6[$k]; ?>
																				</td>
																				<td align="center">
																					 <?php echo $visit_7[$k]; ?>
																				</td>
																				<td align="center">
																					 <?php echo $visit_8[$k]; ?>
																				</td>
																				<td align="center">
																					 <?php echo $visit_9[$k]; ?>
																				</td>
																				<td align="center">
																					 <?php echo $visit_10[$k]; ?>
																				</td>
																				<td align="center">
																					 <?php echo $visit_11[$k]; ?>
																				</td>
																				<td align="center">
																					 <?php echo $visit_12[$k]; ?>
																				</td>
																				
																			</tr>
																		<?php
																	}
																	?>
																</tbody>
															</table>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php include "adminmenu.php"; ?>
		</div>
	</div>
	<div id="ja-footer" class="wrap">
		<div class="main clearfix">
			<div class="ja-footnav clearfix">
				<ul class="ja-links">
					<li class="top">
						<a href="#Top" title="Back to Top">بالا</a>
					</li>
				</ul>
			</div>

			<div>
				<div align="center">
					<p><?php echo SITE_FOOTER; ?></p>
					﻿<p align ="center"><?php include "copyright.php"; ?></p>
				</div>
			</div>
		</div>
	</div>
</div>

</body></html>
<?php
}
else
{
	header("Location: index.php");	
}
?>
