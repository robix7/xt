<?php
require "include/db.php";
if(isset($_SESSION['SUB_ADMIN_ID'])) {
if(isset($_GET['url']))
{
    $url = $_GET['url'];
    $url = trim($url,'/');
    $url = explode('/', $url);
    if(count($url)>3) $mid = $url[3];
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fa-ir" lang="fa-ir"><head>
<meta name="Template" content="" />
<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<meta name="robots" content="index, follow" />
<meta name="keywords" content="" />
<meta name="description" content="" />
<title><?php echo SITE_NAME; ?></title>
  
<link href="<?php echo URL;?>template/default/css/template.css" rel="stylesheet" type="text/css">

<script>
function conf(kind,name,file,content,link)
{
	var li = link.split('/');
	var http = li[0];
	var mkind = 0;
	var mcontent = 0;
	if(kind == 1 && file == '') mkind =1;
	if(kind == 2 && content == -1) mcontent = 1;
	if(kind == 3 && link == '') mcontent = 1;
	if(mkind == 1 || name == '' || mcontent == 1)
	{
		alert("اطلاعات را کامل وارد نمایید");
		return false;
	}
	else if(http != 'http:' && kind == 4)
	{
		alert("لینک خارجی باید با http:// وارد شود");
		return false;
	}
	else
	{
		if(confirm("آیا برای ثبت این منو مطمئن هستید؟"))
		{
		return true;
		}
		else
		{
		return false;
		}
	}
}
function chkind(kind)
{
	if(kind == 1)  // menufile
	{
		document.getElementById('menufile').disabled = false;
		document.getElementById('menucontent').disabled = true;
		document.getElementById('menulink').disabled = true;
		
		document.getElementById('menufile').style.backgroundColor = "#D3D3D3";
		document.getElementById('menucontent').style.backgroundColor = "#919191";
		document.getElementById('menulink').style.backgroundColor = "#919191";
	}
	if(kind == 2) // menucontent
	{
		document.getElementById('menucontent').disabled = false;
		document.getElementById('menufile').disabled = true;
		document.getElementById('menulink').disabled = true;
		
		document.getElementById('menucontent').style.backgroundColor = "#D3D3D3";
		document.getElementById('menufile').style.backgroundColor = "#919191";
		document.getElementById('menulink').style.backgroundColor = "#919191";
	}
	if(kind == 3) // menulink
	{
		document.getElementById('menulink').disabled = false;
		document.getElementById('menufile').disabled = true;
		document.getElementById('menucontent').disabled = true;
		
		document.getElementById('menulink').style.backgroundColor = "#D3D3D3";
		document.getElementById('menufile').style.backgroundColor = "#919191";
		document.getElementById('menucontent').style.backgroundColor = "#919191";
	}
	if(kind == 4) // external link
	{
		document.getElementById('menulink').disabled = false;
		document.getElementById('menufile').disabled = true;
		document.getElementById('menucontent').disabled = true;
		
		document.getElementById('menulink').style.backgroundColor = "#D3D3D3";
		document.getElementById('menufile').style.backgroundColor = "#919191";
		document.getElementById('menucontent').style.backgroundColor = "#919191";
	}

}
function confi()
{
	if(confirm("آیا برای حذف مطمئن هستید؟"))
	{
		return true;
	}
	else
	{
		return false;
	}
}

</script>
</head>
<body id="bd" class="fs3 FF">
<div id="ja-wrapper">
	<a name="Top" id="Top"></a>
	<div id="ja-container" class="wrap ja-l1r1">
		<div class="main clearfix">
			<div id="ja-mainbody" style="width:80%">
				<div class="ja-box1">
					<div class="ja-box2">
						<div id="ja-main" style="width:100%">
							<div class="inner ja-box-br">
								<div class="ja-box-bl">
									<div class="ja-box-tr">
										<div class="ja-box-tl clearfix">
											<div id="ja-breadcrums">
												<div class="inner clearfix">
													<strong></strong> <span class="breadcrumbs pathway">ایجاد و ویرایش فهرست</span>
												</div>
											</div>
											<div id="ja-contentwrap" class="">
												<div id="ja-content" class="column" style="width:100%">
													<div id="ja-current-content" class="column" style="width:100%">
														<div class="ja-content-main clearfix">
					
															<form name="newad" method="post" enctype="multipart/form-data" action="">
																<div>
																	<div style="float:right; text-align:right; width:20%;height:30px;">
																		نام فهرست
																	</div>
																	<div style="float:right; text-align:right; width:30%;height:30px;">
																		<input name="menuname" id="menuname" value="<?php echo $this->menuname; ?>" class="inp1" type="text">
																	</div>
																	<div style="float:right; text-align:right; width:50%;height:30px;">
																	
																	</div>
																</div>
																<div>
																	<div style="float:right; text-align:right; width:20%;height:30px;">
																		نوع فهرست
																	</div>
																	<div style="float:right; text-align:right; width:30%;height:30px;">
																		<?php
																			if($this->editMode == 1)
																			{
																				?>
																				<select name="menukind" id="menukind" class="inp2" onChange="chkind(this.value)">
																					<?php if($this->menukind == 1) { ?><option value='1' selected>فایل PHP</option><option value='2'>محتوا</option><option value='3'>لینک</option><option value='4'>لینک خارجی</option><?php }?>
																					<?php if($this->menukind == 2) { ?><option value='1'>فایل PHP</option><option value='2' selected>محتوا</option><option value='3'>لینک</option><option value='4'>لینک خارجی</option><?php }?>
																					<?php if($this->menukind == 3) { ?><option value='1'>فایل PHP</option><option value='2'>محتوا</option><option value='3' selected>لینک</option><option value='4'>لینک خارجی</option><?php }?>
																					<?php if($this->menukind == 4) { ?><option value='1'>فایل PHP</option><option value='2'>محتوا</option><option value='3'>لینک</option><option value='4' selected>لینک خارجی</option><?php }?>
																				</select>
																				<?php
																			}
																			else
																			{
																				?>
																				<select name="menukind" id="menukind" class="inp2" onChange="chkind(this.value)">
																					<option value='1'>فایل PHP</option>
																					<option value='2'>محتوا</option>
																					<option value='3'>لینک</option>
																					<option value='4'>لینک خارجی</option>
																				</select>
																				<?php
																			}
																		?>
																	</div>
																	<div style="float:right; text-align:right; width:50%;height:30px;">
																	
																	</div>
																</div>
																<div>
																	<div style="float:right; text-align:right; width:20%;height:30px;">
																		فایل PHP
																	</div>
																	<div style="float:right; text-align:right; width:30%;height:30px;">
																		<?php
																			if($this->editMode == 1)
																			{
																				$len = count($this->phpfile);
																				if($this->menukind == 1)
																				{
																					?>
																					<select name="menufile" id="menufile" class="inp2" style="font-family:tahoma;" onChange="chkind(this.value)">
																						<?php
																							for($i=1; $i<=$len;$i++)
																							{
																								if($this->menufile == $this->phpfile[$i])
																								{
																									?>
																									<option value='<?php echo $this->phpfile[$i]; ?>' selected ><?php echo $this->phpfile[$i]; ?></option>
																									<?php
																								}
																								else
																								{
																									?>
																									<option value='<?php echo $this->phpfile[$i]; ?>' ><?php echo $this->phpfile[$i]; ?></option>
																									<?php
																								
																								}
																							}
																						?>
																					</select>
																					<?php
																				}
																				else
																				{
																					?>
																					<select name="menufile" id="menufile" disabled class="inp2dis " style="font-family:tahoma;" onChange="chkind(this.value)">
																							<?php
																							for($i=1; $i<=$len;$i++)
																							{
																								if($this->menufile == $this->phpfile[$i])
																								{
																									?>
																									<option value='<?php echo $this->phpfile[$i]; ?>' selected ><?php echo $this->phpfile[$i]; ?></option>
																									<?php
																								}
																								else
																								{
																									?>
																									<option value='<?php echo $this->phpfile[$i]; ?>' ><?php echo $this->phpfile[$i]; ?></option>
																									<?php
																								
																								}
																							}
																							?>
																					</select>
																					<?php
																				}
																			}
																			else
																			{
																				$len = count($this->phpfile);
																				?>
																				<select name="menufile" id="menufile" class="inp2" style="font-family:tahoma;" onChange="chkind(this.value)">
																					<?php
																						for($i=1; $i<=$len;$i++)
																						{
																							?>
																							<option value='<?php echo $this->phpfile[$i]; ?>'><?php echo $this->phpfile[$i]; ?></option>
																							<?php
																						}
																						?>
																				</select>
																				<?php
																			}
																			?>
																	</div>
																	<div style="float:right; text-align:right; width:50%;height:30px;">
																	
																	</div>
																</div>
																<div>
																	<div style="float:right; text-align:right; width:20%;height:30px;">
																		انتخاب محتوا
																	</div>
																	<div style="float:right; text-align:right; width:30%;height:30px;">
																		<?php 
																		if($this->editMode == 1 and $this->menukind == 2)
																		{
																			?>
																			<select name="menucontent" id="menucontent" class="inp2">
																				<option value='-1'>-</option>
																				<?php  
																				$result  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."content ");
																				while($show_result = $db->sql_fetcharray($result))
																				{
																					$id        = $show_result['id'];
																					$name      = $show_result['name'];
																					if($id == $this->menufile) $s='selected';
																					echo $t = "<option value='$id' $s>$name</option>";
																					$s='';
																					
																				}
																				?>
																			</select>
																			<?php
																		}
																		else
																		{
																			?>
																			<select name="menucontent" id="menucontent" disabled class="inp2dis">
																				<option value='-1'>-</option>
																				<?php  
																				$result  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."content ");
																				while($show_result = $db->sql_fetcharray($result))
																				{
																					$id        = $show_result['id'];
																					$name      = $show_result['name'];
																					echo $t = "<option value='$id'>$name</option>";
																					
																				}
																				?>
																			</select>
																			<?php
																		}
																		?>
																	</div>
																	<div style="float:right; text-align:right; width:50%;height:30px;">
																	
																	</div>
																</div>
																<div>
																	<div style="float:right; text-align:right; width:20%;height:30px;">
																		لینک
																	</div>
																	<div style="float:right; text-align:right; width:30%;height:30px;">
																		<?php 
																			if($this->editMode == 1 & ($this->menukind == 3 OR $this->menukind == 4 ))
																			{
																				?>
																				
																				<input name="menulink" id="menulink" value="<?php echo $this->menulink; ?>" class="inp1" style="font-family:Tahoma" type="text">
																				<?php
																			}
																			else
																			{
																				?>
																				<input name="menulink" id="menulink"  disabled class="inp1dis" type="text">
																				<?php
																			}
																			?>
																	</div>
																	<div style="float:right; text-align:right; width:50%;height:30px;">
																	
																	</div>
																</div>
																<div>
																	<div style="float:right; text-align:right; width:20%;height:30px;">
																		موقعیت
																	</div>
																	<div style="float:right; text-align:right; width:30%;height:30px;">
																		<?php
																			if($this->editMode == 1)
																			{
																				?>
																				<select name="menuposition" id="menuposition" class="inp2">
																					<?php if($this->menupos == 1) { ?><option value='1' selected>بالا</option><option value='2'>راست</option><option value='3'>پایین</option><?php }?>
																					<?php if($this->menupos == 2) { ?><option value='1'>بالا</option><option value='2' selected>راست</option><option value='3'>پایین</option><?php }?>
																					<?php if($this->menupos == 3) { ?><option value='1'>بالا</option><option value='2' selected>راست</option><option value='3' selected>پایین</option><?php }?>
																				</select>
																				<?php
																			}
																			else
																			{
																				?>
																				<select name="menuposition" id="menuposition" class="inp2">
																					<option value='1'>بالا</option>
																					<option value='2'>راست</option>
																					<option value='3'>پایین</option>
																				</select>
																				<?php
																			}
																			?>
																	</div>
																	<div style="float:right; text-align:right; width:50%;height:30px;">
																	
																	</div>
																</div>
																<div>
																	<div style="float:right; text-align:right; width:20%;height:30px;">
																		وضعیت
																	</div>
																	<div style="float:right; text-align:right; width:30%;height:30px;">
																		<?php
																			if($this->editMode == 1)
																			{
																				?>
																				<select name="menustatus" id="menustatus" class="inp2">
																					<?php if($this->menustatus == 0) { ?><option value='0' selected>غیرفعال</option><option value='1'>فعال</option><?php }?>
																					<?php if($this->menustatus == 1) { ?><option value='0'>غیرفعال</option><option value='1' selected>فعال</option><?php }?>
																				</select>
																				<?php
																			}
																			else
																			{
																				?>
																				<select name="menustatus" id="menustatus" value="<?php echo $accountstatus; ?>" class="inp2">
																					<option selected="selected" value="0">غیرفعال</option>
																					<option value="1">فعال</option>
																				</select>
																				<?php
																			}
																		?>
																	</div>
																	<div style="float:right; text-align:right; width:50%;height:30px;">
																	
																	</div>
																</div>
																<div>
																	<div style="float:right; text-align:right; width:20%;height:30px;">

																	</div>
																	<div style="float:right; text-align:right; width:30%;height:30px;">
																		<?php
																			if($this->editMode == 1)
																			{
																				?>
																				<input value="<?php echo $mid; ?>" name="id" id="id" type="hidden" />  
                                                                                <input class="inputbox" dir="rtl" value="  ویرایش  " name="menuedit" id="menuedit" style="width: 100px;" type="submit" onclick="return conf(menukind.value,menuname.value,menufile.value,menucontent.value,menulink.value)" />  
																				<?php
																			}
																			else
																			{
																				?>
																				<input class="inputbox" dir="rtl" value="  افزودن  " name="menuadd" id="menuedit" style="width: 100px;" type="submit"  onclick="return conf(menukind.value,menuname.value,menufile.value,menucontent.value,menulink.value)">&nbsp;  
																				<?php
																			}
																			?>
																		<input class="inputbox" dir="rtl" value="  انصراف  " name="canads" id="canads" style="width: 100px;" type="button" onclick=window.location='index.php'>&nbsp; 
																	</div>
																	<div style="float:right; text-align:right; width:50%;height:30px;">
																		
																	</div>
																</div>
                                                                <div>
																	<div style="float:right; text-align:right; width:20%;height:30px;">

																	</div>
																	<div style="float:right; text-align:right; width:30%;height:30px;">
																		<?php echo $this->msg; ?>
																	</div>
																	<div style="float:right; text-align:right; width:50%;height:30px;">
																		
																	</div>
																</div>	
															</form>
															<table id="table1" class="sortable" style="font: 11px Tahoma; background: #fff; color: #091f30; width: 100%" border="0" cellpadding="0" cellspacing="0">
																<thead>
																	<tr style="height:5px;vertical-align:middle">
																		<th class="tabl">
																			ردیف
																		</th>
																		<th class="tabl">
																			نام
																		</th>
																		<th class="tabl">
																			فایل
																		</th>
																		<th class="tabl">
																			نوع
																		</th>
																		<th class="tabl">
																			موقعیت
																		</th>
																		<th class="tabl">
																			ترتیب
																		</th>
																		<th class="tabl">
																			وضعیت
																		</th>
																		<th class="tabl">
																			عملیات
																		</th>
																	</tr>
																</thead>
																<tbody>
																	<?php
																	$cntm = my_count(TABLE_PREFIX.'menu','id',-1,-1,-1,-1,-1,-1,-1,-1);
																	$i=0;
																	$result  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."menu ORDER BY pos,ordering " );
																	while($show_result = $db->sql_fetcharray($result))
																	{
																		$i++;
																		$id       = $show_result['id'];
																		$name     = $show_result['name'];
																		$file     = $show_result['file'];
																		$kind     = $show_result['kind'];
																		$ordering = $show_result['ordering'];
																		$status   = $show_result['status'];
																		$pos      = $show_result['pos'];
																		$max      = my_max(TABLE_PREFIX.'menu','ordering','pos',$pos,-1,-1,-1,-1,-1,-1);
																		$min      = my_min(TABLE_PREFIX.'menu','ordering','pos',$pos,-1,-1,-1,-1,-1,-1);
																		
																		
																		if($pos == 1) $ps = 'بالا';
																		if($pos == 2) $ps = 'راست';
																		if($pos == 3) $ps = 'پایین';
																		
																		if($kind == 2)
																		{
																			$result1      = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."content WHERE id = $file " );
																			$show_result1 = $db->sql_fetcharray($result1);
																			$file = $show_result1['name'];
																		}
																		
																		
																		if($kind == 1) $kindname = "فایل PHP";
																		if($kind == 2) {$kindname = "محنوا";}
																		if($kind == 3) {$kindname = "لینک";}
																		if($kind == 4) {$kindname = "لینک خارجی";}

																		if(get_lang($file)== 1) $lang = "Tahoma";
																		if(get_lang($file)== 2) $lang = NULL;
																		
																		if($status == 0) 
																		{
																			$col = "#CC9";
																			$st = "غیر فعال";
																		}
																		else
																		{
																			$col = "#FFFFFF";
																			$st = "فعال";
																		}
																		?>
																		<tr style="background-color:<?php echo $col; ?>">
																			<td style="text-align: center;"><?php echo $i; ?></td>
																			<td style="text-align: center;"><?php echo $name; ?></td>
																			<td style="text-align: center;font-family:<?php echo $lang; ?>;"><?php echo $file; ?></td>
																			<td style="text-align: center;"><?php echo $kindname; ?></td>
																			<td style="text-align: center;"><?php echo $ps; ?></td>
																			<td style="text-align: center;"><?php echo $ordering; ?></td>
																			<td style="text-align: center;"><?php echo $st; ?></td>
																			<td style="text-align: center;">							
																				<table>
																					<tbody>
																						<tr>
																							<td>
																								<a href="<?php echo URL; ?>admin/menu/edit/<?php echo $id; ?>">
																									<img src="<?php echo URL; ?>template/default/image/edit.gif" title="ویرایش فهرست" />
																								</a>
																							</td>
																							<td>
																								<a href="<?php echo URL; ?>admin/menu/delete/<?php echo $id; ?>">
																									<img src="<?php echo URL; ?>template/default/image/delete.gif" title="حذف فهرست" onclick="return confi()" />
																								</a>
																							</td>
																							<?php
																							if($ordering != $min)
																							{
																								?>
																								<td>
																									<a href="<?php echo URL; ?>admin/menu/up/<?php echo $id; ?>">
																										<img src="<?php echo URL; ?>template/default/image/up.png" title="تغییر مکان به سمت بالا" />
																									</a>
																								</td>
																								<?php
																							}
																							if($ordering != $max)
																							{
																								?>
																								<td>
																									<a href="<?php echo URL; ?>admin/menu/dn/<?php echo $id; ?>">
																										<img src="<?php echo URL; ?>template/default/image/dn.png" title="تغییر مکان به سمت پایین" />
																									</a>
																								</td>
																								<?php
																							}
																							?>
																						</tr>
																					</tbody>
																				</table>
																			</td>
																		</tr>
																		<?php
																	}
																	?>
																</tbody>
															</table>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php include "adminmenu.php"; ?>
		</div>
	</div>
	<div id="ja-footer" class="wrap">
		<div class="main clearfix">
			<div class="ja-footnav clearfix">
				<ul class="ja-links">
					<li class="top">
						<a href="#Top" title="Back to Top">بالا</a>
					</li>
				</ul>
			</div>
			<div>
				<div align="center">
					<p><?php echo SITE_FOOTER; ?></p>
					﻿<p align ="center"><?php include "copyright.php"; ?></p>
				</div>
			</div>
		</div>
	</div>
</div>
</body></html>
<?php
}
else
{
	header("Location: index.php");	
}
?>
