<?php
require "include/db.php";
if(isset($_SESSION['SUB_ADMIN_ID'])) {
if(isset($_GET['url']))
{
    $url = $_GET['url'];
    $url = trim($url,'/');
    $url = explode('/', $url);
    if(count($url)>3) $mid = $url[3];
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fa-ir" lang="fa-ir"><head>
<meta name="Template" content="">
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="robots" content="index, follow">
<meta name="keywords" content="">
<meta name="description" content="">
<title><?php echo SITE_NAME; ?></title>
  
<link href="<?php echo URL;?>template/default/css/template.css" rel="stylesheet" type="text/css">


<script>
function conf()
{
	if(confirm("آیا می خواهید این محتوا را حذف کنید؟"))
	{
	return true;
	}
	else
	{
	return false;
	}
}
</script>
</head>
<body id="bd" class="fs3 FF">
<div id="ja-wrapper">
	<a name="Top" id="Top"></a>
	<div id="ja-container" class="wrap ja-l1r1">
		<div class="main clearfix">
			<div id="ja-mainbody" style="width:80%">
				<div class="ja-box1">
					<div class="ja-box2">
						<div id="ja-main" style="width:100%">
							<div class="inner ja-box-br">
								<div class="ja-box-bl">
									<div class="ja-box-tr">
										<div class="ja-box-tl clearfix">
											<div id="ja-breadcrums">
												<div class="inner clearfix">
													<strong></strong> <span class="breadcrumbs pathway">ایجاد و ویرایش محتوا</span>
												</div>
											</div>
											<div id="ja-contentwrap" class="">
												<div id="ja-content" class="column" style="width:100%">
													<div id="ja-current-content" class="column" style="width:100%">
														<div class="ja-content-main clearfix">
															<form name="newad" method="post" enctype="multipart/form-data" action="">
																<div>
																	<div style="float:right; text-align:right; width:20%;height:30px;">
																		نام صفحه
																	</div>
																	<div style="float:right; text-align:right; width:30%;height:30px;">
																		<input name="name" id="name" value = "<?php echo $this->name; ?>" class="inp1" type="text">
																	</div>
																	<div style="float:right; text-align:right; width:50%;height:30px;">
																	
																	</div>
																</div>
																<div>
																	<div style="float:right; text-align:right; width:20%;height:30px;">
																		محتوا
																	</div>
																	<div style="float:right; text-align:right; width:30%;height:200px;">
																		<textarea name="content" id="content" rows="10" cols="54" style="color:#414141;background-color:LightGrey;font-family:Tahoma;font-size:12px;"><?php echo $this->content;?></textarea>
																	</div>
																	<div style="float:right; text-align:right; width:50%;height:30px;">
                                                                        <input name="id" id="id" value = "<?php echo $id; ?>" type="hidden" />
																	</div>
																</div>
																<div>
																	<div style="float:right; text-align:right; width:20%;height:30px;">

																	</div>
																	<div style="float:right; text-align:right; width:30%;height:30px;">
																		<?php
																			if( $this->editMode == 1)
																			{
                                                                                ?>
																				<input value="<?php echo $mid; ?>" name="id" id="id" type="hidden" />  
                                                                                <input class="inputbox" dir="rtl" value="  ویرایش  " name="editcontent" id="editcontent" style="width: 100px;" type="submit" />  
																				<?php
																			}
																			else
																			{
																				?>
																				<input class="inputbox" dir="rtl" value="  ثبت  " name="addcontent" id="addcontent" style="width: 100px;" type="submit" />  
																				<?php
																			}
																			?>
																		<input class="inputbox" dir="rtl" value="  انصراف  " name="canads" id="canads" style="width: 100px;" type="button" onclick=window.location='index.php'>&nbsp; 
																	</div>
																	<div style="float:right; text-align:right; width:50%;height:30px;">
																		
																	</div>
																</div>
																<div>
																	<div style="float:right; text-align:right; width:20%;height:30px;">

																	</div>
																	<div style="float:right; text-align:right; width:30%;height:30px;">
																	</div>
																	<div style="float:right; text-align:right; width:50%;height:30px;">
																		
																	</div>
																</div>	
															</form>
															<table id="table1" class="sortable" style="font: 11px Tahoma; background: #fff; color: #091f30; width: 100%" border="0" cellpadding="0" cellspacing="0">
																<thead>
																	<tr style="height:5px;vertical-align:middle">
																		<th class="tabl">
																			ردیف
																		</th>
																		<th class="tabl">
																			نام صفحه
																		</th>
																		<th class="tabl">
																			عملیات
																		</th>

																	</tr>
																</thead>
																<tbody>
																	<?php
																	$result  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."content ORDER BY `id` ASC" );
																	while($show_result=$db->sql_fetcharray($result))
																	{
																		$id      = $show_result['id'];
																		$name    = $show_result['name'];
																		$content = $show_result['content'];
																		
																		$col = "#FFFFFF";
																		?>
																		<tr style="background-color:#FFFFFF">
																			<td style="text-align: center;"><?php echo $id; ?></td>
																			<td style="text-align: center;"><?php echo $name; ?></td>
																			<td style="text-align: center;">							
																				<table>
																					<tbody>
																						<tr>
																							<td>
																								<a href="<?php echo URL; ?>admin/content/delete/<?php echo $id; ?>" onclick="return conf()">
																									<img src="<?php echo URL; ?>template/default/image/delete.gif" border="0">
																								</a>
																							</td>
																							<td>
																								<a href="<?php echo URL; ?>admin/content/edit/<?php echo $id; ?>">
																									<img src="<?php echo URL; ?>template/default/image/edit.gif" border="0">
																								</a>
																							</td>
																						</tr>
																					</tbody>
																				</table>
																			</td>
																		</tr>
																		<?php
																	}
																	?>
																</tbody>
															</table>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php include "adminmenu.php"; ?>
		</div>
	</div>
	<div id="ja-footer" class="wrap">
		<div class="main clearfix">
			<div class="ja-footnav clearfix">
				<ul class="ja-links">
					<li class="top">
						<a href="#Top" title="Back to Top">بالا</a>
					</li>
				</ul>
			</div>

			<div>
				<div align="center">
					<p><?php echo SITE_FOOTER; ?></p>
					<p align ="center"><?php include "copyright.php"; ?></p>
				</div>
			</div>
		</div>
	</div>
</div>
</body></html>
<?php
}
else
{
	header("Location: index.php");		
}
?>
