<?php
require "include/db.php";
if(isset($_SESSION['SUB_ADMIN_ID'])) {

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fa-ir" lang="fa-ir"><head>
<meta name="Template" content="">
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="robots" content="index, follow">
<meta name="keywords" content="">
<meta name="description" content="">
<title><?php echo SITE_NAME; ?></title>
  
<link href="<?php echo URL;?>template/default/css/template.css" rel="stylesheet" type="text/css">

</head>
<body id="bd" class="fs3 FF">
<div id="ja-wrapper">
	<a name="Top" id="Top"></a>
	<div id="ja-container" class="wrap ja-l1r1">
		<div class="main clearfix">
			<div id="ja-mainbody" style="width:80%">
				<div class="ja-box1">
					<div class="ja-box2">
						<div id="ja-main" style="width:100%">
							<div class="inner ja-box-br">
								<div class="ja-box-bl">
									<div class="ja-box-tr">
										<div class="ja-box-tl clearfix">
											<div id="ja-breadcrums">
												<div class="inner clearfix">
													<strong></strong> <span class="breadcrumbs pathway">تنظیمات</span>
												</div>
											</div>
											<div id="ja-contentwrap" class="">
												<div id="ja-content" class="column" style="width:100%">
													<div id="ja-current-content" class="column" style="width:100%">
														<div class="ja-content-main clearfix">
															<form name="newad" method="post" enctype="multipart/form-data" action="">
																<div>
																	<div style="float:right; text-align:right; width:20%;height:30px;">
																		عنوان سایت
																	</div>
																	<div style="float:right; text-align:right; width:32%;height:30px;">
																		<input name="onvan" id="onvan" value="<?php echo $this->onvan; ?>" class="inp1" type="text">
																	</div>
																	<div style="float:right; text-align:right; width:48%;height:30px;">
																	
																	</div>
																</div>
																<div>
																	<div style="float:right; text-align:right; width:20%;height:30px;">
																		ایمیل سایت
																	</div>
																	<div style="float:right; text-align:right; width:32%;height:30px;">
																		<input name="siteEmail" id="siteEmail" value="<?php echo $this->siteEmail; ?>" class="inp1" type="text">
																	</div>
																	<div style="float:right; text-align:right; width:48%;height:30px;">
																		
																	</div>
																</div>
																<div>
																	<div style="float:right; text-align:right; width:20%;height:30px;">
																		تعداد آگهی های صفحه اول
																	</div>
																	<div style="float:right; text-align:right; width:32%;height:30px;">
																		<input name="ads_on_first_page" id="ads_on_first_page" value="<?php echo $this->ads_on_first_page; ?>" class="inp1" type="text">
																	</div>
																	<div style="float:right; text-align:right; width:48%;height:30px;">
																		
																	</div>
																</div>
																<div>
																	<div style="float:right; text-align:right; width:20%;height:30px;">
																		قیمت هر ستاره
																	</div>
																	<div style="float:right; text-align:right; width:32%;height:30px;">
																		<input name="star_price" id="star_price" value="<?php echo sefr($this->star_price); ?>" class="inp1" type="text">
																	</div>
																	<div style="float:right; text-align:right; width:48%;height:30px;">
																		ریال
																	</div>
																</div>
																<div>
																	<div style="float:right; text-align:right; width:20%;height:30px;">
																		قیمت لینک
																	</div>
																	<div style="float:right; text-align:right; width:32%;height:30px;">
																		<input name="link_price" id="link_price" value="<?php echo sefr($this->link_price); ?>" class="inp1" type="text">
																	</div>
																	<div style="float:right; text-align:right; width:48%;height:30px;">
																		ریال
																	</div>
																</div>
																<div>
																	<div style="float:right; text-align:right; width:20%;height:30px;">
																		قیمت آگهی ویژه
																	</div>
																	<div style="float:right; text-align:right; width:32%;height:30px;">
																		<input name="ads_sp_price" id="ads_sp_price" value="<?php echo sefr($this->ads_sp_price); ?>" class="inp1" type="text">
																	</div>
																	<div style="float:right; text-align:right; width:48%;height:30px;">
																		ریال
																	</div>
																</div>
																<div>
																	<div style="float:right; text-align:right; width:20%;height:30px;">
																		اعتبار هدیه
																	</div>
																	<div style="float:right; text-align:right; width:32%;height:30px;">
																		<input name="gift" id="gift" value="<?php echo sefr($this->gift); ?>" class="inp1" type="text">
																	</div>
																	<div style="float:right; text-align:right; width:48%;height:30px;">
																		ریال
																	</div>
																</div>
																<div>
																	<div style="float:right; text-align:right; width:20%;height:30px;">
																		نشان دادن آگهی بدون عکس
																	</div>
																	<div style="float:right; text-align:right; width:32%;height:30px;">
																		<input name="image_ads_show" id="image_ads_show" value="<?php echo sefr($this->image_ads_show); ?>" class="inp1" type="text">
																	</div>
																	<div style="float:right; text-align:right; width:48%;height:30px;">
																		
																	</div>
																</div>
																<div>
																	<div style="float:right; text-align:right; width:20%;height:30px;">
																		آدرس وب سرویس پیامک
																	</div>
																	<div style="float:right; text-align:right; width:32%;height:30px;">
																		<input name="smsWebservise" id="smsWebservise" value="<?php echo $this->smsWebservise; ?>" class="inp1" type="text">
																	</div>
																	<div style="float:right; text-align:right; width:48%;height:30px;">
																		
																	</div>
																</div>
																<div>
																	<div style="float:right; text-align:right; width:20%;height:30px;">
																		شماره مرکز پیامک شما
																	</div>
																	<div style="float:right; text-align:right; width:32%;height:30px;">
																		<input name="smsNumber" id="smsNumber" value="<?php echo $this->smsNumber; ?>" class="inp1" type="text">
																	</div>
																	<div style="float:right; text-align:right; width:48%;height:30px;">
																		
																	</div>
																</div>
																<div>
																	<div style="float:right; text-align:right; width:20%;height:30px;">
																		نام کاربری مرکز پیامک
																	</div>
																	<div style="float:right; text-align:right; width:32%;height:30px;">
																		<input name="smsUsername" id="smsUsername" value="<?php echo $this->smsUsername; ?>" class="inp1" tabindex="10">
																	</div>
																	<div style="float:right; text-align:right; width:48%;height:30px;">
																		
																	</div>
																</div>
																<div>
																	<div style="float:right; text-align:right; width:20%;height:30px;">
																		کلمه عبور مرکز پیامک
																	</div>
																	<div style="float:right; text-align:right; width:32%;height:30px;">
																		<input name="smsPassword" id="smsPassword" value="<?php echo $this->smsPassword; ?>" class="inp1" type="text">
																	</div>
																	<div style="float:right; text-align:right; width:48%;height:30px;">
																		
																	</div>
																</div>
																<div>
																	<div style="float:right; text-align:right; width:20%;height:30px;">
																		آی پی شماره 1
																	</div>
																	<div style="float:right; text-align:right; width:32%;height:30px;">
																		<input name="ip1" id="ip1" value="<?php echo $this->ip1; ?>" class="inp1" type="text">
																	</div>
																	<div style="float:right; text-align:right; width:48%;height:30px;">
																		این IP در آمارگیری سایت محاسبه نمی شود.
																	</div>
																</div>
																<div>
																	<div style="float:right; text-align:right; width:20%;height:30px;">
																		آی پی شماره 2
																	</div>
																	<div style="float:right; text-align:right; width:32%;height:30px;">
																		<input name="ip2" id="ip2" value="<?php echo $this->ip2; ?>" class="inp1" type="text">
																	</div>
																	<div style="float:right; text-align:right; width:48%;height:30px;">
																		این IP در آمارگیری سایت محاسبه نمی شود.			
																	</div>
																</div>
																<div>
																	<div style="float:right; text-align:right; width:20%;height:30px;">
																		اجاز ورود ایمیل های تایید نشده
																	</div>
																	<div style="float:right; text-align:right; width:32%;height:30px;">
																		<select name="loginNotConfirmedEmail" id="loginNotConfirmedEmail" class="inp2" onChange="cha(this.value)" >
																			<?php
																			if($this->loginNotConfirmedEmail == 0)
																			{
																				?>
																				<option value='1'>بلی</option>
																				<option value='0' selected>خیر</option>
																				<?php
																			}
																			else
																			{
																				?>
																				<option value='1' selected>بلی</option>
																				<option value='0'>خیر</option>
																				<?php
																			}
																			?>
																		</select>
																	</div>
																	<div style="float:right; text-align:right; width:48%;height:30px;">
																					
																	</div>
																</div>
																<div>
																	<div style="float:right; text-align:right; width:20%;height:30px;">
																		ارسال ایمیل عضویت
																	</div>
																	<div style="float:right; text-align:right; width:32%;height:30px;">
																		<select name="registerMode" id="registerMode" class="inp2" onChange="cha(this.value)" >
																			<?php
																			if($this->registerMode == 0)
																			{
																				?>
																				<option value='1'>بلی</option>
																				<option value='0' selected>خیر</option>
																				<?php
																			}
																			else
																			{
																				?>
																				<option value='1' selected>بلی</option>
																				<option value='0'>خیر</option>
																				<?php
																			}
																			?>
																		</select>
																	</div>
																	<div style="float:right; text-align:right; width:48%;height:30px;">
																					
																	</div>
																</div>
																<div>
																	<div style="float:right; text-align:right; width:20%;height:30px;">
																		گالری تصاویر
																	</div>
																	<div style="float:right; text-align:right; width:32%;height:30px;">
																		<select name="galeryThemes" id="galeryThemes" class="inp2" onChange="cha(this.value)" >
																			<?php
																			if($this->galeryThemes == 1) $s1='selected';
																			if($this->galeryThemes == 2) $s2='selected';
																			if($this->galeryThemes == 3) $s3='selected';
																			if($this->galeryThemes == 4) $s4='selected';
																			if($this->galeryThemes == 5) $s5='selected';
																			?>
																				<option value='1' <?php echo $s1; ?>>گالری شماره 1</option>
																				<option value='2' <?php echo $s2; ?>>گالری شماره 2</option>
																				<option value='3' <?php echo $s3; ?>>گالری شماره 3</option>
																				<option value='4' <?php echo $s4; ?>>گالری شماره 4</option>
																				<option value='5' <?php echo $s5; ?>>گالری شماره 5</option>
																		</select>
																	</div>
																	<div style="float:right; text-align:right; width:48%;height:30px;">
																					
																	</div>
																</div>
																<div>
																	<div style="float:right; text-align:right; width:20%;height:30px;">
																		تعداد ستون ها
																	</div>
																	<div style="float:right; text-align:right; width:32%;height:30px;">
																		<select name="adsCol" id="adsCol" class="inp2" onChange="cha(this.value)" >
																			<?php
																			if($this->adsCol == 4)
																			{
																				?>
																				<option value='3'>3</option>
																				<option value='4' selected>4</option>
																				<?php
																			}
																			else
																			{
																				?>
																				<option value='3' selected>3</option>
																				<option value='4'>4</option>
																				<?php
																			}
																			?>
																		</select>
																	</div>
																	<div style="float:right; text-align:right; width:48%;height:30px;">
																					
																	</div>
																</div>
																<div>
																	<div style="float:right; text-align:right; width:20%;height:30px;">

																	</div>
																	<div style="float:right; text-align:right; width:32%;height:30px;">
																		<input class="inputbox" dir="rtl" value="  ارسال  " name="updatesetting" id="updatesetting" style="width: 100px;" type="submit">&nbsp;  
																		<input class="inputbox" dir="rtl" value="  انصراف  " name="canads" id="canads" style="width: 100px;" type="button" onclick=window.location='index.php'>&nbsp; 
																	</div>
																	<div style="float:right; text-align:right; width:48%;height:30px;">
																		
																	</div>
																</div>
																<div>
																	<div style="float:right; text-align:right; width:20%;height:30px;">

																	</div>
																	<div style="float:right; text-align:right; width:32%;height:30px;">
																		<?php echo $this->msg; ?>
																	</div>
																	<div style="float:right; text-align:right; width:48%;height:30px;">
																		
																	</div>
																</div>	
															</form>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php include "adminmenu.php"; ?>
		</div>
	</div>
	<div id="ja-footer" class="wrap">
		<div class="main clearfix">
			<div class="ja-footnav clearfix">
				<ul class="ja-links">
					<li class="top">
						<a href="#Top" title="Back to Top">بالا</a>
					</li>
				</ul>
			</div>
			<div>
				<div align="center">
					<p><?php echo SITE_FOOTER; ?></p>
					﻿<p align ="center"><?php include "copyright.php"; ?></p>
				</div>
			</div>
		</div>
	</div>
</div>
</body></html>
<?php
}
else
{
	header("Location: index.php");
}
?>
