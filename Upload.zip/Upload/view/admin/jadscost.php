<?php	
require "../include/config.php";
$m = $_GET["param"];
$y = explode(',',$m);
$kind   = $y[0];
$hasurl = $y[1];
$star   = $y[2];

$star_price   = Setting::GetSetting(2);
$link_price   = Setting::GetSetting(3);
$ads_sp_price = Setting::GetSetting(4);

if($kind == 0) {$adsprice = $hasurl * $link_price;}
if($kind == 1) {$adsprice = $kind * $ads_sp_price + $hasurl * $link_price + $star * $star_price;}

echo $adsprice.",".$hasurl.",".$kind;


?>