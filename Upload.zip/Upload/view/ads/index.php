<?php
include "include/db.php";
$msg = '';$msg1 = '';$r='';$jjj='';$gcnt=0;$mn='';

if($this->group != 1)
{
    $adsid    = $this->adsid;
    $userid    = $this->userid;
    $mgid      = $this->mgid;
    $sgid      = $this->sgid;
    $subject   = $this->subject;
    $comment   = $this->comment;
    $price     = $this->price;
    $adskind   = $this->adskind;
    $url       = $this->url;
    $hasurl    = $this->hasurl;
    $star      = $this->star;
    $name      = $this->name;
    $email     = $this->email;
    $tel       = $this->tel;
    $mobile    = $this->mobile;
    $address   = $this->address;
    $crdate    = $this->crdate;
    $update    = $this->update;
    $lvdate    = $this->lvdate;
    $yahoo     = $this->yahoo;
    $visit     = $this->visit;
    $timelong  = $this->timelong;
    $keyword   = $this->keyword;
    $expdate   = $update + $timelong * 86400;
    $jdate     = s_to_j($expdate);

    $result7      = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."user WHERE id = $userid " );
    $show_result7 = $db->sql_fetcharray($result7);
    $vitrin       = $show_result7['vitrin'];
    $name7        = $show_result7['name'];

    $exp = 0;
    $time = time();
    if($time > $update + ($timelong * 86400)) $exp = 1;
	$update = s_to_j($update);
	
    $result      = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."adsmaingroup WHERE mgid = $mgid " );
    $show_result = $db->sql_fetcharray($result);
    $mgname      = $show_result['mgname'];


    $result      = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."adssubgroup WHERE sgid = $sgid " );
    $show_result = $db->sql_fetcharray($result);
    $sgname      = $show_result['sgname'];


	$visit = $visit + 1;
	$db->sql_query("UPDATE ".TABLE_PREFIX."advertise SET visit = '$visit', lvdate = '$time' WHERE id = $adsid");
  
    $gcnt   = my_count(TABLE_PREFIX.'galery','id','adsid',$adsid,-1,-1,-1,-1,-1,-1);
    if($gcnt > 0) 
    {
        require "include/galery/UberGallery.php";
        $gallery = new UberGallery();
    }
}
else 
{
    $result      = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."adssubgroup WHERE sgid = $this->sgid " );
    $show_result = $db->sql_fetcharray($result);
    $sgname      = $show_result['sgname'];
    
    $result      = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."adsmaingroup WHERE mgid = $this->mgid " );
    $show_result = $db->sql_fetcharray($result);
    $mgname      = $show_result['mgname'];
    
    $subject     = "گروه ".$sgname." صفحه شماره".$this->page;
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fa-ir" lang="fa-ir">
<head>
	<meta name="Template" content="" />
	<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
	<meta name="robots" content="index, follow" />
	<meta name="keywords" content="<?php echo $keyword ?>" />
	<meta name="description" content="<?php echo $subject ?>" />
	<title><?php echo SITE_NAME.'-'.$subject; ?></title>


	<link   href="<?php echo URL; ?>template/default/css/template.css" rel="stylesheet"      type="text/css" />
	<link   href="<?php echo URL; ?>template/default/css/menu.css" rel="stylesheet"      type="text/css" />
	<script type="text/javascript" src="<?php echo URL; ?>include/ajax.js"></script>
	<?php
	if($gcnt > 0)
	{
		?>
			<link rel="stylesheet" type="text/css" href="<?php echo URL; ?>template/default/css/galery/style.css" />
            <link rel="stylesheet" type="text/css" href="<?php echo URL; ?>template/default/css/galery/colorbox/<?php echo GALERY_THEMES; ?>/colorbox.css" />
			<script type="text/javascript" src="<?php echo URL; ?>template/default/css/galery/jquery-2.1.0.min.js"></script>
			<script type="text/javascript" src="<?php echo URL; ?>template/default/css/galery/colorbox/jquery.colorbox.js"></script>
		<?php
	}
?>

<script type="text/javascript">
    $(document).ready(function(){
        $("a[rel='colorbox']").colorbox({maxWidth: "90%", maxHeight: "90%", opacity: ".5"});
    });
</script>

<script type="text/javascript">
	$(document).ready(function() {
		  $('input[type="checkbox"]').ezMark();
		  $('input[type="radio"]').ezMark();
		  $().piroBox_ext({
		  piro_speed : 700,
			  bg_alpha : 0.5,
			  piro_scroll : true
		  });
	  
	});
	$(function(){
		$("#menu ul li:has(ul)").find("span:first").addClass("down");
		$("#menu ul li ul li:has(ul)").find("span:first").removeClass("down");
		$("#menu ul li ul li:has(ul)").find("a:first").addClass("fly");
	});
	$(function(){
	  $('#errid').click();
	});
</script>
<script>
		function question(string)
		{
			var faqDiv1 = document.getElementById('faqDiv1');
			var faqDiv2 = document.getElementById('faqDiv2');
			var faqDiv = document.getElementById('faqDiv');
			var btnSend = document.getElementById('btnSend');
			
			
			if(string == 1)
			{
				faqDiv1.style.display = "inline";
				faqDiv2.style.display = "none";
				faqDiv.style.display = "none";
			}
			else if(string == 2)
			{
				document.getElementById('qName').disabled = true;
				document.getElementById('qEmail').disabled = true;
				document.getElementById('qText').disabled = true;
				
				faqDiv.style.display = "inline";
				faqDiv1.style.display = "none";
				faqDiv2.style.display = "none";
				btnSend.style.display = "none";
				
			}
			else
			{
				faqDiv2.style.display = "inline";
				faqDiv1.style.display = "none";
				faqDiv.style.display = "none";
			}
		}
</script>
</head>

<body id="bd" class="fs3 FF">
<div id="ja-wrapper">
	<a name="Top" id="Top"></a>
		<div class="wrap">
		<div class="main">
			<div class="inner clearfix">
				<?php include "topmenu.php"; ?>
			</div>
		</div>
	</div>
	<div id="ja-header" class="wrap">
		<div class="main">
			<div class="inner clearfix">
				<div class="logo-text">
					<?php include "logo.php"; ?>
				</div>	
				<div id="ja-search">
					<?php include "searchbox.php"; ?>
				</div>
			</div>
		</div>
	</div>
	<div id="ja-mainnav" class="wrap">
		<div >
			<?php include "topgroup.php"; ?>
		</div>
	</div>
	<ul class="no-display">
		<li><a href="" title=""></a></li>
	</ul>
	<div id="ja-container" class="wrap ja-l1r1">
		<div class="main clearfix">
			<div id="ja-mainbody" style="width:80%">
				<div class="ja-box1">
					<div class="ja-box2">
						<?php
						if($this->group != 1)
						{
						?>
						<div id="ja-main" style="width:70%">
							<div class="inner ja-box-br">
								<div class="ja-box-bl">
									<div class="ja-box-tr">
										<div class="ja-box-tl clearfix">
											<div id="ja-breadcrums">
												<div class="inner clearfix">
													<strong></strong> <span class="breadcrumbs pathway"><?php echo $mgname; ?> :: <?php echo $sgname; ?></span>
												</div>
											</div>
											<div id="ja-contentwrap" class="">
												<div id="ja-content" class="column" style="width:100%">
													<div id="ja-current-content" class="column" style="width:100%">
														<div class="ja-content-main clearfix">
															<div class="main-deal-bottom2 pie">
																<div class="details">
																<div class="title">
																	<h1 class="fv c0 s18">
																		<b><?php echo $subject; ?></b> 
																	</h1>
																</div>
																<div style="float:left;padding-left:10px;">
																	<?php
																	if($adskind == 1)
																	{
																		?>
																		<img alt="Special ads" src="<?php echo URL; ?>template/default/image/sp.png" />
																		<?php
																	}
																	?>
																</div>
																<div style="padding: 0px 15px;">
																	<div class="img1" style="text-align: center;">
																		<div style="text-align: center;">
																			<img alt="stars" src="<?php echo URL; ?>template/default/image/star_v_<?php echo $star; ?>.gif" width="70" height="9" />
																		</div>
																		<div style="text-align: center;">
																			<br/>
																			<img alt="" src="<?php echo URL; ?>images/ads/big/<?php echo $adsid ?>.jpg" border="0" />
																		</div>
																	</div>
																	<div>
																		<div style="float: left; width: 297px;"></div>
																		<div>
																			<?php echo nl2br($comment); ?>
																		</div>
																		<div id="galleryListWrapper">
																			<ul id="galleryList" class="clearfix">
																				<?php
																				$result  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."galery WHERE `adsid` = '$adsid' ORDER BY `date` DESC" );
																				while($show_result=$db->sql_fetcharray($result))
																				{
																					$name1 = $show_result['name'];
																					$alt1  = $show_result['alt'];
																					
																					?>
																					<li><a href="<?php echo URL; ?>images/galery/big/<?php echo $name1; ?>" title="<?php echo $alt1; ?>" alt="<?php echo $alt1; ?>" rel="colorbox" /> <img src="<?php echo URL; ?>images/galery/med/<?php echo $name1; ?>" alt=""></a></li>
																					<?php
																				}
																				?>
																			</ul>
																		</div>
																		<div id="Specification1"></div>
																		<div class="clr"></div>
																	</div>
																		<?php
																		if($exp == 1)
																		{
																			?>
																			<div>
																			
																				<div id="lad_dtl_PhoneNumberContainerDiv" class="lad_dtl__phone_off"></div>
																			</div>
																			<?php
																		}
																		else
																		{
																			?>
																			<div class="contact">
																				<?php
																				if($vitrin == 1)
																				{
																					?>
																					<a href="index.php?uid=<?php echo $userid; ?>"><div class="lad_dtl__vitrin_on">غرفه مجازی <?php echo $name7; ?></div></a>
																					<?php
																				}
																				if($mobile != NULL)
																				{
																					?>
																					<div class="lad_dtl__phone_on"><?php echo $mobile; ?></div>
																					<?php
																				}
																				elseif($tel != NULL)
																				{
																					?>
																					<div class="lad_dtl__phone_on"><?php echo $tel; ?></div>
																					<?php
																				}
																				?>
																				<div class="rc ft ct1 s11">
																				<div class="c1">نام</div>
																				<div class="c2"><abbr title=""><?php echo $name; ?></abbr></div>
																				</div>
																				<div class="rc ft ct1 s11">
																				<div class="c1">آدرس ایمیل</div>
																				<div class="c2" style="font-family:Tahoma">
																					<?php echo $email; ?>
																				</div>
																				</div>
																				<div class="rc ft ct1 s11">
																				<div class="c1">آدرس</div>
																				<div class="c2"><?php echo $address; ?></div>
																				</div>
																				<div class="rc ft ct1 s11">
																				<div class="c1">بروزرسانی</div>
																				<div class="c2"><?php echo $update; ?></div>
																				</div>
																				<div class="rc ft ct1 s11">
																				<div class="c1">انقضا</div>
																				<div class="c2"><?php echo $jdate; ?></div>
																				</div>
																				<div class="rc ft ct1 s11">
																				<div class="c1">قیمت</div>
																				<div class="c2"><?php echo $price; ?></div>
																				</div>
																				<div class="rc ft ct1 s11">
																				<div class="c1">وب سایت</div>
																				<?php
																				if($hasurl == 1)
																				{
																					?>
																					<div class="c2"><a href="<?php echo $url; ?>" target="_blank" style="font-family:Tahoma"><?php echo $url; ?></a></div>
																					<?php
																				}
																				?>
																				</div>
																				<div class="rc ft ct1 s11">
																				<div class="c1"><img class="dstat" src="<?php echo URL; ?>template/default/image/stat-icon.gif" align="absmiddle" />بازدید</div>
																				<div class="c2"><?php echo $visit; ?></div>
																				</div>
																			</div>
																			<?php
																		}
																		?>
																	<div class="clr"></div>
																</div>
																<?php
																if($exp != 1)
																{
																	?>
																	<div class="faq" id="faqMainDiv1">
																		<div style="height: 200px;" id="lad_dtl_QuestionFromContainerDiv">
																			<div class="name">پرسش از آگهی دهنده</div>
																			<div class="input"><span>نام</span> <input name="qName" id="qName" class="textbox" type="text"></div>
																			<div class="input"><span>پست الکترونیک</span> <input name="qEmail" id="qEmail" class="textbox" type="text"></div>
																			<div style="border: 0px; float: right; width: 330px;">
                                                                                <textarea name="qText" id="qText" cols="20" ></textarea>
																			</div>
																			<div class="btn" id = "btnSend">
																				<span onclick="sendQuestion(qName.value,qEmail.value,qText.value,<?php echo $userid.",".$adsid; ?>)"><img src="<?php echo URL; ?>template/default/image/n.gif" style="width: 76px; height: 22px; background: url(<?php echo URL; ?>template/default/image/detail-faq-send.png) repeat scroll 0% 0% transparent; margin: 16px 1px 0pt 0pt; float: right; cursor: pointer;" /></span>
																			</div>
                                                                            
																		</div>
                                                                        <div>
																			<div id="faqDiv" style="display: none; height: 250px;">
																				<div style="background: url(<?php echo URL; ?>template/default/image/sms-message-icon.png) no-repeat right center; padding-right: 30px; margin: 20px 8px 0; height: 25px; width: 200px;"><span>پرسش شما با موفقیت ارسال شد.</span></div>
																			</div>
																			<div id="faqDiv1" style="display: none; height: 150px;">
																				<div class="name"><span><font color="red">اطلاعات را کامل وارد نمایید</font></span></div>
																			</div>
																			<div id="faqDiv2" style="display: none; height: 150px;">
																				<div><span><font color="red">مشکل در ارسال درخواست. مجددا تلاش کنید</font></span></div>
																			</div>
                                                                        </div>
																	</div>
																	<?php
																}
																?>
															</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<?php
						}
						?>
						<div id="ja-left" class="column sidebar" style="width:30%">
							<div class="ja-colswrap clearfix ja-l1">
								<div class="ja-col  column">
									<div class="ja-module ja-box-br module_hilite" id="Mod48">
										<div class="ja-box-bl">
											<div class="ja-box-tr">
												<div class="ja-box-tl clearfix">
												
													<h3><span>آگهی‌های جدید: <?php echo $sgname; ?></span></h3>
                                                                                                        <div class="jamod-content ja-box-ct clearfix">
													
														<?php
														$result      = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."advertise WHERE sgid = $this->sgid AND status = 1 ORDER BY id DESC " );
														while($show_result = $db->sql_fetcharray($result))
														{
															$jjj++;
															$othersubject  = $show_result['subject'];
															$othername     = $show_result['name'];
															$othertel      = $show_result['tel'];
															$otherlink     = $show_result['url'];
															$otheradsid    = $show_result['id'];
															$otherstar1    = $show_result['star'];
															$otherstar     = "star_v_".$otherstar1;
															
														?>
															<div>
																<a href="<?php echo URL; ?>ads/view/<?php echo $otheradsid?>/<?php echo space_rep($othersubject); ?>"><?php echo $othersubject; ?></a>
															</div>
															<div style="text-align: left;">
                                                                <img alt="stars" src="<?php echo URL; ?>template/default/image/<?php echo $otherstar; ?>.gif" width="70" height="9" />
															</div>
															<div style="height: 100px;">
																<a href="<?php echo URL; ?>ads/view/<?php echo $otheradsid; ?>/<?php echo space_rep($othersubject); ?>"><img alt="" src="<?php echo URL; ?>images/ads/med/<?php echo $otheradsid; ?>.jpg" align="right" border="0" /></a>
															</div>		
															<div>
																<?php echo $othername; ?><br/>تلفن: <span dir="ltr"><?php echo $othertel; ?></span>			    
															</div>
															<div>
																<hr style="color:#FFDDBB" align="center">
															</div>
														<?php
														if($jjj > 3) break;
														}
														?>	
                                                        <?php $a5=time(); ?>
													</div>
												</div>
											</div>
										</div>
									</div>
									<div class="ja-module ja-box-br module_hilite" id="Mod48">
										<div class="ja-box-bl">
											<div class="ja-box-tr">
												<div class="ja-box-tl clearfix">
													<h3><span>آگهی‌های ویژه: <?php echo $mgname; ?></h3>
													<div class="jamod-content ja-box-ct clearfix">
														<?php
														$uuu='';
														$result      = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."advertise WHERE mgid = $this->mgid AND status = 1 ORDER BY id DESC " );
														while($show_result = $db->sql_fetcharray($result))
														{
															$uuu++;
															$othersubject  = $show_result['subject'];
															$othername     = $show_result['name'];
															$othertel      = $show_result['tel'];
															$otherlink     = $show_result['url'];
															$otheradsid    = $show_result['id'];
															$otherstar1    = $show_result['star'];
															$otherstar     = "star_v_".$otherstar1;	
															
														?>
															
															<div>
																<a href="<?php echo URL; ?>ads/view/<?php echo $otheradsid?>/<?php echo space_rep($othersubject); ?>"><?php echo $othersubject; ?></a>
															</div>
                                                            <div style="text-align: left;">
                                                                <img alt="stars" src="<?php echo URL; ?>template/default/image/<?php echo $otherstar; ?>.gif" width="70" height="9" />
															</div>
															<div style="height: 100px;">
																	<a href="<?php echo URL; ?>ads/view/<?php echo $otheradsid?>/<?php echo space_rep($othersubject); ?>"><img alt="" src="<?php echo URL; ?>images/ads/med/<?php echo $otheradsid; ?>.jpg" align="right" border="0"></a>
															</div>		
															
															
															<div>
																<?php echo $othername; ?><br/>تلفن: <span dir="ltr"><?php echo $othertel; ?></span>			    
															</div>
															
															<div>
																<hr style="color:#FFDDBB" align="center">
															</div>
														<?php
														if($uuu > 4) break;
														}
														?>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<?php
							$ipp = 10;							
							$cnt_query = $db->sql_query("SELECT COUNT(id) FROM ".TABLE_PREFIX."advertise WHERE sgid = $this->sgid and status = 1");
							$cnt_a     = mysql_fetch_row($cnt_query);
							$cnt       = $cnt_a[0];
							
							$pageconf = array(
							'all'=>$cnt ,	 // select count(*) from post where 
							'range'=>$ipp , 	// select * from post limit (inpage-1)*range,range
							'inpage'=>$this->page,	// current page. example $_GET[]
							'limit'=>3 ,	// use number of li for minimize
							'url'=>URL.'ads/group/'.$this->sgid.'/' // url of page. the number showed in end of url
							);
						?>
						<div id="ja-main" style="width:70%">
							<div class="inner ja-box-br">
								<div class="ja-box-bl">
									<div class="ja-box-tr">
										<div class="ja-box-tl clearfix">
											<div id="ja-breadcrums">
												<div class="inner clearfix">
													<strong></strong> <span class="breadcrumbs pathway">تازه های <?php echo $mgname; ?> :: <?php echo $sgname; ?></span>
												</div>
											</div>
											<div id="ja-contentwrap" class="">
												<div id="ja-content" class="column" style="width:100%">
													<div id="ja-current-content" class="column" style="width:100%">
													<div class="ja-content-main clearfix">
															
														<div class="main-deal-bottom2 pie">
															<div class="jamod-content ja-box-ct clearfix">
																<?php
																$result4  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."advertise WHERE `sgid` = $this->sgid and `status` = 1 ORDER BY `update` DESC" );
																while($show_result4=$db->sql_fetcharray($result4))
																{
																	$r++;
																	if($r > $this->page*$ipp) break;
																	if($r <= $this->page*$ipp and $r >= $this->page*$ipp-$ipp+1)
																	{
																		$imid      = $show_result4['id'];
																		$imcomment = $show_result4['comment'];
																		$imsubject = $show_result4['subject'];
																		$imname    = $show_result4['name'];
																		$imtel     = $show_result4['tel'];
																		$immobile  = $show_result4['mobile'];
																		$update    = $show_result4['update'];
																		$tij       = s_to_j($update);																	
																		?>
																		<div>
																			<div style="float: left; width:80%;">
                                                                                <a href="<?php echo URL; ?>ads/view/<?php echo $imid."/".space_rep($imsubject); ?>">
                                                                                <?php echo $imsubject; ?>
																			</a>
																			</div>
																			<div style="float: right; width:20%;">
                                                                                <?php echo $tij; ?>
																			</div>
																		</div>
																		<div>
																			<div style="float: left; width:80%;height:60px;text-align:justify;">
																				<?php 
																				if(strlen($imcomment) < 360)
																				{
																					echo strip_tags($imcomment);
																				 
																				}
																				else
																				{
																					for($ii = 355; $ii < 420; $ii++)
																					{
																						$uuu = substr($imcomment,$ii,1);
																						if($uuu == " ")
																						{
																							$mn = $ii;
																							break;
																						}
																					}
																					$imcomment = substr($imcomment,0,$mn);
																					echo strip_tags($imcomment);
																				}
																				
																				
																				?>
																			</div>
																			<div style="float: right; width:20%;height:60px;">
                                                                                <a href="<?php echo URL; ?>ads/view/<?php echo $imid."/".space_rep($imsubject); ?>"><img alt="<?php echo $imsubject; ?>" src="<?php echo URL; ?>images/ads/small/<?php echo $imid; ?>.jpg" border="0" /> </a>
																			</div>
																		</div>
																		
																		<div>
																			<div style="float: left; width:80%;">
																				<br/>
																				<strong><font color="blue"><?php echo $imname; ?></font>
																				<?php
																				if($immobile != NULL)
																				{
																					?>
																					<font color="red"> همراه: <span dir="ltr"><?php echo $immobile; ?></span></font>
																					<?php
																				}
																				elseif($imtel != NULL)
																				{
																					?>
																					<font color="red"> تلفن: <span dir="ltr"><?php echo $imtel; ?></span></font>
																					<?php
																				}
																				?>
																				</strong>
																			</div>
																			<div style="float: right; width:20%;">
																			
																			</div>
																		</div>
																		<div>
																			<p style="color:#FFFFFF">-<br/>-</p>
																			<hr style="color:#FFDDBB" align="center">
																		</div>

																		<?php
																	}
																}
																?>
															</div>
														</div>
													</div>
													</div>
												</div>	
											</div><?php $a7=time(); ?>
											<div style="padding-right: 50px;">
												<?php
													$pagenumber = new pagination($pageconf);
													echo $pagenumber->pagenumber();
													?>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div id="ja-left" class="column sidebar" style="width:30%">
						</div>
					</div>
				</div>
			</div>
			<?php include "menu.php"; ?>
		</div>
	</div>
	<div id="ja-footer" class="wrap">
		<div class="main clearfix">
			<?php include "dnmenu.php"; ?>
			<div>
				<div align="center">
					<p><?php echo SITE_FOOTER; ?></p>
					<p align ="center"><?php include "copyright.php"; ?></p>
                    <?php include "footer.php"; ?>
				</div>
			</div>
		</div>
	</div>
</div>
</body>
</html>