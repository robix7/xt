<?php
include "include/db.php";
$msg = '';$msg1= '';$email_body = '';$name5='';$email5='';$subject5='';$email_body5='';

if(isset($_POST['send']))
{
	$email      = $_POST["email"];
	$email_body = $_POST["email_body"];
	$name       = $_POST["name"];
	$subject    = $_POST["subject"];
	require('include/captcha/php-captcha.inc.php');
    if (PhpCaptcha::Validate($_POST['user_code'])) 
    {
		if($email_body == "")
		{
			$k =1;
			$email5 = $email;$email_body5 = $email_body;$name5=$name;$subject5=$subject;
			$msg="<strong><font color=red>پیام وارد نشده است</font></strong>";
		}
		else
		{
			if(ereg('^[a-zA-Z0-9_\.\-]+@[a-zA-Z0-9\-]+\.[a-zA-Z0-9\-\.]+$', $email))
			{
				$k = 0;
			}
			else
			{
				$k=1;
				$email5 = $email;$email_body5 = $email_body;$name5=$name;$subject5=$subject;
				$msg="<strong><font color=red>ایمیل را صحیح وارد نمایید</font></strong>";
			}
		}	
		if($k != 1)
		{
			$result      = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."setting WHERE `id` = '12'");
			$show_result = $db->sql_fetcharray($result);
			$siteEmail = $show_result['value'];		
			
			$to = $siteEmail;
			$subject= "پرسش";
			$headers = "From: <$email>\n"."MIME-Version: 1.0\n"."Content-type: text/html; charset=utf-8";           
			$message= $email."<br/>".$name."<br/>".$subject."<br/>".$email_body;
			$sentmail = mail($to,$subject,$message,$headers);
			if($sentmail)
			{
				$email="";$email_body ="";$name="";$subject="";
				$msg = "<strong><font color=blue>پیام ارسال شد</font></strong>";   
			}
			else
			{
				$msg = "<strong><font color=red>پبام ارسال نشد.دقایقی دیگر تلاش نمایید</font></strong>";       
			}			
		}
    }
	else
	{
		$email5 = $email;$email_body5 = $email_body;$name5=$name;$subject5=$subject;
		$msg = "<strong><font color=red>کد امنیتی صحیح نمی باشد</font><strong>"; 
	}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fa-ir" lang="fa-ir">
<head>
	<meta name="Template" content="" />
	<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
	<meta name="robots" content="index, follow" />
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	<title><?php echo SITE_NAME; ?></title>

	<link href="<?php echo URL; ?>template/default/css/template.css" rel="stylesheet"      type="text/css" />
	<link href="<?php echo URL; ?>template/default/css/menu.css"     rel="stylesheet"      type="text/css" />

</head>
<body id="bd" class="fs3 FF">
<div id="ja-wrapper">
	<a name="Top" id="Top"></a>
	<div class="wrap">
		<div class="main">
			<div class="inner clearfix">
				<?php include "topmenu.php" ?>
			</div>
		</div>
	</div>
	<div id="ja-header" class="wrap">
		<div class="main">
			<div class="inner clearfix">
				<div class="logo-text">
					<?php include "logo.php" ?>
				</div>	
				<div id="ja-search">
					<?php include "searchbox.php"; ?>
				</div>
			</div>
		</div>
	</div>
	<div id="ja-mainnav" class="wrap">
		<div >
			<?php include "topgroup.php"; ?>
		</div>
	</div>
	<ul class="no-display">
		<li><a href="" title=""></a></li>
	</ul>
	<div id="ja-container" class="wrap ja-l1r1">
		<div class="main clearfix">
			<div id="ja-mainbody" style="width:80%">
				<div class="ja-box1">
					<div class="ja-box2">
						<div id="ja-main" style="width:100%">
							<div class="inner ja-box-br">
								<div class="ja-box-bl">
									<div class="ja-box-tr">
										<div class="ja-box-tl clearfix">
											<div id="ja-breadcrums">
												<div class="inner clearfix">
													<strong></strong> <span class="breadcrumbs pathway">تماس با ما</span>
												</div>
											</div>
											<div id="ja-contentwrap" class="">
												<div id="ja-content" class="column" style="width:100%">
													<div id="ja-current-content" class="column" style="width:100%">
														<div class="ja-content-main clearfix">
															<div class="main-deal-bottom pie">
																<table class="adsh" cellpadding="0" cellspacing="0" width="100%">
																	<tbody>
																		<tr>
																			<td class="ghd" align="center"><font color="red" >ارسال پیام<font></td>
																		</tr>
																	   <tr>
																			<td class="nLines">
																				<form action="" method="post">						
																					<table class="nLines" cellspacing="0" width="100%">
																						<tbody>
																							<tr>
																								<td colspan="2"><font color="red"><b></b></font></td>
																							</tr>
																							<tr>
																								<td>نام:</td>
																								<td>
																									<div style="text-align:center;margin-top:8px;"> 
																										<input name="name" id="name" class="inp1" value="<?php echo $name5; ?>" type="text" />
																									</div>
																								</td>
																							<tr>
																								<td>آدرس ایمیل:</td>
																								<td>
																									<div style="text-align:center;margin-top:8px;"> 
																										<input name="email" id="email" class="inp1" value="<?php echo $email5; ?>" type="text" />
																									</div>
																								</td>
																							</tr>
																							<tr>
																								<td>موضوع:</td>
																								<td>
																									<div style="text-align:center;margin-top:8px;"> 
																										<input name="subject" id="subject" class="inp1" value="<?php echo $subject5; ?>" type="text" />
																									</div>
																								</td>
																							</tr>
																							<tr>
																								<td>متن:</td>
																								<td>
																									<div style="text-align:center;margin-top:8px;"> 
																										<textarea name="email_body" id="email_body" rows="10" cols="51" style="color:#414141;background-color:LightGrey;font-family:Tahoma;font-size:12px;"><?php echo $email_body5; ?></textarea>
																									</div>
																								</td>
																							</tr>
																							<tr>
																								<td></td>
																								<td align="center"><img src="../include/captcha/visual-captcha.php" width="200" height="60" alt="Visual CAPTCHA" /></td>
																							</tr>
																							<tr>
																								<td width="110" height="20" align="right">کد امنیتی:</td>
																								<td align="center" width="150" height="20">
																									<input name="user_code" size="20"  type="text" />
																								</td>
																							</tr>
																							<tr>
																								<td colspan="2" align="center">
																									<br/>
																									<input name="hasreged" id="hasreged" value="" type="hidden" />
																									<input name="send" id="send" value="ارسال" type="submit" class="button" />
																								</td>
																							</tr>
																							<tr>
																								<td colspan="2"></td>
																								<?php echo $msg; ?>
																							</tr>
																						</tbody>
																					</table>
																				</form>
																			</td>
																		</tr>
																	</tbody>
																</table> 	 			
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php include "menu.php"; ?>
		</div>
	</div>
	<div id="ja-footer" class="wrap">
		<div class="main clearfix">
			<?php include "dnmenu.php"; ?>
			<div>
				<div align="center">
					<p><?php echo SITE_FOOTER; ?></p>
					<p align ="center"><?php include "copyright.php"; ?></p>
				</div>
			</div>
		</div>
	</div>
</div>
</body></html>