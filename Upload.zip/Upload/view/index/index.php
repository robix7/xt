<?php
include "include/db.php";
$msg = '';$msg1 = '';$vitrin='';$cKind='';$pagename='';$pi='';

if(isset($_GET['uid']))
{
	$pi = 1;
	$vitrin = 1 ;
	$uid2        = $_GET['uid'];
	$result      = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."user WHERE id = $uid2 " );
	$show_result = $db->sql_fetcharray($result);
	$name3       = $show_result['name'];
	$vit         = $show_result['vitrin'];
	if($vit == 0) header("Location: index.php");
	$pagename = "غرفه مجازی".$name3;
}

if(isset($_GET['sgid'])) 
{
	$pi = 1;
	$cKind = 2;
	$sgid1 = $_GET['sgid'];
	$data  = get_data($sgid1);
	
	if($data == 1)
	{
		$result      = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."adssubgroup WHERE sgid = $sgid1 " );
		$show_result = $db->sql_fetcharray($result);
		$name4       = $show_result['sgname'];
		$pagename = $name4;
	}
	else
	{
		header("Location: error.php");
	}
	
}
elseif(isset($_GET['mgid']))
{
	$pi = 1;
	$cKind = 1;
	$mgid1 = $_GET['mgid'];
	$data  = get_data($mgid1);
	if($data == 1)
	{
		$result      = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."adsmaingroup WHERE mgid = $mgid1 " );
		$show_result = $db->sql_fetcharray($result);
		$name4       = $show_result['mgname'];
		$pagename = $name4;
	}
	else
	{
		header("Location: error.php");
	}
}
if($pi != 1) $pagename =  SITE_NAME;
if($pi == 1) $pagename =  SITE_NAME."-".$pagename;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fa-ir" lang="fa-ir">
<head>
	<meta name="Template" content="" />
	<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
	<meta name="robots" content="index, follow" />
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	<title><?php echo $pagename; ?></title>

	<link   href="<?php echo URL; ?>template/default/css/template.css" rel="stylesheet"      type="text/css" />
	<link   href="<?php echo URL; ?>template/default/css/menu.css" rel="stylesheet"      type="text/css" />

</head>
<body id="bd" class="fs3 FF">
<div id="ja-wrapper">
	<a name="Top" id="Top"></a>
	<div class="wrap">
		<div class="main">
			<div class="inner clearfix">
				<?php include "topmenu.php" ?>
			</div>
		</div>
	</div>
	<div id="ja-header" class="wrap">
		<div class="main">
			<div class="inner clearfix">
				<div class="logo-text">
					<?php include "logo.php" ?>
				</div>
				<div id="ja-search">
					<?php include "searchbox.php"; ?>
				</div>
			</div>
		</div>
	</div>
	<div>
		<div >
			<?php include "topgroup.php"; ?>
		</div>
	</div>
	<div id="ja-container" class="wrap ja-l1r1">
            <div class="main clearfix">
                <div id="ja-mainbody" style="width:80%">
                    <div class="ja-box1">
                        <div class="ja-box2">
                            <div id="ja-main" style="width:100%">
								<div class="inner ja-box-br">
                                    <div class="ja-box-bl">
										<div class="ja-box-tr">
                                            <div class="ja-box-tl clearfix">
                                                <div id="ja-breadcrums">
                                                    <div class="inner clearfix">
                                                        <?php
                                                        if($vitrin == 1)
                                                        {
                                                                ?>
                                                                <strong></strong> <span class="breadcrumbs pathway">غرفه مجازی <?php echo $name3; ?></span>
                                                                <?php
                                                        }
                                                        else
                                                        {

                                                                if($cKind == 1 OR $cKind == 2 )
                                                                {
                                                                        ?>
                                                                                <strong></strong> <span class="breadcrumbs pathway">آگهی های ویژه <?php echo $name4; ?></span>
                                                                        <?php
                                                                }
                                                                else
                                                                {
                                                                        ?>
                                                                                <strong></strong> <span class="breadcrumbs pathway">آگهی های ویژه</span>
                                                                        <?php
                                                                }
                                                        }
                                                        ?>
                                                     </div>
                                                </div>
                                                <div>
                                                    <div class="column" style="width:100%">
                                                        <div class="column" style="width:100%">
                                                            <div class="ja-content-main clearfix">
                                                                            <?php include "starads.php"; ?> 
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                
                <?php
                $textAds=1;
                if($textAds == 1)
                {
                   ?>

                    <div class="ja-box1">
                        <div class="ja-box2">
                            <div id="ja-main" style="width:100%">
								<div class="inner ja-box-br">
                                    <div class="ja-box-bl">
										<div class="ja-box-tr">
                                            <div class="ja-box-tl clearfix">
                                                <div id="ja-breadcrums">
                                                    <div class="inner clearfix">
                                                        <strong></strong> <span class="breadcrumbs pathway">آگهی های ویژه متنی</span>
                                                     </div>
                                                </div>
                                                <div>
                                                    <div class="column" style="width:100%">
                                                        <div class="column" style="width:100%">
                                                            <div class="ja-content-main clearfix">
                                                                <?php include "textstarads.php"; ?> 
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
                }
                else 
                {
                    ?>
                    </div>
                    <?php
                }
                ?>
		<?php include "menu.php"; ?>
		</div>
	</div>
	<div id="ja-footer" class="wrap">
		<div class="main clearfix">
			<?php include "dnmenu.php"; ?>
			<div>
				<div align="center">
					<p><?php echo SITE_FOOTER; ?></p>
					<p align ="center"><?php include "copyright.php"; ?></p>
				</div>
			</div>
		</div>
	</div>
</div>
</body></html>