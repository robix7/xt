<?php
$aname='';
$muserid     = $_SESSION['SUB_USER_ID'];
$result      = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."user WHERE id = $muserid" );
$show_result = $db->sql_fetcharray($result); 
$mname        = $show_result['name'];
$email        = $show_result['email'];
$active       = $show_result['active'];
if($active == 1) $aname = "تایید شده";
if($active == 0) $aname = "تایید نشده";



$admin='';$adslist='';$fish='';$onlinepay='';$setting='';$addmenu='';$content='';$adsmaingroup='';$adssubgroup='';$accounts='';
$onlinepayaccount='';$userlist='';$adminfooter='';$searchquery='';$keyword='';$amar ='';$visitor='';$emailtemplate='';
$email='';$rq ='';$resetpassword='';
$pt2 =  $_GET['url'];
$pt2 = trim($pt2,'/');
$pt2 = explode('/', $pt2);
$current  = $pt2[1];
switch($current)
{
	case 'index': 			$index 			= 'active';break;
	case 'insertads': 		$insertads		= 'active';break;
	case 'adslist': 		$adslist		= 'active';break;
	case 'message':			$message 		= 'active';break;
	case 'registerfish':	$registerfish	= 'active';break;
	case 'onlinepay':		$onlinepay 		= 'active';break;
	case 'resetpassword':	$resetpassword	= 'active';break;
	case 'setting':			$setting	   	= 'active';break;

}


?>
<div id="ja-right" class="column sidebar" style="width:20%">
	<div class="ja-colswrap clearfix ja-r1">
		<div class="ja-col  column">
			<div class="ja-module ja-box-br module" id="Mod60">
				<div class="ja-box-bl">
					<div class="ja-box-tr">
						<div class="ja-box-tl clearfix">
							<h3><span>فهرست</span></h3>
							<div class="jamod-content ja-box-ct clearfix">
								<div id='cssmenu'>
									<ul>
										<li class='<?php echo $index; ?>'>
											<a href="<?php echo URL; ?>desktop/index">صفحه نخست</a>
										</li>
										<li class='<?php echo $insertads; ?>'>
											<a href="<?php echo URL; ?>desktop/insertads">درج آگهی</a>
										</li>
										<li class='<?php echo $adslist; ?>'>
											<a href="<?php echo URL; ?>desktop/adslist">لیست آگهی ها</a>
										</li>
										<li class='<?php echo $message; ?>'>
											<a href="<?php echo URL; ?>desktop/message">پیام ها</a>
										</li>
										<li class='<?php echo $registerfish; ?>'>
											<a href="<?php echo URL; ?>desktop/registerfish">ثبت فیش بانکی</a>
										</li>
										<li class='<?php echo $onlinepay; ?>'>
											<a href="<?php echo URL; ?>desktop/onlinepay">پرداخت آنلاین</a>
										</li>
										<li class='<?php echo $resetpassword; ?>'>
											<a href="<?php echo URL; ?>desktop/resetpassword">تغییر کلمه عبور</a>
										</li>
										<li class='<?php echo $setting; ?>'>
											<a href="<?php echo URL; ?>desktop/setting">تنظیمات</a>
										</li>
										<li>
											<a href="<?php echo URL; ?>desktop/logout">خروج</a>
										</li>
									</ul>
								</div>
							</div>
						</div>
						<div class="ja-box-tl clearfix">
							<h3><span>اطلاعات اصلی</span></h3>
							<div class="jamod-content ja-box-ct clearfix">
								<ul>
									<li>
										نام:
										<br/>
										<font color="red"><?php echo $mname;?></font>
									</li>
									<li>
										ایمیل:
										<br/>
										<font color="red"><?php echo $email;?></font>
									</li>
									<li>
										آی پی:
										<br/>
										<font color="red"><?php echo $_SERVER['REMOTE_ADDR']; ?></font>
									</li>
									<li>
										وضعیت ایمیل:
										<br/>
										<font color="red"><?php echo $aname; ?></font>
									</li>
								</ul>			
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>