<?php
if(isset($_SERVER['HTTP_REFERER']))
{
	if(!strstr($_SERVER['HTTP_REFERER'],'search.php'))
	{
		if(isset($_POST["search"]))
		{
			$word = $_POST["word"];
			$word = strtolower($word);
			header("Location: ". "search/word/1/$word");
		}
	}
}
?>
