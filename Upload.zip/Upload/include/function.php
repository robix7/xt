<?php
function taginsert($keyword,$adsId,$sgId)
{
	
	global $db;
	$key    = explode("+", $keyword);
	$keylen = sizeof($key);
	for($i = 0; $i < $keylen; $i++)
	{
		$keyw = $key[$i];
		$keywlen = strlen($keyw);
        if($keywlen < 2) {break;}
		
		$cnt_query = $db->sql_query("SELECT COUNT(`id`) FROM ".TABLE_PREFIX."tag WHERE `word` = '$keyw' ");
		$cnt_a     = mysql_fetch_row($cnt_query);
		$cnt       = $cnt_a[0];
		
		if($cnt > 0)
		{
			$result      = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."tag WHERE `word` = '$keyw' ");
			$show_result = $db->sql_fetcharray($result);
			$tagId       = $show_result['id'];
			$oldAdsId    = $show_result['adsid2'];
			$oldGroupId  = $show_result['groupid2'];
			$qty         = $show_result['qty2']+1;
			
			$adsId1 = $oldAdsId.",".$adsId;
			$sgId1  = ",".$sgId.",";
			$sgId2  = ",".$sgId;
			$sgId3  = $sgId.",";
			
			if(!strstr($oldGroupId,","))
			{
				if($oldGroupId != $sgId)
				{
					$groupId = $oldGroupId.",".$sgId;
					$db->sql_query("UPDATE ".TABLE_PREFIX."tag SET `qty2` = '$qty',`adsid2` = '$adsId1',`groupid2` = '$groupId' WHERE `id` = '$tagId'");
				}
				else
				{
					$db->sql_query("UPDATE ".TABLE_PREFIX."tag SET `qty2` = '$qty', `adsid2` = '$adsId1' WHERE `id` = '$tagId'");
				}
			}
			else
			{					
				if(!strstr($oldGroupId,$sgId1) AND !strstr($oldGroupId,$sgId2) AND !strstr($oldGroupId,$sgId3))
				{
					$groupId = $oldGroupId.",".$sgId;
					$db->sql_query("UPDATE ".TABLE_PREFIX."tag SET `qty2` = '$qty',`adsid2` = '$adsId1',`groupid2` = '$groupId' WHERE `id` = '$tagId'");
				}
				else
				{
					$db->sql_query("UPDATE ".TABLE_PREFIX."tag SET `qty2` = '$qty',`adsid2` = '$adsId1' WHERE `id` = '$tagId'");
				}
			}
			
		}
		else
		{
			if($db->sql_query("INSERT INTO ".TABLE_PREFIX."tag VALUES (NULL, '$keyw', '0', '1', '$crdate', '-1', '-1', '$adsId', '$sgId', '0')"))
			{
			
			}
		}
	}
	return 1;
}
function my_count($table,$col,$w1,$m1,$w2,$m2,$w3,$m3,$w4,$m4)
{
	if($w1 == -1) 
	{
		$sql = "SELECT COUNT(`".$col."`) FROM `".$table."`";
	}
	elseif($w2 == -1) 
	{
		$sql = "SELECT COUNT(`".$col."`) FROM `".$table."` WHERE `".$w1."` = ".$m1;
	}
	elseif($w3 == -1)
	{
		$sql = "SELECT COUNT(`".$col."`) FROM `".$table."` WHERE `".$w1."` = ".$m1." and `".$w2."`=". $m2;
	}
	elseif($w4 == -1)
	{
		$sql = "SELECT COUNT(`".$col."`) FROM `".$table."` WHERE `".$w1."` = ".$m1." and `".$w2."`=". $m2." and `".$w3."`=". $m3;
	}
	elseif($w4 != -1)
	{
		$sql = "SELECT COUNT(`".$col."`) FROM `".$table."` WHERE `".$w1."` = ".$m1." and `".$w2."`=". $m2." and `".$w3."`=". $m3." and `".$w4."`=". $m4;
	}
	$cnt_query = mysql_query($sql);
	$cnt_a     = mysql_fetch_row($cnt_query);
	$cnt       = $cnt_a[0];
	return $cnt;
}
function my_max($table,$col,$w1,$m1,$w2,$m2,$w3,$m3,$w4,$m4)
{
	if($w1 == -1) 
	{
		$sql = "SELECT MAX(`".$col."`) FROM `".$table."`";
	}
	elseif($w2 == -1) 
	{
		$sql = "SELECT MAX(`".$col."`) FROM `".$table."` WHERE `".$w1."` = ".$m1;
	}
	elseif($w3 == -1)
	{
		$sql = "SELECT MAX(`".$col."`) FROM `".$table."` WHERE `".$w1."` = ".$m1." and `".$w2."`=". $m2;
	}
	elseif($w4 == -1)
	{
		$sql = "SELECT MAX(`".$col."`) FROM `".$table."` WHERE `".$w1."` = ".$m1." and `".$w2."`=". $m2." and `".$w3."`=". $m3;
	}
	elseif($w4 != -1)
	{
		$sql = "SELECT MAX(`".$col."`) FROM `".$table."` WHERE `".$w1."` = ".$m1." and `".$w2."`=". $m2." and `".$w3."`=". $m3." and `".$w4."`=". $m4;
	}
	$cnt_query = mysql_query($sql);
	$cnt_a     = mysql_fetch_row($cnt_query);
	$cnt       = $cnt_a[0];
	return $cnt;
}
function my_min($table,$col,$w1,$m1,$w2,$m2,$w3,$m3,$w4,$m4)
{
	if($w1 == -1) 
	{
		$sql = "SELECT MIN(`".$col."`) FROM `".$table."`";
	}
	elseif($w2 == -1) 
	{
		$sql = "SELECT MIN(`".$col."`) FROM `".$table."` WHERE `".$w1."` = ".$m1;
	}
	elseif($w3 == -1)
	{
		$sql = "SELECT MIN(`".$col."`) FROM `".$table."` WHERE `".$w1."` = ".$m1." and `".$w2."`=". $m2;
	}
	elseif($w4 == -1)
	{
		$sql = "SELECT MIN(`".$col."`) FROM `".$table."` WHERE `".$w1."` = ".$m1." and `".$w2."`=". $m2." and `".$w3."`=". $m3;
	}
	elseif($w4 != -1)
	{
		$sql = "SELECT MIN(`".$col."`) FROM `".$table."` WHERE `".$w1."` = ".$m1." and `".$w2."`=". $m2." and `".$w3."`=". $m3." and `".$w4."`=". $m4;
	}
	$cnt_query = mysql_query($sql);
	$cnt_a     = mysql_fetch_row($cnt_query);
	$cnt       = $cnt_a[0];
	return $cnt;
}
function get_lang($word)
{
	$word = substr($word,0,1);
	$asc = ord($word);
	if( ($asc >= 65 AND $asc <= 90) OR ($asc >= 97 AND $asc <= 122) OR ($asc >= 48 AND $asc <= 57))
	{
		// English
		$m = 1;
	}
	else
	{
		// Persian
		$m = 2;
	}
	return $m;
}
function get_lang1($word)
{   
	$i='';
	$len = strlen($word);
	for($i = 0; $i < $len; $i++)
	{
		$word1 = substr($word,$i,1);
		$asc = ord($word1);
		if( ($asc >= 65 AND $asc <= 90) OR ($asc >= 97 AND $asc <= 122) OR ($asc >= 48 AND $asc <= 57) OR $asc == 95)
		{
			// English
			$m = 1;
		}
		else
		{
			// Persian
			$m = 2;
			break;
		}
	}
	return $m;
}
function remainCredit($userId)
{
	global $db;
	
	$sumQuery   = $db->sql_query("SELECT SUM(amount) FROM ".TABLE_PREFIX."fish WHERE uid = '$userId' and status = '1' and aid > 0 ");
	$sumFetch   = mysql_fetch_row($sumQuery);
	$fishAmount = $sumFetch[0];
	if($fishAmount == NULL) $fishAmount = 0;
	
	$sumQuery   = $db->sql_query("SELECT SUM(amount) FROM ".TABLE_PREFIX."fish WHERE uid = '$userId' and status = '1' and aid = 0 ");
	$sumFetch   = mysql_fetch_row($sumQuery);
	$fishGift   = $sumFetch[0];
	if($fishGift == NULL) $fishGift = 0;

	$sumQuery    = $db->sql_query("SELECT SUM(amount) FROM ".TABLE_PREFIX."fish WHERE uid = '$userId' and status = '0' ");
	$sumFetch    = mysql_fetch_row($sumQuery);
	$fishPending = $sumFetch[0];
	if($fishPending == NULL) $fishPending = 0;

	$sumQuery     = $db->sql_query("SELECT SUM(amount) FROM ".TABLE_PREFIX."onlinepay WHERE uid = '$userId' and finalized = '1' ");
	$sumFetch     = mysql_fetch_row($sumQuery);
	$onlineAmount = $sumFetch[0];
	if($onlineAmount == NULL) $onlineAmount = 0;

	$sumQuery      = $db->sql_query("SELECT SUM(amount) FROM ".TABLE_PREFIX."onlinepay WHERE uid = '$userId' and finalized = '0' ");
	$sumFetch      = mysql_fetch_row($sumQuery);
	$onlinePending = $sumFetch[0];
	if($onlinePending == NULL) $onlinePending = 0;

	$amountPending = $fishPending + $onlinePending;

	$sumQuery   = $db->sql_query("SELECT SUM(amount) FROM ".TABLE_PREFIX."adscost WHERE uid = '$userId' and status = '0' ");
	$sumFetch   = mysql_fetch_row($sumQuery);
	$adsPending = $sumFetch[0];
	if($adsPending == NULL) $adsPending = 0;

	$sumQuery   = $db->sql_query("SELECT SUM(amount) FROM ".TABLE_PREFIX."adscost WHERE uid = '$userId' and status = '1' ");
	$sumFetch   = mysql_fetch_row($sumQuery);
	$adsCost = $sumFetch[0];
	if($adsCost == NULL) $adsCost = 0;

	$remainCredit = $fishAmount + $fishGift + $onlineAmount - $adsCost - $adsPending;
	
	return $fishAmount."/".$fishPending."/".$onlineAmount."/".$onlinePending."/".$amountPending."/".$adsPending."/".$adsCost."/".$remainCredit."/".$fishGift;
}
function get_data($data)
{   
	$i='';
	$len = strlen($data);
	for($i = 0; $i < $len; $i++)
	{
		$data1 = substr($data,$i,1);
		$asc = ord($data1);
		if( ($asc >= 65 AND $asc <= 90) OR ($asc >= 97 AND $asc <= 122) OR ($asc >= 48 AND $asc <= 57))
		{
			// Ok
			$m = 1;
		}
		else
		{
			// Not OK
			$m = 2;
			break;
		}
	}
	return $m;
}
function get_email($email)
{   
	$i='';$m='';
	$len = strlen($email);
	for($i = 0; $i < $len; $i++)
	{
		$email1 = substr($email,$i,1);
		$asc = ord($email1);
		
		if( ($asc >= 65 AND $asc <= 90) OR ($asc >= 97 AND $asc <= 122) OR ($asc >= 48 AND $asc <= 57) OR $asc == 46 OR $asc == 64 OR $asc == 95)
		{
			// Ok
			$m = 1;
		}
		else
		{
			// Not OK
			$m = 2;
			break;
		}
	}
	return $m;
}
function get_dataf($data)
{   
	$i='';$m='';
	$len = strlen($data);
	for($i = 0; $i < $len; $i++)
	{
		$data1 = substr($data,$i,1);
		$asc = ord($data1);
		
		if( ($asc >= 65 AND $asc <= 90) OR ($asc >= 97 AND $asc <= 122) OR ($asc >= 48 AND $asc <= 57)  OR $asc ==  32   OR $asc ==  129 OR $asc ==  130 OR $asc ==  131 OR $asc ==  132 OR $asc ==  133 OR $asc ==  134 OR $asc ==  135 OR $asc ==  136 OR $asc ==  137 OR $asc ==  138 OR $asc ==  139 OR $asc ==  140 OR $asc ==  152 OR $asc ==  161 OR $asc ==  162 OR $asc ==  163 OR $asc ==  164 OR $asc ==  165 OR $asc ==  166 OR $asc ==  167 OR $asc ==  168 OR $asc ==  169 OR $asc ==  170 OR $asc ==  171 OR $asc ==  172 OR $asc ==  173 OR $asc ==  174 OR $asc ==  175 OR $asc ==  176 OR $asc ==  177 OR $asc ==  178 OR $asc ==  179 OR $asc ==  180 OR $asc ==  181 OR $asc ==  182 OR $asc ==  183 OR $asc ==  184 OR $asc ==  185 OR $asc ==  186 OR $asc ==  190 OR $asc ==  216 OR $asc ==  217 OR $asc ==  218 OR $asc ==  219)
		{
			// Ok
			$m = 1;
		}
		else
		{
			// Not OK
			$m = 2;
			break;
		}
		//$m = $m.'<br/>'.$asc;
	}
	return $m;
}
function get_int($data)
{   
	$i='';
	$len = strlen($data);
	for($i = 0; $i < $len; $i++)
	{
		$data1 = substr($data,$i,1);
		$asc = ord($data1);
		if($asc >= 48 AND $asc <= 57)
		{
			// Ok
			$m = 1;
		}
		else
		{
			// Not OK
			$m = 0;
			break;
		}
	}
	return $m;
}
function space_rep($sub)
{
    $m=0;
    $out='';
    $word = explode(' ',$sub);
    $cnt = count($word);
    if($cnt == 1)
    {
        $out = $sub;
    }
    else
    {
        for($i=0;$i<$cnt;$i++)
        {
            if($word[$i] != NULL)
            {
                $out = $out.$word[$i].'-';
            }
        }
        $out = trim($out,'-');
    }
    return $out;   
}
function get_install($prefix)
{   
	$i='';$m='';
	$len = strlen($prefix);
	for($i = 0; $i < $len; $i++)
	{
		$wo = substr($prefix,$i,1);
		$asc = ord($wo);
		if( ($asc >= 65 AND $asc <= 90) OR ($asc >= 97 AND $asc <= 122) OR ($asc >= 48 AND $asc <= 57) OR $asc == 95)
		{
			// Ok
			$m = 1;
		}
		else
		{
			// Not OK
			$m = 2;
			break;
		}
	}
	return $m;
}
?>