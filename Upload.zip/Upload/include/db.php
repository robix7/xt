<?php
$db = new MYSQL(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_DATABASE, FALSE);
$db->sql_connect();
mysql_query('SET NAMES utf8');

$loginMsg = '';
if(isset($_POST['login']))
{
    $loginMsg = USER::UserLogin($_POST['username'], $_POST['password']);
}

?>