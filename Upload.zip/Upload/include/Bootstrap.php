<?php

class Bootstarp
{
    
    public $error;
    
    function __construct()
    {
        $url = isset($_GET['url']) ? $_GET['url'] : NULL;
        $url = trim($url,'/');
        $url = explode('/', $url);

        $this->errors();
       
        if(empty($url[0]))
        {
            require 'controller/index.php';
            $controller = new index();
            $controller->loadModel('index');
            $controller->Index();
            return FALSE;
        }
		if(empty($url[1]))
        {
            header("Location:index.php");
            require 'controller/index.php';
            $controller = new index();
            $controller->loadModel('index');
            $controller->Index();
            return FALSE;
        }
            
        $path = 'controller/'.$url[0].'.php';
        if(file_exists($path))
        {
            require $path;  
        }
        else
        {
            $this->error->Not_Exist_Controller();
            return FALSE;
        }
        $controller = new $url[0]();
        $controller->loadModel($url[0]);
        
        if(isset($url[5]))
        {
            if(method_exists($controller, $url[1]))
            {
                $controller->{$url[1]}($url[2],$url[3],$url[4],$url[5]);
            }
            else
            {
                $this->error->Not_Exist_Function();
            }
        }
        elseif(isset($url[4]))
        {
            if(method_exists($controller, $url[1]))
            {
                $controller->{$url[1]}($url[2],$url[3],$url[4]);
            }
            else
            {
                $this->error->Not_Exist_Function();
            }
        }
        elseif(isset($url[3]))
        {
            if(method_exists($controller, $url[1]))
            {
                $controller->{$url[1]}($url[2],$url[3]);
            }
            else
            {
                $this->error->Not_Exist_function();
            }
        }
        elseif(isset($url[2]))
        {
            if(method_exists($controller, $url[1]))
            {
                $controller->{$url[1]}($url[2]);
            }
            else
            {
                $this->error->Not_Exist_function();
            }
        }
        elseif(isset($url[1]))
        {
            if(method_exists($controller, $url[1]))
            {
                $controller->{$url[1]}();
            }
            else
            {
                $this->error->Not_Exist_function();
            }
        }
        else 
        {
            $controller->Index();
        }
    }
    public function errors()
    {
       require 'controller/error.php';
       $this->error = new error();
    }

}
