<?php
class USER
{
    public static function UserLogin($username, $password)
    {
        $sql = 'CALL '.TABLE_PREFIX.'user_login(:username, :password)'; 
        $params = array (':username' => $username, ':password' => MD5($password));
        $user =  DatabaseHandler::GetRow($sql, $params);
        if($user)
        {
            $_SESSION['SUB_USER_ID'] = $user['id'];
            $_SESSION['SUB_USER'] = $user['name'];
            header('location:'.URL.'desktop/index');
        }
        else
        {
           $m = "<font color=red>ایمیل و یا رمز عبور اشتباه می باشد</font>";
        }
        return $m;
    }
    public static function AdminLogin($username, $password)
    {
        $sql = 'CALL '.TABLE_PREFIX.'admin_login(:username, :password)'; 
        $params = array (':username' => $username, ':password' => MD5($password));
        $user =  DatabaseHandler::GetRow($sql, $params);
        if ($user)
        {
            $_SESSION['SUB_ADMIN_ID']   = $user['id'];
            $_SESSION['SUB_ADMIN_NAME'] = $user['name'];
            header('location:'.URL.'admin/admin');
        }
        else
        {
           $m = "<font color=red>اطلاعات وارد شده اشتباه است</font>";
        }
        return $m;
    }
}
?>
