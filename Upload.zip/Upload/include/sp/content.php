<?php
class Contents
{
  public static function GetContent($id)
  {
    $sql = 'CALL '.TABLE_PREFIX.'get_content_by_id(:id)';
    $params = array(':id' => $id);
    return DatabaseHandler::GetAll($sql, $params);
  }
}
?>
