<?php
class Group
{
	public static function GetMainGroup()
	{
		$sql = 'CALL '.TABLE_PREFIX.'maingroup_select_all()';
		return DatabaseHandler::GetAll($sql);
	}
	public static function GetSubGroupById($mgid)
	{
		$sql = 'CALL '.TABLE_PREFIX.'subgroup_select_by_id(:mgid)';
		$params = array(':mgid' => $mgid);
		return DatabaseHandler::GetAll($sql, $params);
	}
	public static function GetSubGroup()
	{
		$sql = 'CALL '.TABLE_PREFIX.'subgroup_select_all()';
		return DatabaseHandler::GetAll($sql);
	}
}
?>
