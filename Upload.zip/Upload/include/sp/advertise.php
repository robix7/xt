<?php
class Advertise
{
  public static function GetAdvertise($adsid)
  {
    $sql = 'CALL '.TABLE_PREFIX.'advertise_by_id(:adsid)';
    $params = array(':adsid' => $adsid);
    return DatabaseHandler::GetAll($sql, $params);
  }
}
?>
