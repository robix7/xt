<?php
class Setting
{
    public static function GetSetting($id)
    {
        $sql = 'CALL '.TABLE_PREFIX.'read_setting(:id)';
        $params = array(':id' => $id);
        return DatabaseHandler::GetOne($sql, $params);
    }
}
?>
