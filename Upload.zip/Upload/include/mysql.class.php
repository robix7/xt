<?php
class MYSQL
{
	var $mysql_host;
	var $mysql_user;
	var $mysql_pass;
	var $mysql_name;
	var $mysql_flag;
	
	var $mysql_link;
	
	function MYSQL($mysql_host, $mysql_user, $mysql_pass, $mysql_name, $mysql_flag = false)
	{
		$this->mysql_host = $mysql_host;	
		$this->mysql_user = $mysql_user;
		$this->mysql_pass = $mysql_pass;
		$this->mysql_name = $mysql_name;
		$this->mysql_flag = $mysql_flag;
	}
	
	function sql_connect()
	{
		if($this->mysql_flag)
		{
			$this->link = mysql_pconnect($this->mysql_host, $this->mysql_user, $this->mysql_pass) or die(mysql_error());	
		}
		else
		{
			$this->link = mysql_connect($this->mysql_host, $this->mysql_user, $this->mysql_pass) or die(mysql_error());
		}
		if($this->link)
		{
			if(mysql_select_db($this->mysql_name, $this->link))
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		else
		{
			return false;	
		}
	}
	
	function sql_query($sql)
	{
		if(!$result=mysql_query($sql, $this->link))
		{
			return false;	
		}
		else
		{
			return $result;
		}
	}
	
	function sql_numrows($sql)
	{
		if(!$result=mysql_query($sql))
		{
			return false;	
		}
		else
		{
			return (mysql_num_rows($result));
		}
	}
	
	function sql_fetcharray($query)
	{
		if(!$result = mysql_fetch_array($query))
		{
			return false;	
		}
		else
		{
			return $result;
		}
	}
	
	function sql_result($q1,$q2)
	{
		if(!$result = mysql_result($q1,$q2))
		{
			return false;	
		}
		else
		{
			return $result;
		}
	}	
	function sql_close()
	{
		return (mysql_close($this->link));	
	}
}
?>