var http = getHttp();
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function link_change(kind,hasurl,star,edit)
{
	
    var code = kind+","+hasurl+","+star;
    if(edit == 1) http.open("GET", "../../../jadscost.php?param="+code,true);
    if(edit == 0) http.open("GET", "../jadscost.php?param="+code,true);
    http.onreadystatechange = AnswerOfAdsChanged;
    http.send(null);
}

function AnswerOfAdsChanged()
{
    if(http.readyState == 4)
    {
        
        r = http.responseText;
		if(r != -1)
        {
			adschange(r)
        }
        else
        {
            alert("خطا در ارتباط با سرور");
        }
    }
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function changeMainGroup(mgid,edit)
{
    var code = mgid;
    if(edit == 1) http.open("GET", "../../../jchangegroup.php?param="+code,true);
    if(edit == 0) http.open("GET", "../jchangegroup.php?param="+code,true);
    http.onreadystatechange = AnswerOfChangeMainGroup;
    http.send(null);
}

function AnswerOfChangeMainGroup()
{
    if(http.readyState == 4)
    {

        r = http.responseText;
        if(r != -1)
        {
            adsChangeMainGroup(r);
        }
        else
        {
            alert("خطا در ارتباط با سرور");
        }
    }
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function sendQuestion(qName,qEmail,qText,userid,adsid)
{
	
    var code = qName+","+qEmail+","+qText+","+userid+","+adsid;
    http.open("GET", "../../../jsendfaq.php?param="+code,true);
    http.onreadystatechange = AnswerOfSendQuestion;
    http.send(null);
}
function AnswerOfSendQuestion()
{
    if(http.readyState == 4)
    {
        
        r = http.responseText;
        if(r != -1)
        {
            question(r)
        }
        else
        {
            alert("خطا در ارتباط با سرور");
        }
    }
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function getHttp()
{
    var xmlhttp;
    try
    {
        xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
    }
    catch(e)
    {
        try
        {
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        catch(e)
        {
            if(typeof XMLHttpRequest != "undefined")
            {
                xmlhttp = new XMLHttpRequest();
            }
        }
    }
    return xmlhttp;
}