<?php
function sefr($num){
$lnn='';
$lnnn='';
array($lnn);
$len=strlen($num);
$zc=intval($len/3);
for ($za=0;$za<$len;$za++){
$lnn[$za]=substr($num,$za,1);
}
for ($zb=0;$zb<$len;$zb++){
	if ($zb==$len-(3*$zc) ){
	if ($zb!=0){
		$lnnn=$lnnn.",$lnn[$zb]";	
	}
	else {
		$lnnn=$lnnn.$lnn[$zb];
	}	
	$zc--;
	}
	else {
		$lnnn=$lnnn.$lnn[$zb];
	}
}
return ($lnnn);
}
?>