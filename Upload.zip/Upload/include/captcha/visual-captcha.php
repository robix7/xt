<?php
    require('php-captcha.inc.php');
    $aFonts = array('fonts/1.ttf', 'fonts/2.ttf', 'fonts/3.ttf', 'fonts/4.ttf', 'fonts/5.ttf');
    $oVisualCaptcha = new PhpCaptcha($aFonts, 200, 60);
    $oVisualCaptcha->DisplayShadow(true);
    //$oVisualCaptcha->SetBackgroundImages('images/captcha.jpg');
    //$oVisualCaptcha->UseColour(true);
    $oVisualCaptcha->Create();
?>

