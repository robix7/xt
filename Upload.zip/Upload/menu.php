<div id="ja-right" class="column sidebar" style="width:20%">
	<div class="ja-colswrap clearfix ja-r1">
		<div class="ja-col  column">
			<div class="ja-module ja-box-br module" id="Mod60">
				<div class="ja-box-bl">
					<div class="ja-box-tr">
						<?php
						$result      = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."menu WHERE `pos` = '2' AND `status` = '1' ORDER BY `ordering` ASC " );
						while($show_result = $db->sql_fetcharray($result))
						{
							$kind = $show_result['kind'];
							$file = $show_result['file'];
							$result1      = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."content WHERE `id` = '$file' " );
							$show_result1 = $db->sql_fetcharray($result1);
							$name1        = $show_result1['name'];
							$content      = $show_result1['content']; 							
							
							if($kind == 1)
							{
								?>
								<div class="ja-box-tl clearfix">
									<?php include "block/$file" ?>
								</div>
								<?php
							}
							if($kind == 2)
							{
								?>
								<h3><span><?php echo $name1; ?></span></h3>
								<div class="jamod-content ja-box-ct clearfix">
									<?php echo $content; ?>
								</div>
								<?php
							}
						}
						?>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>