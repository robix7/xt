<?php
$right_c = '';$mid_c = ''; $left_c = ''; 
if(isset($_GET['mgid']))
{
	$currentGroup = $_GET['mgid'];
}
elseif(isset($_GET['sgid']))
{
	$currentSubGroup = $_GET['sgid'];
	$result1         = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."adssubgroup WHERE `sgid` = '$currentSubGroup' ");
	$show_result1    = $db->sql_fetcharray($result1);
	$currentGroup    = $show_result1['mgid'];
}
else
{
	$currentGroup = 0;
}
?>
<ul id="menu">
	<li class="menu_right"><a href="<?php echo URL; ?>" >صفحه اصلی</a>   
   </li>				
<?php
$k = 0;
$result  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."adsmaingroup");
while($show_result=$db->sql_fetcharray($result))
{
	$k = 0;
	$tmgname  = $show_result['mgname'];
	$tmgid    = $show_result['mgid'];
	$tjpg     = $show_result['mgjpg'];
	
	$cnt = my_count(TABLE_PREFIX.'adssubgroup','sgid','mgid',$tmgid,-1,-1,-1,-1,-1,-1);
	$qty = floor($cnt/3);
	$cnt1 = $qty*3;
	$re = $cnt-$cnt1;
	if($re == 0){$right_c = $qty;  $mid_c = $qty+$qty;   $left_c = $cnt;}
	if($re == 1){$right_c = $qty+1;$mid_c = $qty+$qty+1;   $left_c = $cnt;}
	if($re == 2){$right_c = $qty+1;$mid_c = $qty+$qty+2; $left_c = $cnt;}
	
	$result1            = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."adssubgroup WHERE mgid = $tmgid");
	while($show_result1 = $db->sql_fetcharray($result1))
	{
		$k++;
		$tsgname[$k] = $show_result1['sgname'];
		$tsgid[$k]   = $show_result1['sgid'];
	}
	?>
		<li class="menu_right">
			<a href="<?php echo URL; ?>index/maingroup/<?php echo $tmgid; ?>" class="drop"><?php echo $tmgname; ?></a>
			<div class="dropdown_2columns align_right">
				<div class="col_1">
					<ul class="greybox">
						<?php
							
							for($j1	 = $mid_c+1 ;$j1 <= $cnt; $j1++)
							{
								?>
								<li class="mega first">
									<a href="<?php echo URL; ?>index/subgroup/<?php echo $tsgid[$j1]; ?>" class="mega first" title="<?php echo $tsgname[$j1]; ?>">
										<span class="menu-title"><?php echo $tsgname[$j1]; ?></span>
									</a>
								</li>
								<?php
							}
							
						?>
					</ul>
				</div>
				<div class="col_1">
					<ul class="greybox">
						<?php
							
							for($j1 = $right_c+1;$j1 <= $mid_c; $j1++)
							{
								?>
								<li class="mega first">
									<a href="<?php echo URL; ?>index/subgroup/<?php echo $tsgid[$j1]; ?>" class="mega first" title="<?php echo $tsgname[$j1]; ?>">
										<span class="menu-title"><?php echo $tsgname[$j1]; ?></span>
									</a>
								</li>
								<?php
							}
						?>
					</ul>
				</div>
				<div class="col_1">
					<ul class="greybox">
						<?php
							
							for($j1	 = 1 ;$j1 <= $right_c; $j1++)
							{
								?>
								<li class="mega first">
									<a href="<?php echo URL; ?>index/subgroup/<?php echo $tsgid[$j1]; ?>" class="mega first" title="<?php echo $tsgname[$j1]; ?>">
										<span class="menu-title"><?php echo $tsgname[$j1]; ?></span>
									</a>
								</li>
								<?php
							}
							
						?>
					</ul>
				</div>
			</div>
		</li>
	<?php
}
?>
	</ul>
