<?php
$pageid='';
if(isset($_GET['url']))
{
    $pt2 =  $_GET['url'];
    $pt2 = trim($pt2,'/');
    $pt2 = explode('/', $pt2);
    $count = count($pt2);
    
    if($count == 4)
    {
        $current = $pt2[0]."/".$pt2[1];
        $pageid  = $pt2[1];
    }
    elseif($count == 3)
    {
        $current = $pt2[0]."/".$pt2[1];
        $pageid  = $pt2[2];
    }
    elseif($count == 2)
    {
        $current = $pt2[0]."/".$pt2[1];
        $pageid  = $pt2[1];
    }
    elseif($count == 3)
    {
        $current = $pt2[1];
        $pageid  = $pt2[2];
    }
}
else

{
     $current = "index.php";
}

?>
<div class="top-nav">				
	<ul>
		<?php
		$result      = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."menu WHERE `pos` = '1' AND `status` = '1' ORDER BY `ordering` ASC " );
		while($show_result = $db->sql_fetcharray($result))
		{
			$kind1 = $show_result['kind'];
			$file1 = $show_result['file'];
			$name1 = $show_result['name'];
			$http  = substr($file1,0,7);
			if($http == 'http://')
			{
				$target = '_blank';
			}
			else
			{
				$target = '_self';
			}
			$result1      = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."content WHERE `id` = '$file1' " );
			$show_result1 = $db->sql_fetcharray($result1);
			$name2        = $show_result1['name'];  
			if($kind1 == 3)
			{
				if($file1 == $current) $class = 'current-menu-item';
				?>
				<li class = "<?php echo $class; ?>">
					<a href="<?php echo URL; ?><?php echo $file1; ?>" target="<?php echo $target; ?>"><?php echo $name1; ?></a>
				</li>
				<?php
				$class = '';
			}
            if($kind1 == 4)
			{
				if($file1 == $current) $class = 'current-menu-item';
				?>
				<li class = "<?php echo $class; ?>">
					<a href="<?php echo $file1; ?>" target="<?php echo $target; ?>"><?php echo $name1; ?></a>
				</li>
				<?php
				$class = '';
			}
			if($kind1 == 2)
			{
				if($file1 == $pageid) $class = 'current-menu-item';
				?>
				<li class = "<?php echo $class; ?>">
					<a href="<?php echo URL; ?>content/page/<?php echo $file1; ?>"><?php echo $name2; ?></a>
				</li>
				<?php
				$class = '';
			}
		}
		?>
	</ul>
</div>