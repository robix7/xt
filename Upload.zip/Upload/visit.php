<?php
$visit = Setting::GetSetting(22);
$visit++;
$sql = "UPDATE ".TABLE_PREFIX."setting` SET `value` = '$visit' WHERE `id` = '22' ";
$db->sql_query($sql);
?>