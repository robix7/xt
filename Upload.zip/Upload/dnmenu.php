<?php
$pageid='';
if(isset($_GET['url']))
{
    $pt3 =  $_GET['url'];
    $pt3 = trim($pt3,'/');
    $pt3 = explode('/', $pt3);
    $count = count($pt3);
    
    if($count == 2)
    {
        $current = $pt2[0]."/".$pt3[1];
        $pageid  = $pt2[1];
    }
    elseif($count == 3)
    {
        $current = $pt3[1];
        $pageid  = $pt3[2];
    }
}
else

{
     $current = "index.php";
}

?>
<div class="ja-footnav">
	<div>
		<ul>
			<?php
			$result      = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."menu WHERE `pos` = '3' AND `status` = '1' ORDER BY `ordering` ASC " );
			while($show_result = $db->sql_fetcharray($result))
			{
                $kind = $show_result['kind'];
				$file = $show_result['file'];
				$name = $show_result['name'];
				$result1      = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."content WHERE `id` = '$file' " );
				$show_result1 = $db->sql_fetcharray($result1);
				$name1        = $show_result1['name'];  
				if($kind == 3)
				{
					if($file == $current) $class = 'current-menu-item';
					?>
						<li>
							<a href="<?php echo URL; ?><?php echo $file; ?>"><?php echo $name; ?></a>
						</li>
					<?php
					$class = '';
				}
                 if($kind == 4)
                {
                    if($file1 == $current) $class = 'current-menu-item';
                    ?>
                    <li class = "<?php echo $class; ?>">
                        <a href="<?php echo $file1; ?>" target="<?php echo $target; ?>"><?php echo $name1; ?></a>
                    </li>
                    <?php
                    $class = '';
                }
				if($kind == 2)
				{
					if($file == $pageid) $class = 'current-menu-item';
					?>
					<li class = "<?php echo $class; ?>">
						<a href="<?php echo URL; ?>content/page/<?php echo $file; ?>"><?php echo $name1; ?></a>
					</li>
					<?php
					$class = '';
				}
			}
			?>
		</ul>
	</div>
</div>