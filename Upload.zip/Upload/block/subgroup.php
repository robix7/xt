<?php
$uuu = 0;
if(isset($_GET['mgid']))
{
	$mgid3 = $_GET['mgid'];
	$uuu = 1;
}
if(isset($_GET['sgid']))
{
	$sgid3 = $_GET['sgid'];
	$result10  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."adssubgroup WHERE sgid = $sgid3" );
	$show_result10 = $db->sql_fetcharray($result10);
	$mgid3 = $show_result10['mgid'];
	$uuu = 1;
}
if($uuu == 1)
{
	$result10  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."adsmaingroup WHERE mgid = $mgid3" );
	$show_result10 = $db->sql_fetcharray($result10);
	$mgname = $show_result10['mgname'];
	if($mgid3 != NULL) 
	{
		?>
		<h3><span>گروه : <?php echo $mgname; ?></span></h3>
		<div class="jamod-content ja-box-ct clearfix">
		<ul>
			<?php
				$result11  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."adssubgroup WHERE mgid = $mgid3" );
				while($show_result11 = $db->sql_fetcharray($result11))
				{
					$sgname = $show_result11['sgname'];
					$sgid   = $show_result11['sgid'];
					?>
						<li>
							<a href="<?php echo URL; ?>index/subgroup/<?php echo $sgid; ?>"><?php echo $sgname; ?></a>
						</li>
					<?php
				}
				?>
			</ul>
		</div>
		<?php
	}
}
?>