<?php
$amarnow = s_to_g(time());
$amarnow = explode('-',$amarnow);
$amarstr = mktime(0,0,0,$amarnow[1],$amarnow[2],$amarnow[0]);

?>
<h3><span>آمار</span></h3>
<div class="jamod-content ja-box-ct clearfix">
	<table>
		<tbody>
			<tr>
				<td style="text-align:center;">روز</td>
				<td style="text-align:center;">تعداد آگهی</td>
			</tr>
			<?php 
			for($amari = 0; $amari<5; $amari++)
			{
				
				$amarbegin = $amarstr - ($amari * 86400);
				$amarend   = $amarstr + 86400  - ($amari * 86400);
				
				$sql = "SELECT COUNT(`id`) FROM ".TABLE_PREFIX."advertise WHERE `update` >= '$amarbegin' AND `update` <= '$amarend' ";
				$cnt_query = mysql_query($sql);
				$cnt_a     = mysql_fetch_row($cnt_query);
				$cnt       = $cnt_a[0];
				?>
				<tr>
					<td style="text-align:center;"><?php echo s_to_j($amarbegin); ?></td>
					<td style="text-align:center;"><?php echo $cnt; ?></td>
				</tr>
				<?php
			}
		?>
		</tbody>
	</table>
</div>