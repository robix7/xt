<?php
	
	$result12  = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."setting" );
	while($show_result12 = $db->sql_fetcharray($result12))
	{
		$id    = $show_result12['id'];
		$value = $show_result12['value'];
		
		if($id == 2) $star  = $value;
		if($id == 3) $link  = $value;
		if($id == 4) $spads = $value;
	}
?>
<h3><span>تعرفه درج آگهی</span></h3>
<div class="jamod-content ja-box-ct clearfix">
	<ul>
		<li><strong>آگهی ویژه:<?php echo sefr($spads); ?>ریال</strong></li>
		<li><strong>هر ستاره:<?php echo sefr($star); ?>ریال</strong></li>
		<li><strong>لینک:<?php echo sefr($link); ?>ریال</strong></li>
	</ul>
</div>