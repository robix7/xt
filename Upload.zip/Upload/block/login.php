<?php
if(isset($_SESSION['SUB_USER_ID'])) 
{
	?>
	<h3><span>ورود اعضاء</span></h3>
	<div class="jamod-content ja-box-ct clearfix">
		<form action="index.php" method="post" name="form-login" id="form-login">
			<div style="color:red;text-align:justify">

			</div>
			<ul>
				<li>
					<a href="<?php echo URL; ?>desktop/index">کنترل پنل</a>
				</li>
				<li>
					<a href="<?php echo URL; ?>desktop/index.php?log=out">خروج</a>
				</li>
			</ul>			
		</form>
	</div>
	<?php
}
else
{
	?>
	<h3><span>ورود اعضاء</span></h3>
	<div class="jamod-content ja-box-ct clearfix">
		<form action="" method="post">
			<div style="color:red;text-align:justify;" >

			</div>
			<fieldset class="input">
				<p id="form-login-username">
					<label>
						ایمیل<br/>
						<input name="username" id="username" class="inputbox" alt="username" size="18" type="text" />
					</label>
				</p>
				<p id="form-login-password">
					<label>
						رمزعبور<br/>
						<input name="password" id="password" class="inputbox" size="18" alt="password" type="password" />
					</label>
				</p>
				<input name="login" class="button" value="ورود" type="submit" />
			</fieldset>
			<?php echo $loginMsg; ?>
			<ul>
				<li>
					<a href="<?php echo $pt; ?>register/add">رمزعبور خود را فراموش کردید؟</a>
				</li>
				<li>
					<a href="<?php echo $pt; ?>register/add">ایجاد یک حساب کاربری</a>
				</li>
			</ul>			
		</form>
	</div>
	<?php
}
?>