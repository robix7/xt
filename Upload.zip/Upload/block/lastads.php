<h3><span>آخرین آگهی ها</span></h3>
<div class="jamod-content ja-box-ct clearfix">
	<ul>
		<?php 
		$lastads   = $db->sql_query("SELECT * FROM ".TABLE_PREFIX."advertise WHERE `status` = 1 ORDER BY `update` DESC" );
		while($lsRS      = $db->sql_fetcharray($lastads))
		{
			$lsk++;
			if($lsk > 10) break;
			$lsid      = $lsRS['id'];
			$lssubject = $lsRS['subject'];
			?>
			<li><img alt="stars" src="<?php echo URL; ?>template/default/image/singlestar.gif"> <a href="<?php echo URL; ?>ads/view/<?php echo $lsid; ?>/<?php echo $lssubject; ?>" target="_blank"><?php echo $lssubject; ?></a></li>
			<?php
		}
		?>
	</ul>
</div>